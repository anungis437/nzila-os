package main

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"runtime"
)

func compress(source io.Reader, destination io.Writer) error {
	buffer := bufio.NewWriterSize(destination, 128*1024)
	writer, err := gzip.NewWriterLevel(buffer, gzip.DefaultCompression)
	if err != nil {
		return err
	}
	// TeeReader prevents WriterTo selection, as in BuildKit timestamp conversion.
	if _, err := io.Copy(writer, io.TeeReader(source, io.Discard)); err != nil {
		closeErr := writer.Close()
		if closeErr != nil {
			return errors.Join(err, closeErr)
		}
		return err
	}
	if err := writer.Close(); err != nil {
		return err
	}
	return buffer.Flush()
}

func execute(args []string) error {
	if runtime.Version() != "go1.25.6" {
		return errors.New("EXACT_ENGINE_GO_1_25_6_REQUIRED_NO_CANDIDATE_RUN")
	}
	if len(args) != 4 || len(args[1]) != 64 || len(args[3]) != 64 {
		return errors.New("EXACT_FIXTURE_SHA_AND_GZIP_SHA_REQUIRED")
	}
	file, err := os.Open(args[0])
	if err != nil {
		return err
	}
	defer file.Close()
	digest := sha256.New()
	if _, err := io.Copy(digest, file); err != nil {
		return err
	}
	if hex.EncodeToString(digest.Sum(nil)) != args[1] {
		return errors.New("FROZEN_TAR_SHA_MISMATCH")
	}
	if _, err := file.Seek(0, io.SeekStart); err != nil {
		return err
	}
	output, err := os.OpenFile(args[2], os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	if err := compress(file, output); err != nil {
		closeErr := output.Close()
		return errors.Join(err, closeErr)
	}
	if err := output.Close(); err != nil {
		return err
	}
	raw, err := os.ReadFile(args[2])
	if err != nil {
		return err
	}
	sum := sha256.Sum256(raw)
	actual := hex.EncodeToString(sum[:])
	if err := json.NewEncoder(os.Stdout).Encode(map[string]any{
		"goVersion": runtime.Version(), "gzipSha256": actual, "gzipBytes": len(raw),
		"exactDigest": actual == args[3],
		"stream":      "IO_COPY_TEE_READER_NOMINAL_32K_NOT_OBSERVED_PIPE_SHORT_READ_SEQUENCE",
	}); err != nil {
		return err
	}
	if actual != args[3] {
		return errors.New("EXACT_GZIP_GATE_FAILED_STOP_CANDIDATE")
	}
	return nil
}

func main() {
	if err := execute(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
