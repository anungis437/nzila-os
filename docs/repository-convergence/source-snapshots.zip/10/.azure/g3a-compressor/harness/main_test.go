package main

import (
	"bytes"
	"compress/gzip"
	"errors"
	"io"
	"runtime"
	"testing"
)

func TestFixtureRoundTripAndHeaderOnlyNotFrozenCandidate(t *testing.T) {
	var output bytes.Buffer
	input := bytes.Repeat([]byte("synthetic-compressor-unit-fixture\n"), 4096)
	if err := compress(bytes.NewReader(input), &output); err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(output.Bytes()[:10], []byte{31, 139, 8, 0, 0, 0, 0, 0, 0, 255}) {
		t.Fatal("gzip header")
	}
	reader, err := gzip.NewReader(bytes.NewReader(output.Bytes()))
	if err != nil {
		t.Fatal(err)
	}
	got, err := io.ReadAll(reader)
	if err != nil || !bytes.Equal(got, input) {
		t.Fatal("round trip")
	}
	if err := reader.Close(); err != nil {
		t.Fatal(err)
	}
}

type brokenReader struct{}

func (brokenReader) Read([]byte) (int, error) { return 0, errors.New("fixture-read-error") }

type brokenWriter struct{}

func (brokenWriter) Write([]byte) (int, error) { return 0, errors.New("fixture-write-error") }

func TestErrorsSurface(t *testing.T) {
	if err := compress(brokenReader{}, &bytes.Buffer{}); err == nil {
		t.Fatal("reader error swallowed")
	}
	if err := compress(bytes.NewReader([]byte("fixture")), brokenWriter{}); err == nil {
		t.Fatal("flush error swallowed")
	}
}

func TestOtherRuntimeCannotRunFrozenCandidate(t *testing.T) {
	if runtime.Version() == "go1.25.6" {
		t.Skip("runtime guard requires non-target runtime")
	}
	if err := execute(nil); err == nil || err.Error() != "EXACT_ENGINE_GO_1_25_6_REQUIRED_NO_CANDIDATE_RUN" {
		t.Fatal("unbound runtime accepted")
	}
}
