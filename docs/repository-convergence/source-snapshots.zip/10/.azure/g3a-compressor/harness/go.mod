module nzila.example/g3a-compressor

go 1.25.6
