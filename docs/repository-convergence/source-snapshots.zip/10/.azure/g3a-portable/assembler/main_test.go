package main

import (
	"archive/tar"
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

func TestRejectArchiveEscapesAndTypes(t *testing.T) {
	for _, tc := range []struct {
		Name string
		Type byte
	}{
		{"/foreign", tar.TypeReg}, {"../foreign", tar.TypeReg}, {"x/../foreign", tar.TypeReg},
		{"file", tar.TypeSymlink}, {"file", tar.TypeLink}, {"file", tar.TypeChar},
	} {
		var b bytes.Buffer
		writer := tar.NewWriter(&b)
		h := &tar.Header{Name: tc.Name, Mode: 0644, Typeflag: tc.Type, Linkname: "/foreign"}
		if err := writer.WriteHeader(h); err != nil {
			t.Fatal(err)
		}
		if err := writer.Close(); err != nil {
			t.Fatal(err)
		}
		parent := t.TempDir()
		if err := extract(b.Bytes(), filepath.Join(parent, "out"), map[string]entry{"file": {SHA: fmt.Sprintf("%x", sha256.Sum256(nil)), Mode: 0644}}); err == nil {
			t.Fatal("unsafe archive accepted", tc)
		}
	}
}

func TestExtractionExactHashModeAndNoOverwrite(t *testing.T) {
	var b bytes.Buffer
	writer := tar.NewWriter(&b)
	if err := writer.WriteHeader(&tar.Header{Name: "file", Mode: 0755, Size: 3, Typeflag: tar.TypeReg}); err != nil {
		t.Fatal(err)
	}
	if _, err := writer.Write([]byte("abc")); err != nil {
		t.Fatal(err)
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	contract := map[string]entry{"file": {Bytes: 3, SHA: hash([]byte("abc")), Mode: 0755}}
	dest := filepath.Join(t.TempDir(), "out")
	if err := extract(b.Bytes(), dest, contract); err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(filepath.Join(dest, "file"))
	if err != nil || info.Mode().Perm() != 0755 {
		t.Fatal("mode")
	}
	if err := extract(b.Bytes(), dest, contract); err == nil {
		t.Fatal("existing workspace accepted")
	}
	contract["file"] = entry{Bytes: 3, SHA: hash([]byte("foreign")), Mode: 0755}
	if err := extract(b.Bytes(), filepath.Join(t.TempDir(), "out"), contract); err == nil {
		t.Fatal("foreign SHA")
	}
}

func TestFrozenTarHeaderAndDeterministicGzip(t *testing.T) {
	files := []struct {
		Name      string
		Mode      int64
		Data      []byte
		Directory bool
	}{{"g3-runtime", 0755, []byte("fixture"), false}}
	raw, compressed, err := makeLayer(files)
	if err != nil {
		t.Fatal(err)
	}

	raw2, compressed2, err := makeLayer(files)
	if err != nil || !bytes.Equal(raw, raw2) || !bytes.Equal(compressed, compressed2) {
		t.Fatal("non deterministic")
	}
	if !bytes.Equal(compressed[:10], []byte{31, 139, 8, 0, 0, 0, 0, 0, 0, 255}) {
		t.Fatal("gzip header contract")
	}
	if len(raw) != 2048 {
		t.Fatal("tar end padding", len(raw))
	}
}

func TestDescriptorSizesCompactAndPretty(t *testing.T) {
	for _, template := range []string{`{"digest":"sha256:fixture","size":3}`,
		"{\n  \"digest\": \"sha256:fixture\",\n  \"size\": 3,\n \"mediaType\": \"fixture\"\n}"} {
		actual, err := replaceDescriptor(template, descriptor{Digest: "sha256:fixture", Size: 3}, []byte("five!"))
		if err != nil {
			t.Fatal(err)
		}
		var object descriptor
		if err := json.Unmarshal([]byte(actual), &object); err != nil || object.Size != 5 ||
			object.Digest != "sha256:"+hash([]byte("five!")) {
			t.Fatal("invalid descriptor", actual, err)
		}
	}
	if _, err := replaceDescriptor(`{"digest":"sha256:fixture","size":4}`,
		descriptor{Digest: "sha256:fixture", Size: 3}, []byte("five!")); err == nil {
		t.Fatal("unbound template descriptor accepted")
	}
}
