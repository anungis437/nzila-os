package main

import (
	"archive/tar"
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

type entry struct {
	Bytes int64  `json:"bytes"`
	SHA   string `json:"sha256"`
	Mode  int64  `json:"mode"`
}
type binding struct {
	Inputs      map[string]entry `json:"inputs"`
	Source      map[string]entry `json:"sourceMembers"`
	Frozen      string           `json:"frozenManifest"`
	ExpectedELF string           `json:"expectedBinarySha256"`
}
type descriptor struct {
	Digest string `json:"digest"`
	Size   int64  `json:"size"`
}
type imageManifest struct {
	Config descriptor   `json:"config"`
	Layers []descriptor `json:"layers"`
}

func hash(raw []byte) string {
	value := sha256.Sum256(raw)
	return hex.EncodeToString(value[:])
}

func fail(value bool, stage string) error {
	if !value {
		return errors.New(stage)
	}
	return nil
}

func exclusive(path string, raw []byte, mode os.FileMode) error {
	file, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, mode)
	if err != nil {
		return err
	}
	_, err = file.Write(raw)
	closeErr := file.Close()
	if err != nil {
		return err
	}
	return closeErr
}

func safeName(name string) bool {
	if name == "" || strings.Contains(name, "\\") || strings.HasPrefix(name, "/") {
		return false
	}
	for _, part := range strings.Split(strings.TrimSuffix(name, "/"), "/") {
		if part == "" || part == "." || part == ".." {
			return false
		}
	}
	return true
}

func extract(raw []byte, dest string, contract map[string]entry) error {
	if err := os.Mkdir(dest, 0700); err != nil {
		return err
	}
	reader := tar.NewReader(bytes.NewReader(raw))
	seen := map[string]bool{}
	for {
		header, err := reader.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
		name := strings.TrimSuffix(header.Name, "/")
		if !safeName(header.Name) || seen[name] || header.Mode & ^int64(0777) != 0 {
			return errors.New("ARCHIVE_PATH_MODE_OR_DUPLICATE")
		}
		seen[name] = true
		target := filepath.Join(dest, filepath.FromSlash(name))
		if header.Typeflag == tar.TypeDir {
			allowed := false
			for member := range contract {
				allowed = allowed || strings.HasPrefix(member, name+"/")
			}
			if !allowed || header.Mode != 0755 {
				return errors.New("ARCHIVE_UNEXPECTED_DIRECTORY")
			}
			if err := os.MkdirAll(target, 0755); err != nil {
				return err
			}
			continue
		}
		expected, ok := contract[name]
		if !ok || header.Typeflag != tar.TypeReg || header.Size != expected.Bytes || header.Mode != expected.Mode {
			return errors.New("ARCHIVE_MEMBER_TYPE_MODE_SIZE")
		}
		payload, err := io.ReadAll(io.LimitReader(reader, expected.Bytes+1))
		if err != nil || int64(len(payload)) != expected.Bytes || hash(payload) != expected.SHA {
			return errors.New("ARCHIVE_MEMBER_SHA")
		}
		if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil {
			return err
		}
		if err := exclusive(target, payload, os.FileMode(expected.Mode)); err != nil {
			return err
		}
	}
	for name := range contract {
		if !seen[name] {
			return errors.New("ARCHIVE_MEMBER_MISSING")
		}
	}
	return nil
}

func makeLayer(files []struct {
	Name      string
	Mode      int64
	Data      []byte
	Directory bool
}, compressor, work string) ([]byte, []byte, error) {
	var content bytes.Buffer
	writer := tar.NewWriter(&content)
	for _, item := range files {
		header := &tar.Header{Name: item.Name, Mode: item.Mode, Uid: 0, Gid: 0,
			ModTime: time.Unix(946684800, 0), Format: tar.FormatUSTAR,
			Typeflag: tar.TypeReg, Size: int64(len(item.Data))}
		if item.Directory {
			header.Typeflag, header.Size = tar.TypeDir, 0
		}
		if err := writer.WriteHeader(header); err != nil {
			return nil, nil, err
		}
		if !item.Directory {
			if _, err := writer.Write(item.Data); err != nil {
				return nil, nil, err
			}
		}
	}
	if err := writer.Close(); err != nil {
		return nil, nil, err
	}
	compressed, err := compressStaged(content.Bytes(), compressor, work)
	if err != nil {
		return nil, nil, err
	}
	return content.Bytes(), compressed, nil
}

func staticELF(raw []byte) bool {
	if len(raw) < 64 || !bytes.Equal(raw[:6], []byte{0x7f, 'E', 'L', 'F', 2, 1}) ||
		binary.LittleEndian.Uint16(raw[18:20]) != 62 {
		return false
	}

	offset := binary.LittleEndian.Uint64(raw[32:40])
	stride := uint64(binary.LittleEndian.Uint16(raw[54:56]))
	count := uint64(binary.LittleEndian.Uint16(raw[56:58]))
	if stride < 56 || count == 0 || offset > uint64(len(raw)) || count*stride > uint64(len(raw))-offset {
		return false
	}
	for i := uint64(0); i < count; i++ {
		if binary.LittleEndian.Uint32(raw[offset+i*stride:]) == 3 {
			return false
		}
	}
	return true
}

func replaceDescriptor(content string, expected descriptor, payload []byte) (string, error) {
	if strings.Count(content, expected.Digest) != 1 {
		return "", errors.New("TEMPLATE_DESCRIPTOR_DIGEST_CENSUS")
	}
	pattern := regexp.MustCompile(fmt.Sprintf(`("size"\s*:\s*)%d([,}])`, expected.Size))
	if len(pattern.FindAllString(content, -1)) != 1 {
		return "", errors.New("TEMPLATE_DESCRIPTOR_SIZE_CENSUS")
	}
	content = strings.Replace(content, expected.Digest, "sha256:"+hash(payload), 1)
	return pattern.ReplaceAllStringFunc(content, func(match string) string {
		fields := pattern.FindStringSubmatch(match)
		return fields[1] + fmt.Sprint(len(payload)) + fields[2]
	}), nil
}

func execute(inputs, work, output string) error {
	if os.Getenv("DOCKER_HOST") != "" {
		return errors.New("HOST_DOCKER_ENV_PRESENT")
	}
	for _, name := range []string{"docker", "buildx", "buildctl", "buildkitd", "go"} {
		if _, err := exec.LookPath(name); err == nil {
			return errors.New("UNSTAGED_EXECUTABLE_VISIBLE_" + name)
		}
	}
	for _, path := range []string{"/var/run/docker.sock", "/run/docker.sock", "/usr/local/go/bin/go"} {
		if _, err := os.Stat(path); err == nil || !os.IsNotExist(err) {
			return errors.New("HOST_ENGINE_OR_COMPILER_PATH_VISIBLE")
		}
	}
	raw, err := os.ReadFile(filepath.Join(inputs, "binding.json"))
	if err != nil {
		return err
	}
	var b binding
	if err := json.Unmarshal(raw, &b); err != nil {
		return err
	}
	if err := os.Mkdir(work, 0700); err != nil {
		return err
	}
	payloads := map[string][]byte{}
	for name, expected := range b.Inputs {
		if !safeName(name) || strings.Contains(name, "/") {
			return errors.New("INPUT_NAME_INVALID")
		}
		raw, err := os.ReadFile(filepath.Join(inputs, name))
		if err != nil {
			return err
		}
		if int64(len(raw)) != expected.Bytes || hash(raw) != expected.SHA {
			return errors.New("INPUT_SHA_OR_SIZE")
		}
		payloads[name] = raw
	}
	var sourceManifest struct {
		Schema   int    `json:"schemaVersion"`
		Media    string `json:"mediaType"`
		Artifact string `json:"artifactType"`
		Config   struct {
			Media  string `json:"mediaType"`
			Digest string `json:"digest"`
			Size   int64  `json:"size"`
		} `json:"config"`
		Layers []struct {
			Media  string `json:"mediaType"`
			Digest string `json:"digest"`
			Size   int64  `json:"size"`
		} `json:"layers"`
	}
	if err := json.Unmarshal(payloads["source-manifest.json"], &sourceManifest); err != nil {
		return err
	}
	if sourceManifest.Schema != 2 || sourceManifest.Media != "application/vnd.oci.image.manifest.v1+json" ||
		sourceManifest.Artifact != "application/vnd.nzila.g3.build-source.v1" ||
		sourceManifest.Config.Media != "application/vnd.oci.empty.v1+json" || sourceManifest.Config.Size != 2 ||
		sourceManifest.Config.Digest != "sha256:"+hash([]byte("{}")) || len(sourceManifest.Layers) != 1 ||
		sourceManifest.Layers[0].Media != "application/vnd.nzila.g3.source.tar.v1" ||
		sourceManifest.Layers[0].Digest != "sha256:"+hash(payloads["source.tar"]) ||
		sourceManifest.Layers[0].Size != int64(len(payloads["source.tar"])) {
		return errors.New("SOURCE_MANIFEST_DESCRIPTOR_CONTRACT")
	}
	var tools map[string]entry
	if err := json.Unmarshal(payloads["toolchain-members.json"], &tools); err != nil {
		return err
	}
	if err := extract(payloads["go-toolchain.tar"], filepath.Join(work, "go"), tools); err != nil {
		return err
	}
	if err := extract(payloads["source.tar"], filepath.Join(work, "source"), b.Source); err != nil {
		return err
	}
	goPath := filepath.Join(work, "go", "bin", "go")
	for _, name := range []string{"bin/go", "pkg/tool/linux_amd64/compile", "pkg/tool/linux_amd64/link"} {
		raw, err := os.ReadFile(filepath.Join(work, "go", name))
		if err != nil || !staticELF(raw) {
			return errors.New("STAGED_TOOLCHAIN_STATIC_ELF_REQUIRED")
		}
	}
	log, err := os.OpenFile(filepath.Join(work, "compiler.log"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer log.Close()
	defer func() {
		payload, readErr := os.ReadFile(filepath.Join(work, "compiler.log"))
		if readErr == nil {
			if writeErr := exclusive(filepath.Join(output, "compiler-diagnostic.txt"), payload, 0600); writeErr != nil {
				fmt.Fprintln(os.Stderr, "COMPILER_DIAGNOSTIC_OUTPUT_FAILED", writeErr)
			}
		} else {
			fmt.Fprintln(os.Stderr, "COMPILER_DIAGNOSTIC_READ_FAILED", readErr)
		}
	}()
	for _, args := range [][]string{{"test", "./..."}, {"vet", "./..."}, {"build", "-trimpath", "-buildvcs=false",
		"-ldflags=-buildid= -s -w", "-o", filepath.Join(work, "g3-runtime"), "."}} {
		command := exec.Command(goPath, args...)
		command.Dir = filepath.Join(work, "source")
		command.Env = []string{"PATH=/unavailable", "GOROOT=" + filepath.Join(work, "go"),
			"GOCACHE=" + filepath.Join(work, "cache"), "GOPATH=" + filepath.Join(work, "gopath"),
			"HOME=" + work, "TMPDIR=/tmp", "CGO_ENABLED=0", "GOOS=linux", "GOARCH=amd64",
			"GOTOOLCHAIN=local", "GOPROXY=off", "GOSUMDB=off", "SOURCE_DATE_EPOCH=946684800"}
		command.Stdout, command.Stderr = log, log
		if err := command.Run(); err != nil {
			return fmt.Errorf("STAGED_COMPILER_EXECUTION: %w", err)
		}
	}
	app, err := os.ReadFile(filepath.Join(work, "g3-runtime"))
	if err != nil {
		return err
	}
	if !staticELF(app) || hash(app) != b.ExpectedELF {
		return errors.New("FROZEN_APPLICATION_BINARY_MISMATCH")
	}
	type file = struct {
		Name      string
		Mode      int64
		Data      []byte
		Directory bool
	}
	firstRaw, first, err := makeLayer([]file{{"g3-runtime", 0755, app, false}}, filepath.Join(inputs, "compressor-go1256"), work)
	if err != nil {
		return err
	}
	secondRaw, second, err := makeLayer([]file{
		{"etc/", 0755, nil, true}, {"etc/ssl/", 0755, nil, true}, {"etc/ssl/certs/", 0755, nil, true},
		{"etc/ssl/certs/ca-certificates.crt", 0644, payloads["ca-certificates.crt"], false},
	}, filepath.Join(inputs, "compressor-go1256"), work)
	if err != nil {
		return err
	}
	config := payloads["config-template.json"]
	var expected imageManifest
	if err := json.Unmarshal(payloads["manifest-template.json"], &expected); err != nil {
		return err
	}
	if len(expected.Layers) != 2 {
		return errors.New("FROZEN_LAYER_CENSUS")
	}
	// Templates bind only serialized image metadata; all layer content is freshly constructed.
	manifest := string(payloads["manifest-template.json"])
	for i, layer := range [][]byte{first, second} {
		manifest, err = replaceDescriptor(manifest, expected.Layers[i], layer)
		if err != nil {
			return err
		}
	}
	index, err := replaceDescriptor(string(payloads["index-template.json"]),
		descriptor{Digest: b.Frozen, Size: int64(len(payloads["manifest-template.json"]))}, []byte(manifest))
	if err != nil {
		return err
	}
	layout := filepath.Join(work, "oci")
	if err := os.MkdirAll(filepath.Join(layout, "blobs", "sha256"), 0700); err != nil {
		return err
	}
	for _, raw := range [][]byte{config, first, second, []byte(manifest)} {
		if err := exclusive(filepath.Join(layout, "blobs", "sha256", hash(raw)), raw, 0600); err != nil {
			return err
		}
	}
	if err := exclusive(filepath.Join(layout, "index.json"), []byte(index), 0600); err != nil {
		return err
	}
	if err := exclusive(filepath.Join(layout, "oci-layout"), []byte(`{"imageLayoutVersion":"1.0.0"}`), 0600); err != nil {
		return err
	}
	result := map[string]any{
		"binarySha256": hash(app), "binaryBytes": len(app), "binaryFormat": "STATIC_ELF_LINUX_AMD64",
		"configDigest": "sha256:" + hash(config), "layerDigests": []string{"sha256:" + hash(first), "sha256:" + hash(second)},
		"uncompressedLayerDigests": []string{"sha256:" + hash(firstRaw), "sha256:" + hash(secondRaw)},
		"manifestDigest":           "sha256:" + hash([]byte(manifest)), "indexDigest": "sha256:" + hash([]byte(index)),
		"frozenManifest": b.Frozen, "exactFrozenManifest": "sha256:"+hash([]byte(manifest)) == b.Frozen,
		"hostBuildEngineIsolation": "PASS", "stagedGoCompilerUsed": true, "network": "NONE",
		"executablesUsed": []string{"STAGED_CONTROLLER", "STAGED_GO_BIN", "STAGED_GO_TOOL_EXECUTABLES"},
	}
	out, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return err
	}
	if err := exclusive(filepath.Join(work, "result.json"), append(out, '\n'), 0600); err != nil {
		return err
	}
	for name, raw := range map[string][]byte{
		"result.json": append(out, '\n'), "g3-runtime": app, "layer1.tar": firstRaw,
		"layer2.tar": secondRaw, "layer1.tar.gz": first, "layer2.tar.gz": second,
		"config.json": config, "manifest.json": []byte(manifest), "index.json": []byte(index),
	} {
		if err := exclusive(filepath.Join(output, name), raw, 0600); err != nil {
			return err
		}
	}
	compilerLog, err := os.ReadFile(filepath.Join(work, "compiler.log"))
	if err != nil {
		return err
	}
	if err := exclusive(filepath.Join(output, "compiler.log"), compilerLog, 0600); err != nil {
		return err
	}
	fmt.Println(string(out))
	return fail(result["exactFrozenManifest"] == true, "EXACT_FROZEN_MANIFEST_MISMATCH_STOP")
}

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintln(os.Stderr, "EXACT_INPUTS_AND_EXCLUSIVE_WORKSPACE_REQUIRED")
		os.Exit(1)
	}
	if err := execute(os.Args[1], os.Args[2], os.Args[3]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
