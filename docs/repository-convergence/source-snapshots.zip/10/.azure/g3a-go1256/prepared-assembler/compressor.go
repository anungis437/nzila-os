package main

import (
	"errors"
	"os"
	"os/exec"
	"path/filepath"
)

func compressStaged(raw []byte, compressor, work string) ([]byte, error) {
	binary, err := os.ReadFile(compressor)
	if err != nil {
		return nil, err
	}
	if hash(binary) != "378bacae9bd14e6d2c428fb52ea537ae06bedae01392849293ba9863eb62f95c" {
		return nil, errors.New("PROVEN_COMPRESSOR_BINARY_SHA_REQUIRED")
	}
	rawDigest := hash(raw)
	expected := map[string]string{
		"000cdf8c38857aab9b5a16244b98eb8f6017bf251f064c124622633c8850fc38": "e384c980a44e96f09d36cc4e6ffb44b4d7e03af6a75af1bd283c8cd9543aace7",
		"622d4366d78c36ca5ca6086e93b66d93305e0e11b95941375c1c4ff1f51cdfa1": "af22bfbdda5d1f2c63684516b52acd617cd5913c758d117c044121992d67bb2d",
	}[rawDigest]
	if expected == "" {
		return nil, errors.New("GENERATED_TAR_NOT_FROZEN_EXACT_INPUT")
	}
	input := filepath.Join(work, rawDigest+".tar")
	output := filepath.Join(work, rawDigest+".gz")
	if err := exclusive(input, raw, 0600); err != nil {
		return nil, err
	}
	command := exec.Command(compressor, input, rawDigest, output, expected)
	command.Env = []string{"PATH=/unavailable", "HOME=" + work}
	command.Stdout, command.Stderr = os.Stdout, os.Stderr
	if err := command.Run(); err != nil {
		return nil, err
	}
	compressed, err := os.ReadFile(output)
	if err != nil {
		return nil, err
	}
	if hash(compressed) != expected {
		return nil, errors.New("PROVEN_COMPRESSOR_OUTPUT_SHA_MISMATCH")
	}
	return compressed, nil
}
