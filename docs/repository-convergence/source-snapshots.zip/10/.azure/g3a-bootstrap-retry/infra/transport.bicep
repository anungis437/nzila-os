param suffix string
param cidr string
param producerPrincipalId string
param producerIPv4 string
param tags object

var prefix = 'g3fb-${suffix}'
var vmPrefix = '${split(cidr, '.')[0]}.${split(cidr, '.')[1]}.${split(cidr, '.')[2]}.0/27'
var pePrefix = '${split(cidr, '.')[0]}.${split(cidr, '.')[1]}.${split(cidr, '.')[2]}.32/27'

resource nsg 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: '${prefix}-nsg'
  location: 'canadacentral'
  tags: tags
  properties: {
    securityRules: [
      {
        name: 'DenyAllInbound'
        properties: {
          priority: 100
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
        }
      }
    ]
  }
}

resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' = {
  name: '${prefix}-vnet'
  location: 'canadacentral'
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: [
        cidr
      ]
    }
    subnets: [
      {
        name: 'vm'
        properties: {
          addressPrefix: vmPrefix
          networkSecurityGroup: {
            id: nsg.id
          }
          defaultOutboundAccess: true
        }
      }
      {
        name: 'pe'
        properties: {
          addressPrefix: pePrefix
          privateEndpointNetworkPolicies: 'Disabled'
        }
      }
    ]
  }
}

resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: 'nzilag3fb${suffix}'
  location: 'canadacentral'
  tags: tags
  kind: 'StorageV2'
  sku: {
    name: 'Standard_LRS'
  }
  properties: {
    accessTier: 'Hot'
    supportsHttpsTrafficOnly: true
    minimumTlsVersion: 'TLS1_2'
    allowSharedKeyAccess: false
    allowBlobPublicAccess: false
    publicNetworkAccess: 'Enabled'
    networkAcls: {
      bypass: 'None'
      defaultAction: 'Deny'
      ipRules: [
        {
          action: 'Allow'
          value: producerIPv4
        }
      ]
      virtualNetworkRules: []
    }
  }
}

resource blob 'Microsoft.Storage/storageAccounts/blobServices@2023-05-01' = {
  parent: storage
  name: 'default'
  properties: {
    isVersioningEnabled: true
  }
}

resource container 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-05-01' = {
  parent: blob
  name: 'bootstrap-proof'
  properties: {
    publicAccess: 'None'
  }
}

resource identity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: '${prefix}-reader'
  location: 'canadacentral'
  tags: tags
}

resource writer 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(container.id, producerPrincipalId, 'ba92f5b4-2d11-453d-a403-e96b0029c9fe', suffix)
  scope: container
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'ba92f5b4-2d11-453d-a403-e96b0029c9fe')
    principalId: producerPrincipalId
    principalType: 'User'
  }
}

resource reader 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(container.id, identity.id, '2a2b9908-6ea1-4ae2-8e65-a410df84e7d1', suffix)
  scope: container
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '2a2b9908-6ea1-4ae2-8e65-a410df84e7d1')
    principalId: identity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

resource zone 'Microsoft.Network/privateDnsZones@2020-06-01' = {
  name: 'privatelink.blob.${environment().suffixes.storage}'
  location: 'global'
  tags: tags
}

resource link 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2020-06-01' = {
  parent: zone
  name: '${prefix}-link'
  location: 'global'
  tags: tags
  properties: {
    registrationEnabled: false
    virtualNetwork: {
      id: vnet.id
    }
  }
}

resource endpoint 'Microsoft.Network/privateEndpoints@2024-05-01' = {
  name: '${prefix}-blob-pe'
  location: 'canadacentral'
  tags: tags
  properties: {
    subnet: {
      id: '${vnet.id}/subnets/pe'
    }
    privateLinkServiceConnections: [
      {
        name: 'blob'
        properties: {
          privateLinkServiceId: storage.id
          groupIds: [
            'blob'
          ]
        }
      }
    ]
  }
}

resource group 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2024-05-01' = {
  parent: endpoint
  name: 'blob'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'blob'
        properties: {
          privateDnsZoneId: zone.id
        }
      }
    ]
  }
}

output bindings object = {
  storageId: storage.id
  storageName: storage.name
  blobHost: '${storage.name}.blob.${environment().suffixes.storage}'
  identityId: identity.id
  identityClientId: identity.properties.clientId
  identityPrincipalId: identity.properties.principalId
  producerRoleId: writer.id
  readerRoleId: reader.id
  containerId: container.id
  nsgId: nsg.id
  subnetId: '${vnet.id}/subnets/vm'
  endpointId: endpoint.id
  zoneId: zone.id
  vnetId: vnet.id
}
