targetScope = 'subscription'

param resourceGroupName string
param suffix string
param cidr string
param producerPrincipalId string
param producerIPv4 string
param tags object

resource rg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: resourceGroupName
  location: 'canadacentral'
  tags: tags
}

module transport 'transport.bicep' = {
  name: 'g3-firstbyte-transport-${suffix}'
  scope: rg
  params: {
    suffix: suffix
    cidr: cidr
    producerPrincipalId: producerPrincipalId
    producerIPv4: producerIPv4
    tags: tags
  }
}

output transportBindings object = transport.outputs.bindings
