"""Exclusive source generation, preserving both historical sources and first FAIL report."""

import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
LANE = HERE.parent
OWNED = LANE.parent.parent
FOREIGN = Path(r"C:\APPS\nzila-os")
QUALIFIED = LANE.parent / "g3a-isolation-artifacts"
CAPACITY = LANE.parent / "g3a-hard-capacity"


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def baseline():
    values = {}
    for name, root, expected in (
        ("owned", OWNED, "7bec20aad11d43eeae8099c14e021b3074154b27"),
        ("foreign", FOREIGN, "1c337567635bb86ea0df7831557d8d2d22df1e6f"),
    ):
        head = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"]).decode().strip()
        if head != expected:
            raise RuntimeError("HEAD_CHANGED_" + name)
        statuses = subprocess.check_output(["git", "-C", str(root), "status", "--porcelain=v1", "-z"])
        values[name] = {"head": head, "count": statuses.count(b"\0"), "statusSha256": hashlib.sha256(statuses).hexdigest()}
    if values["owned"]["count"] != 2:
        raise RuntimeError("BASELINE_CHANGED")
    if sha(LANE / "PARENT_INTEGRATION_REPORT.json") != "5d7feb7f3bde66f00e62803a8fe0dd7ca43dc6e354d54d77fd8860346946325e":
        raise RuntimeError("FIRST_FAIL_REPORT_CHANGED")
    if sha(LANE.parent / "g3a-isolation-live" / "ISOLATION_VERIFICATION.json") != "ef348fa762c5e62a73ace8a26a95cb4e5427fa36677ce437a0d0c6dcc4890bae":
        raise RuntimeError("LIVE_SEAL_CHANGED")
    return values


def fresh(name, raw):
    baseline()
    with (HERE / name).open("xb") as output:
        output.write(raw.encode() if isinstance(raw, str) else raw)


def main():
    initial = baseline()
    protected = {}
    for path in LANE.iterdir():
        if path.is_file():
            protected[str(path)] = sha(path)
    binding = json.loads((QUALIFIED / "SOURCE_BINDING.json").read_text())
    for name, expected in binding["sourceFileHashes"].items():
        path = QUALIFIED / name
        if sha(path) != expected:
            raise RuntimeError("QUALIFIED_SOURCE_CHANGED_" + name)
        protected[str(path)] = expected
    for path in (
        QUALIFIED / "SOURCE_BINDING.json", QUALIFIED / "payload.tar",
        LANE.parent / "g3a-isolation-live" / "ISOLATION_VERIFICATION.json",
        CAPACITY / "HARD_BOUND_ACCEPTANCE.json", CAPACITY / "EFFECTIVE_LIMITS.json",
        CAPACITY / "rehearsal-resume" / "GUEST_OFFLINE_RAW.json",
        LANE.parent / "g3a-controller-repair" / "inputs" / "binding.json",
    ):
        protected[str(path)] = sha(path)
    proof = (QUALIFIED / "proof_linux.go").read_text()
    child = proof[proof.index("func isolatedProofChild()"):proof.index("\nfunc disconnectedRoutes(")]
    child = child.replace("func isolatedProofChild()", "func productionChild()", 1)
    child = child.replace('\tr := newResult()', '\tr := newResult()\n\tr.Mode = "--production"', 1)
    child = child.replace("io.LimitReader(f, 8192)", "io.LimitReader(f, 32768)", 1)
    child = child.replace("\tif os.Geteuid() != 0 {", """\tproductionPlan, productionErr := validatedChildPlan(plan)
\tif productionErr != nil {
\t\tfail(&r, "productionAuthority", productionErr.Error())
\t\treturn
\t}
\tevidenceFD := os.NewFile(5, "bounded-evidence-pipe")
\tif evidenceFD == nil {
\t\tfail(&r, "productionEvidence", "EVIDENCE_PIPE_MISSING")
\t\treturn
\t}
\tdefer evidenceFD.Close()
\tevidenceStat, evidenceErr := evidenceFD.Stat()
\tif evidenceErr != nil || evidenceStat.Mode()&os.ModeNamedPipe == 0 {
\t\tfail(&r, "productionEvidence", "EVIDENCE_NOT_PIPE")
\t\treturn
\t}
\tsyscall.CloseOnExec(5)
\tif os.Geteuid() != 0 {""", 1)
    child = child.replace('\tro := filepath.Join(root, "runtime")', """\tif err = stageProductionMounts(root, productionPlan); err != nil {
\t\tfail(&r, "productionMounts", err.Error())
\t\treturn
\t}
\tro := filepath.Join(root, "runtime")""", 1)
    child = child.replace('\tr.Checks["selfContained"], r.Outcome = "PASS", "PASS"', """\tif err = invokeProductionCore(productionPlan, &r, evidenceFD); err != nil {
\t\tfail(&r, "productionDispatch", err.Error())
\t\treturn
\t}
\tr.Checks["selfContained"], r.Outcome = "PASS", "PASS" """.rstrip(), 1)
    # Original declarations, imports, inline isolation and failure handling remain untouched.
    fresh("proof_linux.go", (proof + "\n" + child + "\n").encode())
    launcher = (QUALIFIED / "launcher.go").read_text()
    launcher = launcher.replace("func main() {", """func main() {
\tif len(os.Args) == 2 && os.Args[1] == "--production" {
\t\tif err := runProduction(os.Stdin); err != nil {
\t\t\tfmt.Fprintln(os.Stderr, err)
\t\t\tos.Exit(1)
\t\t}
\t\treturn
\t}
\tif len(os.Args) == 2 && os.Args[1] == "--_isolated-production-child" {
\t\tos.Exit(productionChild())
\t}""", 1)
    fresh("launcher.go", launcher)
    fresh("census.go", (QUALIFIED / "census.go").read_bytes())
    inputs = json.loads((LANE.parent / "g3a-controller-repair" / "inputs" / "binding.json").read_text())["inputs"]
    inputs_sha = hashlib.sha256(json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    outputs = json.loads((CAPACITY / "HARD_BOUND_ACCEPTANCE.json").read_text())["exactImageGates"]
    definitions = 'package main\n\ntype frozenInput struct { Bytes int64; SHA string }\n'
    definitions += f'\nconst frozenInputSpecSHA256 = "{inputs_sha}"\n\nvar frozenInputs = map[string]frozenInput{{\n'
    for name, value in sorted(inputs.items()):
        definitions += f'\t"{name}": {{{value["bytes"]}, "{value["sha256"]}"}},\n'
    definitions += '}\n\nvar exactOutputs = map[string]string{\n'
    for value in outputs.values():
        definitions += f'\t"{value["file"]}": "{value["sha256"]}",\n'
    definitions += '}\n'
    fresh("frozen_bindings.go", definitions)
    fresh("PROTECTED_REFERENCES.json", json.dumps({"initialBaseline": initial, "hashes": protected}, indent=2) + "\n")
    print(json.dumps({"generated": ["proof_linux.go", "launcher.go", "census.go", "frozen_bindings.go"],
                      "frozenInputSpecSha256": inputs_sha, "protectedReferenceCount": len(protected)}))


if __name__ == "__main__":
    main()
