//go:build linux && amd64

package main

import (
	"archive/tar"
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"testing"
)

type forbiddenReader struct{}

func (forbiddenReader) Read([]byte) (int, error) {
	panic("production default must deny before reading any payload")
}

func TestActualProductionEntrypointDeniedBeforeInputOrBackend(t *testing.T) {
	err := runProduction(forbiddenReader{})
	if err == nil || err.Error() != "FUTURE_EXECUTION_AUTHORITY_DIGEST_REQUIRED" {
		t.Fatal("actual entrypoint enabled", err)
	}
}

func localFixture(t *testing.T) string {
	t.Helper()
	path, err := os.MkdirTemp(".", ".source-test-")
	if err != nil {
		t.Fatal(err)
	}
	path, err = filepath.Abs(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		_ = os.Chmod(path, 0700)
		_ = os.RemoveAll(path)
	})
	return path
}

func TestActualDurableReceiptConsumedOnceAndCannotMoveRoot(t *testing.T) {
	request, _ := fixture(t)
	root := localFixture(t)
	request["receiptRoot"] = root
	auth := request["authority"].(map[string]interface{})
	auth["receiptRoot"] = root
	pin, _ := authorityDigest(encode(t, auth))
	plan, err := validateRequest(encode(t, request), pin)
	if err != nil {
		t.Fatal(err)
	}
	if err = writeConsumedReceipt(plan); err != nil {
		t.Fatal(err)
	}
	first, err := os.ReadFile(receiptPath(plan))
	if err != nil {
		t.Fatal(err)
	}
	if writeConsumedReceipt(plan) == nil {
		t.Fatal("receipt reused")
	}
	second, _ := os.ReadFile(receiptPath(plan))
	if !bytes.Equal(first, second) {
		t.Fatal("receipt overwritten")
	}
	request["receiptRoot"] = localFixture(t)
	if _, err = validateRequest(encode(t, request), pin); err == nil {
		t.Fatal("ledger relocation bypassed consumption")
	}
}

func TestBoundedMountProductionConstructorUsesExactRequestedOptions(t *testing.T) {
	for _, c := range []limits{maxima, {8192, 2, 12288, 3}} {
		specs, err := boundedSpecs(c)
		if err != nil {
			t.Fatal(err)
		}
		var calls []string
		err = mountBoundedRoots("/source-only-root", c, func(source, target, kind string, flags uintptr, options string) error {
			if source != "none" || kind != "tmpfs" || flags != syscall.MS_NOSUID|syscall.MS_NODEV {
				t.Fatal("executable hard-bound mount flags changed")
			}
			calls = append(calls, filepath.Base(target)+":"+options)
			return nil
		})
		if err != nil || len(calls) != 2 || calls[0] != "build:"+specs[0].Options || calls[1] != "tmp:"+specs[1].Options {
			t.Fatal("implicit enlargement, missing mount, or option mismatch", err, calls)
		}
	}
}

func TestBoundedMountFailureNoRetryOrExpansion(t *testing.T) {
	calls := 0
	err := mountBoundedRoots("/source-only-root", maxima, func(string, string, string, uintptr, string) error {
		calls++
		return syscall.ENOSPC
	})
	if !errors.Is(err, syscall.ENOSPC) || calls != 1 {
		t.Fatal("mount failure retried or expanded")
	}
	c := maxima
	c.TmpBytes++
	calls = 0
	if mountBoundedRoots("/source-only-root", c, func(string, string, string, uintptr, string) error {
		calls++
		return nil
	}) == nil || calls != 0 {
		t.Fatal("bad capacity reached mount syscall")
	}
}

func testArchive(t *testing.T, name string, mode int64, kind byte, raw []byte, duplicate bool) []byte {
	t.Helper()
	var buffer bytes.Buffer
	writer := tar.NewWriter(&buffer)
	count := 1
	if duplicate {
		count = 2
	}
	for i := 0; i < count; i++ {
		header := &tar.Header{Name: name, Size: int64(len(raw)), Mode: mode, Typeflag: kind}
		if kind == tar.TypeSymlink {
			header.Size, header.Linkname, raw = 0, "/outside", nil
		}
		if err := writer.WriteHeader(header); err != nil {
			t.Fatal(err)
		}
		if _, err := writer.Write(raw); err != nil {
			t.Fatal(err)
		}
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	return buffer.Bytes()
}

func TestInputStagingDigestCensusTypeModeAndTraversalDenials(t *testing.T) {
	original := frozenInputs
	defer func() { frozenInputs = original }()
	content := []byte("source-only archive fixture; never executed")
	frozenInputs = map[string]frozenInput{"portable-assembler": {int64(len(content)), shaBytes(content)}}
	noopChown := func(string, int, int) error { return nil }
	for _, name := range []string{"tamper", "missing", "unexpected", "traversal", "symlink", "mode", "duplicate", "trailing"} {
		t.Run(name, func(t *testing.T) {
			member, mode, kind, raw := "portable-assembler", int64(0500), byte(tar.TypeReg), append([]byte(nil), content...)
			switch name {
			case "tamper":
				raw[0] ^= 1
			case "unexpected":
				member = "extra"
			case "traversal":
				member = "../escape"
			case "symlink":
				kind = tar.TypeSymlink
			case "mode":
				mode = 0700
			}
			archive := testArchive(t, member, mode, kind, raw, name == "duplicate")
			if name == "missing" {
				archive = make([]byte, 1024)
			}
			if name == "trailing" {
				archive = append(archive, 1)
			}
			path := localFixture(t)
			if err := extractFrozenArchive(bytes.NewReader(archive), path, noopChown); err == nil {
				t.Fatal("bad input archive accepted")
			}
		})
	}
	path := localFixture(t)
	archive := testArchive(t, "portable-assembler", 0500, tar.TypeReg, content, false)
	if err := extractFrozenArchive(bytes.NewReader(archive), path, noopChown); err != nil {
		t.Fatal(err)
	}
}

func TestCleanupCanEmptyReadonlyOwnedInputDirectory(t *testing.T) {
	build, temporary := localFixture(t), localFixture(t)
	input := filepath.Join(build, ".inputs")
	if err := os.Mkdir(input, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(input, "fixture"), []byte("source-only"), 0400); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(input, 0500); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(temporary, "fixture"), []byte("source-only"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := emptyRoots(build, temporary); err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{build, temporary} {
		entries, err := os.ReadDir(path)
		if err != nil || len(entries) != 0 {
			t.Fatal("root not emptied", err)
		}
	}
}

func TestOutputEvidenceRegularOnlyAndBoundedWriter(t *testing.T) {
	path := localFixture(t)
	if err := os.WriteFile(filepath.Join(path, "fixture.txt"), []byte("source-only"), 0600); err != nil {
		t.Fatal(err)
	}
	var buffer bytes.Buffer
	hash, err := exportOutputArchive(&buffer, path)
	if err != nil || hash != shaBytes(buffer.Bytes()) {
		t.Fatal("evidence not hash-bound", err)
	}
	if err = os.Symlink("/outside", filepath.Join(path, "escape")); err != nil {
		t.Fatal(err)
	}
	if _, err = exportOutputArchive(&buffer, path); err == nil {
		t.Fatal("output symlink exported")
	}
	bound := &cappedBuffer{limit: 3}
	if _, err = bound.Write([]byte("abcd")); err == nil || bound.Len() != 0 {
		t.Fatal("bounded evidence writer overflowed")
	}
}

func TestNoCallerEnvironmentAuthorityOverride(t *testing.T) {
	t.Setenv("G3A_EXECUTION_AUTHORITY_SHA256", strings.Repeat("a", 64))
	t.Setenv("TRUSTED_EXECUTION_AUTHORITY_SHA256", strings.Repeat("a", 64))
	if runProduction(forbiddenReader{}) == nil {
		t.Fatal("environment enabled production")
	}
}
