"""Compile unit tests, not a candidate; never execute a production child or frozen core."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from prepare_revision import baseline, sha, HERE, LANE, QUALIFIED

GO = Path(r"C:\Program Files\Go\bin\go.exe")
IMAGE = "sha256:e88e9763f943ec1834f992a4b51e0f24500486803e8bc534e5767af9ea65f6ce"


def protected():
    hashes = json.loads((HERE / "PROTECTED_REFERENCES.json").read_text())["hashes"]
    for name, expected in hashes.items():
        if sha(Path(name)) != expected:
            raise RuntimeError("PROTECTED_REFERENCE_CHANGED_" + name)


def execute(command, cwd, env):
    before = baseline()
    protected()
    result = subprocess.run(list(map(str, command)), cwd=cwd, env=env, capture_output=True,
                            text=True, encoding="utf-8", errors="replace", timeout=300)
    return {"command": list(map(str, command)), "cwd": str(cwd), "exitCode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr,
            "beforeBaseline": before, "afterBaseline": baseline()}


def main():
    initial = baseline()
    protected()
    check = HERE / ".checks"
    baseline()
    check.mkdir(exist_ok=True)
    env = dict(os.environ, GOENV="off", GOTOOLCHAIN="local", GO111MODULE="off", CGO_ENABLED="0")
    for variable, name in (("GOCACHE", "cache"), ("GOPATH", "gopath"),
                           ("GOTMPDIR", "go-work"), ("TEMP", "host-work"), ("TMP", "host-work")):
        path = check / name
        baseline()
        path.mkdir(exist_ok=True)
        env[variable] = str(path)
    results = []
    results.append(execute([GO, "test", "-v", "dispatch.go", "frozen_bindings.go", "dispatch_test.go"], HERE, env))
    results.append(execute([GO, "run", "verify_primitives.go", "--",
                            QUALIFIED / "proof_linux.go", HERE / "proof_linux.go",
                            QUALIFIED / "launcher.go", HERE / "launcher.go",
                            HERE / "production_linux.go"], HERE, env))
    stage = check / "linux-source-tests"
    baseline()
    stage.mkdir(exist_ok=True)
    for name in ("dispatch.go", "dispatch_test.go", "frozen_bindings.go", "launcher.go",
                 "proof_linux.go", "census.go", "production_linux.go", "production_linux_test.go"):
        baseline()
        shutil.copyfile(HERE / name, stage / name)
    baseline()
    (stage / "payload.tar").write_bytes(b"")
    baseline()
    (stage / "fixtures").mkdir(exist_ok=True)
    linux_env = dict(env, GOOS="linux", GOARCH="amd64")
    compile_result = execute([GO, "test", "-c", "-o", stage / "runner-source-tests"], stage, linux_env)
    results.append(compile_result)
    if compile_result["exitCode"] == 0:
        results.append(execute(["docker", "run", "--rm", "--pull", "never", "--network", "none",
                                "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                                "--mount", f"type=bind,source={stage},target=/source-tests,readonly",
                                "--tmpfs", "/source-tests/fixtures:rw,noexec,nosuid,nodev,size=1048576,nr_inodes=128,mode=0700",
                                "--workdir", "/source-tests/fixtures", IMAGE,
                                "/source-tests/runner-source-tests", "-test.v", "-test.timeout=60s"], HERE, env))
    protected()
    final = baseline()
    if initial["owned"] != final["owned"]:
        raise RuntimeError("OWNED_WORKTREE_STATUS_CHANGED")
    attempt = 1
    while (HERE / f"VALIDATION_ATTEMPT_{attempt}.json").exists():
        attempt += 1
    baseline()
    path = HERE / f"VALIDATION_ATTEMPT_{attempt}.json"
    with path.open("x", encoding="utf-8", newline="\n") as output:
        json.dump({"initialBaseline": initial, "finalBaseline": final,
                   "foreignStatusDriftObserved": initial["foreign"] != final["foreign"],
                   "foreignWritesByThisDriver": 0,
                   "testedSourceFileHashes": {name: sha(HERE / name) for name in (
                       "dispatch.go", "dispatch_test.go", "frozen_bindings.go", "launcher.go",
                       "proof_linux.go", "census.go", "production_linux.go", "production_linux_test.go",
                       "verify_primitives.go")},
                   "linuxUnitTestExecutableSha256": sha(stage / "runner-source-tests") if compile_result["exitCode"] == 0 else None,
                   "testOnlyEmbeddedPayloadBytes": 0, "candidateBuilt": False,
                   "frozenCoreInvocations": 0, "productionChildInvocations": 0,
                   "results": results}, output, indent=2)
        output.write("\n")
    for result in results:
        print(json.dumps({"command": result["command"], "exitCode": result["exitCode"]}))
        if result["exitCode"] != 0:
            print(result["stdout"])
            print(result["stderr"])
    print("EVIDENCE=" + str(path))
    return 0 if len(results) == 4 and all(result["exitCode"] == 0 for result in results) else 1


if __name__ == "__main__":
    sys.exit(main())
