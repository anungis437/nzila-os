"""Append a separate source-integration report; never replace the preserved first FAIL."""

from datetime import datetime, timezone
import ast
import hashlib
import json
from pathlib import Path
import shutil

from prepare_revision import baseline, sha, HERE, LANE, QUALIFIED
from validate_revision import protected


def fresh(path, value):
    baseline()
    protected()
    with path.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write("\n")


def main():
    start = baseline()
    protected()
    original_path = LANE / "PARENT_INTEGRATION_REPORT.json"
    original = json.loads(original_path.read_text())
    for name, expected in original["protectedReferenceHashes"].items():
        if sha(Path(name)) != expected:
            raise RuntimeError("FIRST_REPORT_PROTECTED_REFERENCE_CHANGED_" + name)
    authority = Path(original["authorityPath"])
    # Read the full governing authority, not an excerpt or helper summary.
    authority_text = authority.read_text(encoding="utf-8")
    if sha(authority) != original["authoritySha256"]:
        raise RuntimeError("LATEST_AUTHORITY_CHANGED")
    for source in HERE.glob("*.py"):
        ast.parse(source.read_text(), filename=str(source))
    latest = max(HERE.glob("VALIDATION_ATTEMPT_*.json"), key=lambda path: int(path.stem.rsplit("_", 1)[1]))
    results = json.loads(latest.read_text())
    if len(results["results"]) != 4 or any(item["exitCode"] != 0 for item in results["results"]):
        raise RuntimeError("SOURCE_INTEGRATION_TESTS_NOT_ALL_PASS")
    for name, expected in results["testedSourceFileHashes"].items():
        if sha(HERE / name) != expected:
            raise RuntimeError("SOURCE_CHANGED_AFTER_TESTS_" + name)
    if not (HERE / "proof_linux.go").read_bytes().startswith((QUALIFIED / "proof_linux.go").read_bytes()):
        raise RuntimeError("QUALIFIED_SOURCE_PREFIX_CHANGED")
    inputs_root = LANE.parent / "g3a-controller-repair" / "inputs"
    input_binding = json.loads((inputs_root / "binding.json").read_text())["inputs"]
    for name, expected in input_binding.items():
        path = inputs_root / name
        if path.stat().st_size != expected["bytes"] or sha(path) != expected["sha256"]:
            raise RuntimeError("FROZEN_INPUT_CHANGED_" + name)
    matrix = json.loads(results["results"][1]["stdout"])
    if not all(row["equivalent"] and row["qualifiedSha256"] == row["productionSha256"]
               for row in matrix["primitiveMatrix"]):
        raise RuntimeError("PRIMITIVE_DRIFT")
    fresh(HERE / "PRIMITIVE_EQUIVALENCE_MATRIX.json", matrix)
    source_names = sorted(path.name for path in HERE.iterdir() if path.suffix in {".go", ".py", ".md"})
    source_binding = {
        "schema": "g3a-hard-runner-source-revision/v1",
        "sources": {name: sha(HERE / name) for name in source_names},
        "qualifiedSourcePrefixPreserved": True,
        "qualifiedRuntimePayloadSha256": sha(QUALIFIED / "payload.tar"),
        "frozenInputCensusCanonicalSha256": hashlib.sha256(
            json.dumps(input_binding, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "candidateBuilt": False, "candidateBinding": "NOT_CREATED",
    }
    source_binding["sourceManifestSha256"] = hashlib.sha256(
        json.dumps(source_binding["sources"], sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    fresh(HERE / "REVISION_SOURCE_BINDING.json", source_binding)
    commands = []
    for item in results["results"]:
        commands.append({
            "command": item["command"], "cwd": item["cwd"], "result": "PASS", "exitCode": item["exitCode"],
            "passedTestsAndSubtests": item["stdout"].count("--- PASS:"),
            "passedTopLevelTests": sum(line.startswith("--- PASS:") for line in item["stdout"].splitlines()),
        })
    evidence = {path.name: sha(path) for path in HERE.glob("*.json")}
    report = {
        "schema": "g3a-revised-source-production-integration/v1",
        "utc": datetime.now(timezone.utc).isoformat(),
        "mission": "NZ-20261008-INFRA-001", "gate": "G3_PRIVATE_APPLICATION_SUBSTRATE",
        "integration": "PASS",
        "disposition": "SOURCE_ONLY_PRIMITIVE_EQUIVALENCE_COMPILED_PRODUCTION_WIRING_AND_DISPATCH_DENIALS",
        "offlinePASS": False, "offlineRunnerQualification": "NOT_RUN",
        "newRunnerKernelOrFrozenCoreProof": "NOT_RUN",
        "candidateBinding": "NOT_CREATED", "productionExecutionAuthority": "ABSENT",
        "productionDispatch": "FAIL_CLOSED_EMPTY_COMPILE_TIME_FUTURE_AUTHORITY_DIGEST",
        "sourceLane": str(HERE),
        "authorityPath": str(authority), "authoritySha256": sha(authority),
        "fullAuthorityCharactersRead": len(authority_text),
        "authorityInterpretation": "Sections 18/19 permit orchestration delta; only listed primitive identities/order/error handling/locking are invariants.",
        "firstReport": {
            "path": str(original_path), "sha256": sha(original_path), "preserved": True,
            "historicalDisposition": "FAIL", "interpretationSuperseded": True,
            "correction": "Whole isolatedProofChild AST immutability was an overconstraint, not a genuine listed-primitive blocker.",
        },
        "primitiveEquivalence": matrix,
        "sourceBinding": source_binding,
        "sourceChanges": [
            {"path": str(HERE / name), "sha256": source_binding["sources"][name], "change": "ADDITIONAL_REVISION_FILE"}
            for name in source_names
        ],
        "productionIntegration": {
            "actualEntry": "launcher.main --production -> runProduction -> dispatchProduction -> validate/prepare/consume/launch",
            "actualChild": "launcher.main --_isolated-production-child -> productionChild -> unchanged primitives -> invokeProductionCore -> effective/device gates -> exact frozen assembler",
            "futureAuthoritySchema": "g3a-execution-authority/v2",
            "authorityBinds": ["mission", "transaction", "payloadSha256", "capacity", "inputRoot", "receiptRoot", "consumed"],
            "callerAuthorityDigestOrEnvironmentOverride": "DENIED",
            "consumption": "O_EXCL private-root receipt, file and directory fsync, no rollback or automatic retry",
            "capacityModel": "ENFORCED_HARD_LIMIT",
            "buildMaximum": {"bytes": 1073741824, "inodes": 32768},
            "tmpMaximum": {"bytes": 268435456, "inodes": 4096},
            "lowerAuthorizedCapacities": "EXACTLY_RETAINED_NO_EXPANSION",
            "effectiveBeforeCore": "exact TMPFS type/bytes/inodes, positive bounded availability, rw/exec/nosuid/nodev",
            "workOutputFlags": "rw,noexec,nosuid,nodev",
            "outputEvidenceCeilingBytes": 67108864,
            "deviceAllowlist": ["/dev/null"], "procfs": "NONE", "randomDevices": "NONE",
            "inputLayout": "fixed 15 inputs charged beneath /build/.inputs; readonly alias /inputs",
            "fixedInputBytes": sum(value["bytes"] for value in input_binding.values()),
            "exactOutputGateCount": 7,
            "cleanup": "build/tmp emptying including staged input permissions; parent kills child process group; private namespace lifetimes",
            "automaticRetry": False,
        },
        "tests": {
            "evidence": str(latest), "sha256": sha(latest), "commands": commands,
            "actualDispatchBoundaryDenialsExercised": True,
            "actualPublicEntrypointEmptyPinDenialExercised": True,
            "helperOnlyAuthoritySuccessClaim": False,
            "realKernelMountsExecutedByRunnerTests": False,
            "realFrozenCoreExecutedByRunnerTests": False,
            "linuxUnitTestExecutableSha256": results["linuxUnitTestExecutableSha256"],
            "testOnlyEmbeddedPayloadBytes": 0,
            "developmentIssueResolved": "An added test was briefly nested incorrectly; gofmt rejected it, placement was fixed, and all final checks passed.",
            "validationAttempts": {path.name: sha(path) for path in HERE.glob("VALIDATION_ATTEMPT_*.json")},
        },
        "historicalParentHardBoundSuccess": {
            "reference": str(LANE.parent / "g3a-hard-capacity" / "HARD_BOUND_ACCEPTANCE.json"),
            "sha256": sha(LANE.parent / "g3a-hard-capacity" / "HARD_BOUND_ACCEPTANCE.json"),
            "parentVerifiedExactSuccess": True, "rerunByThisTask": False,
            "appliesToNewCombinedInputStagingLayout": False,
        },
        "remainingQualification": [
            "No production authority digest is issued or populated.",
            "No production candidate was built or runner-source/candidate binding created.",
            "The staged-input build layout and larger fixed output evidence ceiling are source additions, not newly kernel/runtime-qualified.",
            "Source/mocked mount and core-boundary tests do not prove an offline runner transaction succeeds.",
        ],
        "genuineListedPrimitiveBlocker": None,
        "protectedReferenceHashes": json.loads((HERE / "PROTECTED_REFERENCES.json").read_text())["hashes"],
        "originalProtectedReferenceHashes": original["protectedReferenceHashes"],
        "frozenInputHashesVerified": input_binding,
        "evidenceHashes": evidence,
        "rebaseline": {
            "originalCount": {"owned": 2, "foreign": 606}, "beforeReport": start,
            "foreignObservedCounts": [606, 609, 610],
            "foreignStatusDriftDisposition": "CONCURRENT_EXTERNAL_OBSERVATION_ONLY; no foreign/product writes",
            "headsUnchanged": True, "ownedCollapsedStatusesUnchanged": True,
        },
        "operationCounters": {
            "candidateBuilds": 0, "frozenCoreInvocations": 0, "productionChildInvocations": 0,
            "azureReads": 0, "azureMutations": 0, "registryOperations": 0,
            "foreignWrites": 0, "productWrites": 0, "historicalArtifactWrites": 0, "commits": 0,
            "linuxUnitTestExecutablesCompiled": 2, "linuxUnitTestExecutablesExecuted": 2,
        },
    }
    report_path = LANE / "REVISED_PARENT_INTEGRATION_REPORT.json"
    fresh(report_path, report)
    baseline()
    protected()
    check = HERE / ".checks"
    if check.exists():
        if check.parent != HERE:
            raise RuntimeError("CLEANUP_SCOPE_INVALID")
        shutil.rmtree(check)
    final = baseline()
    protected()
    final_record = {
        "reportPath": str(report_path), "reportSha256": sha(report_path),
        "finalBaseline": final, "sourceAndProtectedHashesVerified": True,
        "firstReportSha256": sha(original_path), "testIntermediatesRemoved": not check.exists(),
        "sourceIntegration": "PASS", "offlinePASS": False,
    }
    fresh(HERE / "FINAL_VERIFICATION.json", final_record)
    print(json.dumps(final_record, indent=2))


if __name__ == "__main__":
    main()
