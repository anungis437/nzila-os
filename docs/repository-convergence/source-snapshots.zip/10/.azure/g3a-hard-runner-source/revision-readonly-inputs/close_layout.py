"""Seal verified source/kernel evidence, preserve history, remove only owned test intermediates."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

from prepare_layout import baseline, fresh, protect, sha, HERE, ROOT, LANE, OLD, QUALIFIED


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    before = baseline()
    protect()
    attempt = HERE / "VALIDATION_ATTEMPT_4.json"
    validation = json.loads(attempt.read_text())
    results = validation["results"]
    require(len(results) == 6 and all(r["exitCode"] == 0 for r in results), "VALIDATION_NOT_ALL_PASS")
    for name, expected in validation["sourceHashes"].items():
        require(sha(HERE/name) == expected, "TESTED_SOURCE_CHANGED_"+name)
    matrix = json.loads(results[1]["stdout"])
    require(len(matrix["primitiveMatrix"]) == 30 and all(r["equivalent"] and
            r["qualifiedSha256"] == r["productionSha256"] for r in matrix["primitiveMatrix"]),
            "PRIMITIVE_EQUIVALENCE_NOT_THIRTY_PASS")
    require(matrix["originalStatementsPreservedInOrder"] == 97, "QUALIFIED_ORDER_DRIFT")
    require((HERE/"proof_linux.go").read_bytes().startswith((QUALIFIED/"proof_linux.go").read_bytes()),
            "QUALIFIED_PREFIX_CHANGED")
    reports = []
    marker = "G3A_KERNEL_STATIC_CONSTRUCTOR_WITNESS="
    for line in results[5]["stdout"].splitlines():
        if marker in line:
            reports.append(json.loads(line.split(marker, 1)[1]))
    require(len(reports) == 2, "KERNEL_CHILD_AND_PARENT_WITNESSES_REQUIRED")
    kernel = reports[-1]
    for key in ("parentMountInfoByteEquivalent", "namespaceProcessGone", "noSurvivingTransactionMounts",
                "parentOwnedRootRemoved", "publishedEntrypointDeniedWithoutReading",
                "directInputSameInodeBinding", "buildAndTmpInitiallyEmpty", "buildTmpEmptied",
                "outerInputsRevalidatedAfterCleanup", "readonlyRootRuntimeInputs", "hostTreeAbsent",
                "downLoopbackOnlyNoRoutes", "qualifiedTcpNegative", "exactNullOnlyDeviceAndNoProcChecks",
                "effectiveMismatchDeniedBeforeStaticBoundary", "dirtyBuildDeniedBeforeStaticBoundary"):
        require(kernel[key] is True, "KERNEL_CHECK_MISSING_"+key)
    require(kernel["frozenCoreInvocations"] == 0 and kernel["staticBoundaryInvocations"] == 1 and
            kernel["productionChildInvocations"] == 0 and kernel["inputStagingCopies"] == 0 and
            kernel["inputChargeToBuildBytes"] == 0 and kernel["inputEntries"] == 15 and
            kernel["inputBytes"] == 265077049, "WITNESS_SCOPE_OR_INPUT_LAYOUT_CHANGED")
    require(kernel["initialEffectiveLimits"] == kernel["finalEffectiveLimits"], "CLEANUP_DID_NOT_RESTORE_CAPACITY")
    for name, size, inodes in (("build", 1073741824, 32768), ("tmp", 268435456, 4096)):
        value = kernel["initialEffectiveLimits"][name]
        require(value["totalBytes"] == size and value["availableBytes"] == size and
                value["totalInodes"] == inodes and value["availableInodes"] == inodes-1 and
                value["filesystemType"] == 0x01021994 and value["mountFlags"] & 6 == 6 and
                value["mountFlags"] & 9 == 0, "KERNEL_CAPACITY_MISMATCH_"+name)
    require(kernel["execWitness"] == {"/build": "STATIC_UNIT_EXEC_PASS", "/tmp": "STATIC_UNIT_EXEC_PASS",
            "/work": "EACCES", "/output": "EACCES"}, "EXEC_NOEXEC_CONTRACT_MISMATCH")
    require('const trustedExecutionAuthoritySHA256 = ""' in (HERE/"dispatch.go").read_text(),
            "PRODUCTION_PIN_POPULATED")
    require(kernel["futureExecutionAuthorityIssued"] is False, "FUTURE_AUTHORITY_ISSUED")
    source_files = sorted(p for p in HERE.iterdir() if p.suffix in (".go", ".py", ".md"))
    changes = []
    for path in source_files:
        previous = OLD/path.name
        old = previous.read_text().splitlines(True) if previous.exists() else []
        changes += list(difflib.unified_diff(old, path.read_text().splitlines(True),
                        fromfile="historical-revision/"+path.name if old else "/dev/null",
                        tofile="revision-readonly-inputs/"+path.name))
    fresh("SOURCE_CHANGESET.diff", "".join(changes))
    fresh("PRIMITIVE_EQUIVALENCE_MATRIX.json", matrix)
    fresh("KERNEL_CONSTRUCTOR_WITNESS.json", kernel)
    binding = {
        "schema": "g3a-readonly-input-source-binding/v1",
        "sourceHashes": {p.name: sha(p) for p in source_files},
        "sourceChangeSetSha256": sha(HERE/"SOURCE_CHANGESET.diff"),
        "qualifiedSourcePrefixByteEquivalent": True,
        "primitiveMatrixSha256": sha(HERE/"PRIMITIVE_EQUIVALENCE_MATRIX.json"),
        "kernelWitnessSha256": sha(HERE/"KERNEL_CONSTRUCTOR_WITNESS.json"),
        "validationAttemptSha256": sha(attempt),
        "normalizedSourceAstPrimitiveIdentityRows": matrix["primitiveMatrix"],
    }
    fresh("SOURCE_BINDING.json", binding)
    checks = HERE/".checks"
    require(checks.resolve().parent == HERE.resolve() and not checks.is_symlink(), "OWNED_CLEANUP_BOUNDARY")
    baseline()
    protect()
    shutil.rmtree(checks)
    require(not checks.exists(), "OWNED_TEST_INTERMEDIATES_SURVIVED")
    summaries = []
    for index in (0, 4, 5):
        result = results[index]
        summaries.append({
            "scope": ("portable production-dispatch denies", "Linux source/real-entrypoint denies",
                      "actual kernel constructor/static boundary")[index if index == 0 else index-3],
            "command": result["command"], "exitCode": result["exitCode"],
            "passTestsAndSubtests": len(re.findall(r"^\s*--- PASS:", result["stdout"], re.M)),
            "skippedTests": len(re.findall(r"^\s*--- SKIP:", result["stdout"], re.M)),
            "stdoutSha256": hashlib.sha256(result["stdout"].encode()).hexdigest(),
        })
    report = {
        "schema": "g3a-rehearsal-aligned-source-integration/v1",
        "mission": "NZ-20261008-INFRA-001", "scope": "SOURCE_AND_STATIC_LOCAL_KERNEL_CONSTRUCTOR_ONLY",
        "integration": "PASS", "sourceIntegration": "PASS", "staticKernelConstructorWitness": "PASS",
        "productionCapacityGate": "PASS_SOURCE_DENIALS_AND_ACTUAL_KERNEL_MISMATCH_DENIAL",
        "productionExecutionFailClosed": "PASS_ACTUAL_RUNPRODUCTION_DENIAL_BEFORE_READ",
        "qualifiedPrimitivesUnchanged": "YES", "primitiveEquivalenceRows": 30,
        "qualifiedStatementsRetainedInOrder": 97, "wholeOrchestrationEquivalenceRequired": False,
        "sourceBindingPath": str(HERE/"SOURCE_BINDING.json"), "sourceBindingSha256": sha(HERE/"SOURCE_BINDING.json"),
        "sourceHashes": binding["sourceHashes"], "normalizedPrimitiveBindings": matrix["primitiveMatrix"],
        "sourceChanges": {
            "dispatch.go": "Signed canonical transaction-specific sibling inputs/receipts paths; original strict authority/capacity gates retained",
            "production_linux.go": "Exact regular/no-symlink fifteen-file census with bounded O_NOFOLLOW hashes; canonical private controller-owned transaction boundary; kernel-readonly external inputRoot; direct readonly /inputs bind; no tar input pipe/copy; one O_EXCL durable transaction receipt across pins; evidence fd4; actual constructed-core gate revalidates inputs/effective limits/device/empty transaction and empties build/tmp",
            "proof_linux.go": "Qualified exact byte prefix and all 97 original inline statements retained; permitted production evidence fd5->fd4 only; no isolation primitive changes",
            "launcher.go,census.go,frozen_bindings.go": "Byte-identical to preceding revision",
            "verify_primitives.go": "Same thirty primitive comparisons; only authorized evidence-FD and constructed-gate wiring location updated",
            "*_test.go": "Full dispatch/capacity/authority/root denials; actual durable cross-pin receipt; regular/hash/no-symlink input checks; actual constructor and gate syscalls with isolated static unit-test boundary",
            "prepare_layout.py,validate_layout.py,close_layout.py,README.md": "Exclusive generation, before-write rebaselines, preserved-byte guards, bounded local validation, exact on-disk fixture projection and reproducible closure",
        },
        "inputLayout": {
            "contract": "external transaction-owned immutable inputRoot readonly-bound at /inputs",
            "signedInputRootPattern": "<private-root>/.g3a-transaction-<transaction>/inputs",
            "signedReceiptRootPattern": "<same-transaction-boundary>/receipts",
            "frozenInputEntries": 15, "frozenInputBytes": 265077049,
            "frozenInputSpecSha256": "247cd5aed0a3154891a5f966992c10e6a6d319c0f1554887c99aaa3f3c3572d3",
            "productionInputCopies": 0, "inputChargeToBuildBytes": 0, "memoryTmpfsInputStagingCopies": 0,
            "buildTransactionBeforeCore": "ABSENT_AND_NO_PREEXISTING_TRANSACTION_FILES",
            "noHostTreeExposure": "Only exact fifteen-file directory bound; original host paths absent; no external file descriptors supplied to core",
            "immutabilityBoundary": "Kernel-readonly source alias plus private controller-owned boundary; trusted outer owner must preserve backing bytes against privileged host mutation; exact hashes rechecked after binding, before static core and after cleanup",
            "testFixturePreparation": validation["outerInputFixturePreparation"],
        },
        "effectiveCapacity": kernel["initialEffectiveLimits"], "kernelWitness": kernel,
        "tests": summaries, "allValidationCommands": [{"command": r["command"], "exitCode": r["exitCode"]} for r in results],
        "validationAttemptPath": str(attempt), "validationAttemptSha256": sha(attempt),
        "diagnosticsPreserved": [
            {"attempt": 1, "cause": "New device constructor err variable lost its previous input-pipe declaration; fixed local declaration; no kernel/core invoked"},
            {"attempt": 2, "cause": "Strict census rejected original sixteen-entry source directory including binding.json; historical bytes preserved; fifteen-input outer on-disk fixture prepared"},
            {"attempt": 3, "cause": "Test container cap-drop ALL omitted SYS_CHROOT; actual constructor/effective limits already passed, chroot EPERM; test-only explicit capability corrected"},
            {"attempt": 4, "cause": "All six validation commands PASS; actual kernel static constructor/gate/cleanup witness PASS"},
        ],
        "rehearsalBinding": {
            "historicalStatus": "PARENT_VERIFIED_HARD_BOUNDED_EXACT_CORE_PASS_REUSED_NOT_RERUN",
            "historicalReportPath": str(ROOT/".azure/g3a-hard-capacity/HARD_BOUND_ACCEPTANCE.json"),
            "historicalReportSha256": sha(ROOT/".azure/g3a-hard-capacity/HARD_BOUND_ACCEPTANCE.json"),
            "historicalRawEvidenceSha256": sha(ROOT/".azure/g3a-hard-capacity/rehearsal-resume/GUEST_OFFLINE_RAW.json"),
            "appliesToRehearsedSeparatelyReadonlyBoundInputLayout": True,
            "appliesToRejectedCombinedBuildInputStagingLayout": False,
            "exactFifteenFrozenInputHashesUnchanged": True, "frozenCoreInvocationsThisFollowup": 0,
            "staticWitnessIsNotExactCoreOrFinalRunnerRuntimeProof": True,
        },
        "productionRunnerOfflineQualification": "NOT_CLAIMED_BY_THIS_SOURCE_ONLY_FOLLOWUP",
        "offlinePASS": False, "candidateBuilt": False, "candidateBinding": "NOT_CREATED",
        "runtimeProofClaimed": False, "productionChildInvocations": 0, "futureExecutionAuthorityIssued": False,
        "trustedExecutionAuthorityDigest": "", "publishedProductionEntryRemainsDisabled": True,
        "unitTestExecutableHashesBeforeOwnedCleanup": validation["unitTestExecutableHashes"],
        "priorReportsPreserved": {p.name: sha(p) for p in (
            LANE/"PARENT_INTEGRATION_REPORT.json", LANE/"REVISED_PARENT_INTEGRATION_REPORT.json")},
        "allHistoricalBytesVerified": True, "ownedTestIntermediatesRemoved": True,
        "beforeBaseline": before, "afterBaseline": baseline(),
        "foreignWrites": 0, "productWrites": 0, "cloudReads": 0, "cloudMutations": 0, "registryCalls": 0, "commits": 0,
    }
    fresh(r"..\FINAL_READONLY_INPUT_PARENT_INTEGRATION_REPORT.json", report)
    protect()
    final = LANE/"FINAL_READONLY_INPUT_PARENT_INTEGRATION_REPORT.json"
    fresh("FINAL_VERIFICATION.json", {
        "status": "PASS_SOURCE_BINDINGS_KERNEL_EVIDENCE_HISTORICAL_BYTES_AND_OWNED_CLEANUP",
        "parentReportSha256": sha(final), "sourceBindingSha256": sha(HERE/"SOURCE_BINDING.json"),
        "baseline": baseline(), "oldBytesPreserved": True, "checksAbsent": not checks.exists(),
    })
    print("FINAL_PARENT_REPORT="+str(final))
    print("FINAL_PARENT_REPORT_SHA256="+sha(final))
    print("INTEGRATION=PASS_SOURCE_AND_STATIC_KERNEL_CONSTRUCTOR")
    print("FROZEN_CORE_INVOCATIONS=0; CANDIDATE_BUILT=NO; PRODUCTION_AUTHORITY_ABSENT")


if __name__ == "__main__":
    main()
