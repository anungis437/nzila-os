//go:build linux && amd64

package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"testing"
	"time"
)

const kernelMarker = "G3A_KERNEL_STATIC_CONSTRUCTOR_WITNESS="

func TestKernelConstructorWitness(t *testing.T) {
	if os.Getenv("G3A_KERNEL_WITNESS") != "1" {
		t.Skip("separate bounded kernel-witness invocation required")
	}
	if trustedExecutionAuthoritySHA256 != "" {
		t.Fatal("witness must not have future production authority")
	}
	TestActualProductionEntrypointDeniedBeforeInputOrBackend(t)
	before, err := os.ReadFile("/proc/self/mountinfo")
	if err != nil {
		t.Fatal(err)
	}
	boundary := filepath.Join(localFixture(t), ".g3a-transaction-KERNEL_STATIC_ONLY")
	for _, name := range []string{"inputs", "receipts"} {
		if err = os.MkdirAll(filepath.Join(boundary, name), 0700); err != nil {
			t.Fatal(err)
		}
	}
	proof := localFixture(t)
	ctx, cancel := context.WithTimeout(context.Background(), 75*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestKernelConstructorChild$", "-test.v", "-test.timeout=70s")
	cmd.Env = []string{"PATH=/unavailable", "HOME=/unavailable", "G3A_KERNEL_WITNESS_CHILD=1",
		"G3A_KERNEL_TX_ROOT=" + boundary, "G3A_KERNEL_PROOF_ROOT=" + proof}
	cmd.Dir = proof
	cmd.Stdin = bytes.NewReader(nil)
	stdout, stderr := &cappedBuffer{limit: 2 * 1024 * 1024}, &cappedBuffer{limit: 1024 * 1024}
	cmd.Stdout, cmd.Stderr = stdout, stderr
	cmd.SysProcAttr = &syscall.SysProcAttr{Cloneflags: syscall.CLONE_NEWNS | syscall.CLONE_NEWNET,
		Pdeathsig: syscall.SIGKILL, Setpgid: true}
	cmd.Cancel = func() error { return syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL) }
	cmd.WaitDelay = 2 * time.Second
	err = cmd.Run()
	if cmd.Process != nil {
		groupErr := syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL)
		if groupErr != nil && !errors.Is(groupErr, syscall.ESRCH) {
			t.Fatal("group cleanup", groupErr)
		}
	}
	t.Log("kernel child stdout:\n" + stdout.String())
	if err != nil {
		t.Fatalf("actual constructor witness failed: %v\n%s", err, stderr.String())
	}
	var report map[string]interface{}
	for _, line := range strings.Split(stdout.String(), "\n") {
		if strings.HasPrefix(line, kernelMarker) {
			if err = json.Unmarshal([]byte(strings.TrimPrefix(line, kernelMarker)), &report); err != nil {
				t.Fatal(err)
			}
		}
	}
	if report == nil || report["scope"] != "STATIC_CONSTRUCTOR_WITNESS_NOT_PRODUCTION_EXECUTION" ||
		report["frozenCoreInvocations"] != float64(0) || report["staticBoundaryInvocations"] != float64(1) ||
		report["buildTmpEmptied"] != true || report["outerInputsRevalidatedAfterCleanup"] != true {
		t.Fatal("incomplete kernel witness", report)
	}
	after, err := os.ReadFile("/proc/self/mountinfo")
	if err != nil || !bytes.Equal(before, after) {
		t.Fatal("parent mount state changed", err)
	}
	if _, err = os.Stat("/proc/" + strconvPID(cmd.Process.Pid)); !os.IsNotExist(err) {
		t.Fatal("child process remains", err)
	}
	for _, directory := range []string{filepath.Join(proof, "root"), filepath.Join(boundary, "inputs")} {
		entries, err := os.ReadDir(directory)
		if err != nil || len(entries) != 0 {
			t.Fatal("private mounts survived namespace exit", directory, err)
		}
	}
	if err = os.Remove(filepath.Join(proof, "root")); err != nil {
		t.Fatal(err)
	}
	report["parentMountInfoByteEquivalent"] = true
	report["namespaceProcessGone"] = true
	report["noSurvivingTransactionMounts"] = true
	report["parentOwnedRootRemoved"] = true
	report["publishedEntrypointDeniedWithoutReading"] = true
	raw, err := json.Marshal(report)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(kernelMarker + string(raw))
}

func strconvPID(pid int) string {
	raw, _ := json.Marshal(pid)
	return string(raw)
}

func TestKernelConstructorChild(t *testing.T) {
	if os.Getenv("G3A_KERNEL_WITNESS_CHILD") != "1" {
		t.Skip("internal unit-test namespace child only")
	}
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	if trustedExecutionAuthoritySHA256 != "" || runProduction(forbiddenReader{}) == nil {
		t.Fatal("public production entrypoint not failclosed")
	}
	if err := namespaceBoundary(); err != nil {
		t.Fatal("qualified namespace helper", err)
	}
	namespaceIDs := map[string]string{}
	for _, name := range []string{"mnt", "net"} {
		value, err := os.Readlink("/proc/self/ns/" + name)
		if err != nil {
			t.Fatal(err)
		}
		namespaceIDs[name] = value
	}
	if err := syscall.Mount("", "/", "", syscall.MS_REC|syscall.MS_PRIVATE, ""); err != nil {
		t.Fatal(err)
	}
	boundary := os.Getenv("G3A_KERNEL_TX_ROOT")
	request := productionRequest{Transaction: "KERNEL_STATIC_ONLY", Capacity: maxima,
		InputRoot: filepath.Join(boundary, "inputs"), ReceiptRoot: filepath.Join(boundary, "receipts")}
	// Fixture-only sealing of the outer tree; no input bytes are copied anywhere.
	if err := syscall.Mount("/frozen-inputs", request.InputRoot, "", syscall.MS_BIND, ""); err != nil {
		t.Fatal(err)
	}
	if err := syscall.Mount("", request.InputRoot, "", syscall.MS_BIND|syscall.MS_REMOUNT|
		syscall.MS_RDONLY|syscall.MS_NOSUID|syscall.MS_NODEV, ""); err != nil {
		t.Fatal(err)
	}
	if err := checkTransactionInputs(request); err != nil {
		t.Fatal("actual outer input contract", err)
	}
	inputStat, err := os.Stat(request.InputRoot)
	if err != nil {
		t.Fatal(err)
	}
	markerBytes, err := os.ReadFile("/source-tests/static-marker.test")
	if err != nil {
		t.Fatal(err)
	}
	// The fixture plan has no authority, digest, receipt or production request.
	plan := verifiedProduction{Request: request}
	root := filepath.Join(os.Getenv("G3A_KERNEL_PROOF_ROOT"), "root")
	if err = os.Mkdir(root, 0700); err != nil {
		t.Fatal(err)
	}
	if err = syscall.Mount("none", root, "tmpfs", syscall.MS_NOSUID|syscall.MS_NODEV, "mode=0755,size=128m"); err != nil {
		t.Fatal(err)
	}
	if shaBytes(payload) != qualifiedRuntimePayloadSHA256 {
		t.Fatal("qualified embedded payload changed")
	}
	if _, err = extract(filepath.Join(root, "runtime")); err != nil {
		t.Fatal(err)
	}
	if _, err = stageSONAMEAliases(filepath.Join(root, "runtime")); err != nil {
		t.Fatal(err)
	}
	if err = filepath.Walk(filepath.Join(root, "runtime"), func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if err = os.Chown(path, 65532, 65532); err != nil {
			return err
		}
		if info.IsDir() {
			return os.Chmod(path, 0500)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
	probe := filepath.Join(root, "readonly-probe")
	if os.WriteFile(probe, []byte("static-constructor-only"), 0600) != nil ||
		os.Chown(probe, 65532, 65532) != nil {
		t.Fatal("readonly probe")
	}
	for _, name := range []string{"work", "output"} {
		path := filepath.Join(root, name)
		if err = os.Mkdir(path, 0700); err != nil {
			t.Fatal(err)
		}
		if err = syscall.Mount("none", path, "tmpfs", syscall.MS_NOSUID|syscall.MS_NODEV|syscall.MS_NOEXEC,
			"mode=0700,uid=65532,gid=65532,size=16m"); err != nil {
			t.Fatal(err)
		}
	}
	// This is the actual production constructor, including actual mount syscalls.
	if err = stageProductionMounts(root, plan); err != nil {
		t.Fatal("actual production mount constructor", err)
	}
	aliasStat, err := os.Stat(filepath.Join(root, "inputs"))
	if err != nil || !os.SameFile(inputStat, aliasStat) {
		t.Fatal("input alias is not direct binding", err)
	}
	initialLimits, err := effectiveAt(root, request.Capacity)
	if err != nil {
		t.Fatal(err)
	}
	for _, item := range []struct {
		name          string
		bytes, inodes uint64
	}{
		{"build", 1073741824, 32768}, {"tmp", 268435456, 4096},
	} {
		actual := initialLimits[item.name]
		if actual.AvailableBytes != item.bytes || actual.AvailableInodes != item.inodes-1 {
			t.Fatal("inputs charged to redirected mount", item.name, actual)
		}
	}
	for _, name := range []string{"build", "tmp"} {
		entries, err := os.ReadDir(filepath.Join(root, name))
		if err != nil || len(entries) != 0 {
			t.Fatal("constructor root not empty", name, err)
		}
	}
	ro := filepath.Join(root, "runtime")
	if err = syscall.Mount(ro, ro, "", syscall.MS_BIND, ""); err != nil {
		t.Fatal(err)
	}
	if err = syscall.Mount("", ro, "", syscall.MS_BIND|syscall.MS_REMOUNT|syscall.MS_RDONLY|syscall.MS_NOSUID|syscall.MS_NODEV, ""); err != nil {
		t.Fatal(err)
	}
	if err = syscall.Mount("", root, "tmpfs", syscall.MS_REMOUNT|syscall.MS_RDONLY|syscall.MS_NOSUID|syscall.MS_NODEV, ""); err != nil {
		t.Fatal(err)
	}
	ifaces, err := net.Interfaces()
	if err != nil || len(ifaces) != 1 {
		t.Fatal("interface census", err)
	}
	for _, iface := range ifaces {
		addrs, err := iface.Addrs()
		if err != nil || iface.Name != "lo" || iface.Flags&net.FlagUp != 0 || len(addrs) != 0 {
			t.Fatal("connected interface")
		}
	}
	for _, path := range []string{"/proc/net/route", "/proc/net/ipv6_route"} {
		raw, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		if _, err = disconnectedRoutes(raw, path == "/proc/net/ipv6_route"); err != nil {
			t.Fatal(err)
		}
	}
	if err = syscall.Chroot(root); err != nil {
		t.Fatal(err)
	}
	if err = os.Chdir("/work"); err != nil {
		t.Fatal(err)
	}
	r := newResult()
	if err = dropPrivileges(&r); err != nil {
		t.Fatal("qualified drop/regain negatives", err, r)
	}
	for _, path := range []string{"/var/lib/waagent", "/etc/shadow", "/source-tests", "/frozen-inputs",
		boundary, "/root", "/home", "/proc", "/sys"} {
		if _, err = os.Stat(path); !os.IsNotExist(err) {
			t.Fatal("host path exposed", path, err)
		}
	}
	mounts := map[string]filesystemLimit{}
	for _, path := range []string{"/", "/runtime", "/inputs", "/build", "/tmp", "/work", "/output", "/dev"} {
		value, err := filesystemObservation(path)
		if err != nil {
			t.Fatal(err)
		}
		mounts[path] = value
		if path == "/" || path == "/runtime" || path == "/inputs" {
			if value.Flags&syscall.MS_RDONLY == 0 {
				t.Fatal("not readonly", path)
			}
		}
		if path == "/work" || path == "/output" {
			if value.Flags&14 != 14 || value.Flags&1 != 0 {
				t.Fatal("work/output mount flags", path)
			}
		}
	}
	if err = os.WriteFile("/readonly-probe", nil, 0600); !errors.Is(err, syscall.EROFS) {
		t.Fatal("root write not EROFS", err)
	}
	if err = os.WriteFile("/inputs/forbidden", nil, 0600); !errors.Is(err, syscall.EROFS) {
		t.Fatal("input write not EROFS", err)
	}
	if err = readonlyInputRoot("/inputs"); err != nil {
		t.Fatal("isolated nonroot input census", err)
	}
	if err = networkNegative(&r); err != nil {
		t.Fatal("qualified TCP negative", err)
	}
	if err = nullOnlyDeviceCheck(); err != nil {
		t.Fatal("actual device/proc checks", err)
	}
	calls := 0
	bad := plan
	bad.Request.Capacity.BuildBytes -= 4096
	if dispatchConstructedCore(bad, &r, func() error { calls++; return nil }) == nil || calls != 0 {
		t.Fatal("kernel effective-limit mismatch reached boundary")
	}
	if err = os.Mkdir("/build/transaction", 0700); err != nil {
		t.Fatal(err)
	}
	if dispatchConstructedCore(plan, &r, func() error { calls++; return nil }) == nil || calls != 0 {
		t.Fatal("dirty build transaction reached boundary")
	}
	execWitness := map[string]string{}
	err = dispatchConstructedCore(plan, &r, func() error {
		calls++
		for _, path := range []string{"/build", "/tmp", "/work", "/output"} {
			if err := os.Chdir(path); err != nil {
				return err
			}
			if err := os.WriteFile("static-marker.test", markerBytes, 0500); err != nil {
				return err
			}
			cmd := exec.Command("./static-marker.test", "-test.run=^TestStaticMarker$", "-test.v")
			cmd.Env = []string{"PATH=/unavailable", "HOME=/unavailable"}
			out := &cappedBuffer{limit: 4096}
			cmd.Stdout, cmd.Stderr, cmd.Stdin = out, out, bytes.NewReader(nil)
			err := cmd.Run()
			if path == "/work" || path == "/output" {
				if !errors.Is(err, syscall.EACCES) {
					return errors.New("NOEXEC_NEGATIVE_FAILED_" + path)
				}
				execWitness[path] = "EACCES"
			} else {
				if err != nil || !strings.Contains(out.String(), "G3A_STATIC_UNIT_EXEC_WITNESS_ONLY") {
					return errors.New("STATIC_UNIT_EXEC_FAILED_" + path)
				}
				execWitness[path] = "STATIC_UNIT_EXEC_PASS"
			}
			if err = os.Remove("static-marker.test"); err != nil {
				return err
			}
		}
		if err := os.Chdir("/work"); err != nil {
			return err
		}
		if err := os.Mkdir("/build/transaction", 0700); err != nil {
			return err
		}
		if err := os.WriteFile("/build/transaction/static-boundary", []byte("not frozen core"), 0600); err != nil {
			return err
		}
		if err := os.Chdir("/tmp"); err != nil {
			return err
		}
		if err := os.WriteFile("static-boundary", []byte("not frozen core"), 0600); err != nil {
			return err
		}
		return os.Chdir("/work")
	})
	if err != nil || calls != 1 {
		t.Fatal("actual constructed gate/static boundary", err, calls)
	}
	finalLimits, err := effectiveAt("/", request.Capacity)
	if err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{"/build", "/tmp"} {
		entries, err := os.ReadDir(path)
		if err != nil || len(entries) != 0 {
			t.Fatal("actual cleanup failed", path, err)
		}
	}
	if err = readonlyInputRoot("/inputs"); err != nil {
		t.Fatal("outer inputs changed after cleanup", err)
	}
	var inputBytes int64
	for _, expected := range frozenInputs {
		inputBytes += expected.Bytes
	}
	report := map[string]interface{}{
		"schema": "g3a-static-constructor-witness/v1", "scope": "STATIC_CONSTRUCTOR_WITNESS_NOT_PRODUCTION_EXECUTION",
		"status": "PASS_STATIC_KERNEL_CONSTRUCTOR", "frozenCoreInvocations": 0, "staticBoundaryInvocations": calls,
		"futureExecutionAuthorityIssued": false, "productionChildInvocations": 0,
		"actualProductionConstructor": "stageProductionMounts",
		"actualConstructedBoundary":   "dispatchConstructedCore",
		"inputLayout":                 "outer-readonly-inputRoot-bound-at-/inputs",
		"inputEntries":                len(frozenInputs), "inputBytes": inputBytes,
		"directInputSameInodeBinding": true, "inputStagingCopies": 0,
		"inputChargeToBuildBytes": 0, "buildAndTmpInitiallyEmpty": true,
		"initialEffectiveLimits": initialLimits, "finalEffectiveLimits": finalLimits,
		"actualMounts": mounts, "isolatedNamespaceIDs": namespaceIDs, "execWitness": execWitness,
		"namespacePrivatePropagation": true, "readonlyRootRuntimeInputs": true,
		"hostTreeAbsent": true, "downLoopbackOnlyNoRoutes": true, "qualifiedTcpNegative": true,
		"qualifiedPrivilegeChecks": r.Checks, "qualifiedPrivilegeDetails": r.Details,
		"exactNullOnlyDeviceAndNoProcChecks":          true,
		"effectiveMismatchDeniedBeforeStaticBoundary": true, "dirtyBuildDeniedBeforeStaticBoundary": true,
		"buildTmpEmptied": r.Details["buildTmpEmptied"], "outerInputsRevalidatedAfterCleanup": true,
	}
	raw, err := json.Marshal(report)
	if err != nil {
		t.Fatal(err)
	}
	// Separate witness schema/marker: never a production-proof success document.
	os.Stdout.WriteString(kernelMarker + string(raw) + "\n")
}
