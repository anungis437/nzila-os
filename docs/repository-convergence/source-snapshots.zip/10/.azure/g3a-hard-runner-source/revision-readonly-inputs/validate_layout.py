"""Failclosed source tests and a bounded static constructor witness, never a frozen build."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

from prepare_layout import baseline, fresh, protect, sha, HERE, ROOT, QUALIFIED

GO = Path(r"C:\Program Files\Go\bin\go.exe")
IMAGE = "sha256:e88e9763f943ec1834f992a4b51e0f24500486803e8bc534e5767af9ea65f6ce"
SOURCES = ("dispatch.go", "dispatch_test.go", "transaction_roots_test.go", "frozen_bindings.go",
           "launcher.go", "proof_linux.go", "census.go", "production_linux.go",
           "production_linux_test.go", "kernel_constructor_linux_test.go")


def execute(command, cwd, env):
    before = baseline()
    protect()
    result = subprocess.run(list(map(str, command)), cwd=cwd, env=env, capture_output=True,
                            text=True, encoding="utf-8", errors="replace", timeout=300)
    return {"command": list(map(str, command)), "cwd": str(cwd), "exitCode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr,
            "beforeBaseline": before, "afterBaseline": baseline()}


def main():
    initial = baseline()
    protect()
    check = HERE / ".checks"
    baseline()
    check.mkdir(exist_ok=True)
    env = dict(os.environ, GOENV="off", GOTOOLCHAIN="local", GO111MODULE="off", CGO_ENABLED="0")
    for var, name in (("GOCACHE", "cache"), ("GOPATH", "gopath"), ("GOTMPDIR", "go-work"),
                      ("TEMP", "host-work"), ("TMP", "host-work")):
        path = check / name
        baseline()
        path.mkdir(exist_ok=True)
        env[var] = str(path)
    results = []
    # Each source formatting write is preceded by a complete rebaseline.
    for name in SOURCES + ("verify_primitives.go", "static_marker_test.go"):
        result = execute([GO.parent / "gofmt.exe", "-w", HERE / name], HERE, env)
        if result["exitCode"] != 0:
            raise RuntimeError(result)
    results.append(execute([GO, "test", "-v", "dispatch.go", "frozen_bindings.go",
                            "dispatch_test.go", "transaction_roots_test.go"], HERE, env))
    results.append(execute([GO, "run", "verify_primitives.go", "--", QUALIFIED / "proof_linux.go",
                            HERE / "proof_linux.go", QUALIFIED / "launcher.go", HERE / "launcher.go",
                            HERE / "production_linux.go"], HERE, env))
    stage = check / "linux-source-tests"
    baseline()
    stage.mkdir(exist_ok=True)
    for name in SOURCES + ("static_marker_test.go",):
        baseline()
        shutil.copyfile(HERE / name, stage / name)
    baseline()
    shutil.copyfile(QUALIFIED / "payload.tar", stage / "payload.tar")
    baseline()
    (stage / "fixtures").mkdir(exist_ok=True)
    linux = dict(env, GOOS="linux", GOARCH="amd64")
    results.append(execute([GO, "test", "-c", "-o", stage / "static-marker.test", "static_marker_test.go"], stage, linux))
    results.append(execute([GO, "test", "-c", "-o", stage / "runner-source-tests"], stage, linux))
    base_command = ["docker", "run", "--rm", "--pull", "never", "--network", "none", "--read-only",
                    "--memory", "768m", "--pids-limit", "128", "--cpus", "2",
                    "--mount", f"type=bind,source={stage},target=/source-tests,readonly",
                    "--tmpfs", "/source-tests/fixtures:rw,noexec,nosuid,nodev,size=8388608,nr_inodes=256,mode=0700",
                    "--workdir", "/source-tests/fixtures"]
    if all(r["exitCode"] == 0 for r in results):
        results.append(execute(base_command + ["--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                        IMAGE, "/source-tests/runner-source-tests", "-test.v", "-test.timeout=60s"], HERE, env))
    if len(results) == 5 and all(r["exitCode"] == 0 for r in results):
        historical = ROOT / ".azure/g3a-controller-repair/inputs"
        inputs = check / ".g3a-transaction-KERNEL_STATIC_ONLY" / "inputs"
        spec = re.findall(r'"([^"]+)":\s+\{(\d+), "([0-9a-f]{64})"\}', (HERE / "frozen_bindings.go").read_text())
        if len(spec) != 15:
            raise RuntimeError("FIFTEEN_FROZEN_INPUT_IDENTITIES_REQUIRED")
        baseline()
        inputs.mkdir(parents=True, exist_ok=True)
        for name, size, digest in spec:
            source, target = historical / name, inputs / name
            if source.is_symlink() or source.stat().st_size != int(size) or sha(source) != digest:
                raise RuntimeError("HISTORICAL_INPUT_CHANGED_" + name)
            if not target.exists():
                baseline()
                protect()
                with source.open("rb") as reader, target.open("xb") as writer:
                    shutil.copyfileobj(reader, writer, 1024*1024)
            if target.is_symlink() or target.stat().st_size != int(size) or sha(target) != digest:
                raise RuntimeError("OUTER_DISK_FIXTURE_CHANGED_" + name)
        if {p.name for p in inputs.iterdir()} != {n for n, _, _ in spec}:
            raise RuntimeError("OUTER_DISK_FIXTURE_EXACT_CENSUS")
        command = base_command + ["--cap-drop", "ALL"]
        for cap in ("SYS_ADMIN", "SYS_CHROOT", "SETPCAP", "SETUID", "SETGID", "CHOWN", "DAC_OVERRIDE", "FOWNER"):
            command += ["--cap-add", cap]
        command += ["--security-opt", "seccomp=unconfined", "--env", "G3A_KERNEL_WITNESS=1",
                    "--mount", f"type=bind,source={inputs},target=/frozen-inputs,readonly",
                    IMAGE, "/source-tests/runner-source-tests",
                    "-test.run=^TestKernelConstructorWitness$", "-test.v", "-test.timeout=90s"]
        results.append(execute(command, HERE, env))
    attempt = 1
    while (HERE / f"VALIDATION_ATTEMPT_{attempt}.json").exists():
        attempt += 1
    payload = {"initialBaseline": initial, "finalBaseline": baseline(), "results": results,
               "sourceHashes": {n: sha(HERE / n) for n in SOURCES + ("verify_primitives.go", "static_marker_test.go")},
               "unitTestExecutableHashes": {n: sha(stage/n) for n in ("runner-source-tests", "static-marker.test") if (stage/n).exists()},
               "testOnlyEmbeddedQualifiedPayloadSha256": sha(stage / "payload.tar"),
               "outerInputFixturePreparation": {
                   "storage": "exclusive owned on-disk fixture; readonly-bound before constructor",
                   "memoryTmpfsInputCopies": 0, "productionConstructorInputCopies": 0,
                   "historicalMetadataExcludedWithoutEditing": ["binding.json"],
                   "historicalInputSource": str(ROOT / ".azure/g3a-controller-repair/inputs")},
               "frozenCoreInvocations": 0, "productionChildInvocations": 0,
               "candidateBuilt": False, "futureExecutionAuthorityIssued": False,
               "cloudReads": 0, "cloudMutations": 0, "registryCalls": 0}
    fresh(f"VALIDATION_ATTEMPT_{attempt}.json", payload)
    for result in results:
        print(json.dumps({"command": result["command"], "exitCode": result["exitCode"]}))
        if result["exitCode"] != 0:
            print(result["stdout"])
            print(result["stderr"])
    print("EVIDENCE=" + str(HERE / f"VALIDATION_ATTEMPT_{attempt}.json"))
    return 0 if len(results) == 6 and all(r["exitCode"] == 0 for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
