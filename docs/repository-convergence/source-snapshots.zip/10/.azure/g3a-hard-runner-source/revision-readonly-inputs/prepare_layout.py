"""Append-only rehearsal-aligned source generation. Never dispatch the frozen core."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(r"C:\APPS\worktrees\nzila-g2-provenance")
FOREIGN = Path(r"C:\APPS\nzila-os")
HERE = Path(__file__).resolve().parent
LANE = HERE.parent
OLD = LANE / "revision"
QUALIFIED = ROOT / ".azure/g3a-isolation-artifacts"
AUTHORITY = Path(r"C:\Users\AubertNungisa\AppData\Roaming\Code\agentSessionData\7496e6a0-5c9e-4c19-86cb-183af2c0f9c4\attachments\3d123728-29e5-4f5e-9862-5ca634b7275f\Pasted text #1.txt")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def baseline():
    result = {}
    for label, root, expected in (
        ("owned", ROOT, "7bec20aad11d43eeae8099c14e021b3074154b27"),
        ("foreign", FOREIGN, "1c337567635bb86ea0df7831557d8d2d22df1e6f"),
    ):
        head = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()
        status = subprocess.check_output(["git", "-C", str(root), "status", "--short"], text=True)
        if head != expected or label == "owned" and len(status.splitlines()) != 2:
            raise RuntimeError("BASELINE_CHANGED_" + label)
        result[label] = {"head": head, "statusCount": len(status.splitlines()), "statusSha256": hashlib.sha256(status.encode()).hexdigest()}
    return result


def protect():
    if (HERE / "PRESERVED_BYTES.json").exists():
        for path, expected in json.loads((HERE / "PRESERVED_BYTES.json").read_text())["hashes"].items():
            if sha(Path(path)) != expected:
                raise RuntimeError("HISTORICAL_BYTES_CHANGED_" + path)


def fresh(name, value):
    baseline()
    protect()
    raw = value.encode() if isinstance(value, str) else value if isinstance(value, bytes) else (json.dumps(value, indent=2) + "\n").encode()
    with (HERE / name).open("xb") as output:
        output.write(raw)


def replace(text, old, new):
    if old not in text:
        raise RuntimeError("GENERATION_ANCHOR_MISSING_" + old[:70])
    return text.replace(old, new)


def main():
    original = baseline()
    # Read the full authority, not excerpts; retain its identity without rewriting it.
    authority = AUTHORITY.read_text(encoding="utf-8-sig")
    if "# 18. PRODUCTION RUNNER DELTA" not in authority or "# 19. PRIMITIVE EQUIVALENCE" not in authority:
        raise RuntimeError("AUTHORITY_SECTIONS_MISSING")
    paths = [p for p in OLD.rglob("*") if p.is_file()]
    paths += [p for p in LANE.iterdir() if p.is_file()]
    paths += [QUALIFIED / n for n in ("proof_linux.go", "launcher.go", "census.go", "payload.tar", "SOURCE_BINDING.json")]
    paths += [ROOT / ".azure/g3a-isolation-live/ISOLATION_VERIFICATION.json",
              ROOT / ".azure/g3a-hard-capacity/HARD_BOUND_ACCEPTANCE.json",
              ROOT / ".azure/g3a-hard-capacity/EFFECTIVE_LIMITS.json",
              ROOT / ".azure/g3a-hard-capacity/rehearsal-resume/GUEST_OFFLINE_RAW.json", AUTHORITY]
    fresh("PRESERVED_BYTES.json", {"initialBaseline": original, "authorityFullyReadCharacters": len(authority),
                                  "hashes": {str(p): sha(p) for p in paths}})
    for name in ("launcher.go", "census.go", "frozen_bindings.go"):
        fresh(name, (OLD / name).read_bytes())
    text = (OLD / "dispatch.go").read_text()
    anchor = "\tvar authority executionAuthority\n"
    text = replace(text, anchor, '\tif err := validateTransactionRoots(request); err != nil {\n\t\treturn verified, err\n\t}\n' + anchor)
    text += '''
func validateTransactionRoots(request productionRequest) error {
    if !transactionPattern.MatchString(request.Transaction) {
        return errors.New("WRONG_TRANSACTION_IDENTITY")
    }
    for _, path := range []string{request.InputRoot, request.ReceiptRoot} {
        if !filepath.IsAbs(path) || filepath.Clean(path) != path {
            return errors.New("ABSOLUTE_CANONICAL_ROOT_REQUIRED")
        }
    }
    boundary := filepath.Dir(request.InputRoot)
    if filepath.Base(request.InputRoot) != "inputs" ||
       filepath.Base(request.ReceiptRoot) != "receipts" ||
       filepath.Dir(request.ReceiptRoot) != boundary ||
       filepath.Base(boundary) != ".g3a-transaction-"+request.Transaction {
        return errors.New("EXCLUSIVE_TRANSACTION_ROOT_BINDING_REQUIRED")
    }
    return nil
}
'''
    fresh("dispatch.go", text)
    text = (OLD / "dispatch_test.go").read_text()
    text = replace(text, 'filepath.Join(root, "input-fixture")', 'filepath.Join(root, ".g3a-transaction-SOURCE_ONLY_TEST", "inputs")')
    text = replace(text, 'filepath.Join(root, "receipt-fixture")', 'filepath.Join(root, ".g3a-transaction-SOURCE_ONLY_TEST", "receipts")')
    fresh("dispatch_test.go", text)
    text = (OLD / "proof_linux.go").read_text()
    prefix, child = text.split("func productionChild()", 1)
    child = replace(child, 'os.NewFile(5, "bounded-evidence-pipe")', 'os.NewFile(4, "bounded-evidence-pipe")')
    child = replace(child, "syscall.CloseOnExec(5)", "syscall.CloseOnExec(4)")
    fresh("proof_linux.go", prefix + "func productionChild()" + child)
    text = (OLD / "verify_primitives.go").read_text()
    text = replace(text, "syscall.CloseOnExec(5)", "syscall.CloseOnExec(4)")
    text = replace(text, 'normalized(backend["invokeProductionCore"]), "childDispatchBoundary("',
                   'normalized(backend["dispatchConstructedCore"]), "childDispatchBoundary("')
    fresh("verify_primitives.go", text)
    text = (OLD / "production_linux.go").read_text()
    text = replace(text, '"context"', '"context"\n\t"crypto/sha256"\n\t"encoding/hex"')
    start, end = text.index("func checkFrozenInputs("), text.index("type linuxProductionBackend")
    text = text[:start] + '''
func validateInputFiles(root string) error {
    entries, err := os.ReadDir(root)
    if err != nil || len(entries) != len(frozenInputs) {
        return errors.New("FROZEN_INPUT_EXACT_CENSUS")
    }
    for _, entry := range entries {
        name := entry.Name()
        expected, ok := frozenInputs[name]
        if !ok || !safe(name) || strings.ContainsAny(name, "/\\\\\\\\") {
            return errors.New("FROZEN_INPUT_UNEXPECTED_ENTRY")
        }
        path := filepath.Join(root, name)
        stat, err := os.Lstat(path)
        if err != nil || !stat.Mode().IsRegular() || stat.Size() != expected.Bytes ||
           stat.Mode()&(os.ModeSetuid|os.ModeSetgid) != 0 || stat.Mode().Perm()&0004 == 0 {
            return errors.New("FROZEN_INPUT_TYPE_SIZE_MODE_"+name)
        }
        if (name == "portable-assembler" || name == "compressor-go1256") && stat.Mode().Perm()&0001 == 0 {
            return errors.New("FROZEN_INPUT_NONROOT_EXEC_"+name)
        }
        file, err := os.OpenFile(path, os.O_RDONLY|syscall.O_NOFOLLOW, 0)
        if err != nil { return err }
        opened, err := file.Stat()
        if err != nil || !os.SameFile(stat, opened) || !opened.Mode().IsRegular() || opened.Size() != expected.Bytes {
            file.Close()
            return errors.New("FROZEN_INPUT_CHANGED_"+name)
        }
        h := sha256.New()
        count, hashErr := io.CopyN(h, file, expected.Bytes)
        var extra [1]byte
        tail, tailErr := file.Read(extra[:])
        after, statErr := file.Stat()
        closeErr := file.Close()
        if hashErr != nil || count != expected.Bytes || tail != 0 || tailErr != io.EOF ||
           statErr != nil || after.Size() != expected.Bytes || closeErr != nil ||
           hex.EncodeToString(h.Sum(nil)) != expected.SHA {
            return errors.New("FROZEN_INPUT_HASH_"+name)
        }
    }
    return nil
}

func readonlyInputRoot(root string) error {
    stat, err := os.Lstat(root)
    canonical, canonicalErr := filepath.EvalSymlinks(root)
    if err != nil || !stat.IsDir() || stat.Mode()&os.ModeSymlink != 0 ||
       canonicalErr != nil || canonical != root || stat.Mode().Perm()&0005 != 0005 {
        return errors.New("CANONICAL_NONROOT_READABLE_INPUT_ROOT_REQUIRED")
    }
    observed, err := filesystemObservation(root)
    if err != nil || observed.Flags&syscall.MS_RDONLY == 0 {
        return errors.New("OUTER_INPUT_ROOT_NOT_KERNEL_READONLY")
    }
    return validateInputFiles(root)
}

func checkTransactionInputs(request productionRequest) error {
    if err := validateTransactionRoots(request); err != nil { return err }
    if err := secureRoot(filepath.Dir(request.InputRoot)); err != nil { return err }
    if err := secureRoot(request.ReceiptRoot); err != nil { return err }
    stat, err := os.Lstat(request.InputRoot)
    if err != nil { return err }
    owner, ok := stat.Sys().(*syscall.Stat_t)
    if !ok || int(owner.Uid) != os.Geteuid() {
        return errors.New("INPUT_ROOT_OWNER_MISMATCH")
    }
    return readonlyInputRoot(request.InputRoot)
}

''' + text[end:]
    text = replace(text, "return checkFrozenInputs(plan.Request.InputRoot)", "return checkTransactionInputs(plan.Request)")
    text = replace(text, 'plan.Pin+".consumed.json"', '"transaction.consumed.json"')
    start, end = text.index("func streamFrozenInputs("), text.index("func (linuxProductionBackend) launch")
    text = text[:start] + text[end:]
    start, end = text.index("\tinputRead, inputWrite, err := os.Pipe()"), text.index("\tevidenceRead, evidenceWrite, err := os.Pipe()")
    text = text[:start] + text[end:]
    text = replace(text, "[]*os.File{planRead, inputRead, evidenceWrite}", "[]*os.File{planRead, evidenceWrite}")
    text = replace(text, "\tinputRead.Close()\n", "")
    start, end = text.index("\tstreamDone, evidenceDone :="), text.index("\tgo func() {\n\t\t_, err := io.Copy(archive")
    text = text[:start] + "\tevidenceDone := make(chan error, 1)\n" + text[end:]
    text = replace(text, "streamErr, evidenceErr := <-streamDone, <-evidenceDone", "evidenceErr := <-evidenceDone")
    text = replace(text, '"inputStreamError": fmt.Sprint(streamErr), ', '"inputLayout": "outer-readonly-inputRoot-bound-at-/inputs", ')
    text = replace(text, " || streamErr != nil", "")
    start, end = text.index("func stageInputArchive("), text.index("func filesystemObservation(")
    text = text[:start] + '''
func bindTransactionInputs(root string, request productionRequest) error {
    if err := checkTransactionInputs(request); err != nil { return err }
    destination := filepath.Join(root, "inputs")
    if err := syscall.Mount(request.InputRoot, destination, "", syscall.MS_BIND, ""); err != nil { return err }
    if err := syscall.Mount("", destination, "", syscall.MS_BIND|syscall.MS_REMOUNT|
       syscall.MS_RDONLY|syscall.MS_NOSUID|syscall.MS_NODEV, ""); err != nil { return err }
    return readonlyInputRoot(destination)
}

''' + text[end:]
    start, end = text.index('\tinput := os.NewFile(4, "frozen-input-pipe")'), text.index('\tdev := filepath.Join(root, "dev")')
    text = text[:start] + '''\tif err := bindTransactionInputs(root, plan.Request); err != nil { return err }
''' + text[end:]
    text = replace(text, 'if err = syscall.Mount("none", dev, "tmpfs"', 'if err := syscall.Mount("none", dev, "tmpfs"')
    start, end = text.index("\tdefer func() {", text.index("func executeFrozenCore(")), text.index('\tif _, err := os.Lstat("/build/transaction")', text.index("func executeFrozenCore("))
    text = text[:start] + text[end:]
    start, end = text.index('\tif err := os.Chmod(filepath.Join(build, ".inputs")'), text.index('\tfor _, root := range []string{build, temporary}')
    text = text[:start] + text[end:]
    start = text.index("func invokeProductionCore(")
    text = text[:start] + '''
func dispatchConstructedCore(plan verifiedProduction, r *proofResult, core func() error) (returnErr error) {
    observed, err := effectiveAt("/", plan.Request.Capacity)
    if err != nil { return err }
    r.Details["effectiveLimitsBeforeCore"] = observed
    defer func() {
        if err := emptyBuildTmp(); err != nil { returnErr = err } else { r.Details["buildTmpEmptied"] = true }
    }()
    if _, err := os.Lstat("/build/transaction"); !os.IsNotExist(err) {
        return errors.New("FROZEN_WORK_ALREADY_EXISTS")
    }
    if err := readonlyInputRoot("/inputs"); err != nil { return err }
    return childDispatchBoundary(plan, observed, nullOnlyDeviceCheck, core)
}

func invokeProductionCore(plan verifiedProduction, r *proofResult, output io.Writer) error {
    return dispatchConstructedCore(plan, r, func() error { return executeFrozenCore(r, output) })
}
'''
    fresh("production_linux.go", text)
    print("APPEND_ONLY_READONLY_LAYOUT_SOURCE_GENERATED")


if __name__ == "__main__":
    main()
