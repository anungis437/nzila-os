package main

import "testing"

func TestStaticMarker(t *testing.T) {
	t.Log("G3A_STATIC_UNIT_EXEC_WITNESS_ONLY")
}
