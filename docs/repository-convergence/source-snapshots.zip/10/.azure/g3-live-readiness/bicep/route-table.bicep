targetScope = 'resourceGroup'

@allowed(['canadacentral'])
param location string = 'canadacentral'
param tags object
@description('Observed G2 firewall next hop. Not reachable from G3 without separately governed connectivity and rules.')
@allowed(['10.90.0.4'])
param firewallPrivateIp string

resource routes 'Microsoft.Network/routeTables@2024-05-01' = {
  name: 'nzila-g3-test-001-egress-rt'
  location: location
  tags: tags
  properties: {
    disableBgpRoutePropagation: true
    routes: [
      {
        name: 'DefaultToGovernedFirewall'
        properties: {
          addressPrefix: '0.0.0.0/0'
          nextHopType: 'VirtualAppliance'
          nextHopIpAddress: firewallPrivateIp
        }
      }
    ]
  }
}

output routeTableId string = routes.id
output associationPrepared bool = false
output connectivityPrerequisite string = 'BLOCKED_NO_G3_G2_PEERING_OR_APPROVED_FIREWALL_RULES'
