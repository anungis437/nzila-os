package main

import (
	"crypto/sha256"
	"fmt"
	"io"
	"os"
)

var marker string

func main() {
	if marker != "G3A_BOOTSTRAP_REQUESTED_V1" && marker != "G3A_BOOTSTRAP_CURRENT_V2" {
		fmt.Fprintln(os.Stderr, "BOOTSTRAP_PROOF_INVALID_MARKER")
		os.Exit(78)
	}
	file, err := os.Open("/proc/self/exe")
	if err != nil {
		fmt.Fprintln(os.Stderr, "BOOTSTRAP_PROOF_SELF_OPEN_FAILED")
		os.Exit(79)
	}
	hash := sha256.New()
	_, err = io.Copy(hash, file)
	closeErr := file.Close()
	if err != nil || closeErr != nil {
		fmt.Fprintln(os.Stderr, "BOOTSTRAP_PROOF_SELF_HASH_FAILED")
		os.Exit(80)
	}
	fmt.Println(marker)
	fmt.Printf("SELF_SHA256=%x\n", hash.Sum(nil))
	if marker == "G3A_BOOTSTRAP_CURRENT_V2" {
		os.Exit(42)
	}
}
