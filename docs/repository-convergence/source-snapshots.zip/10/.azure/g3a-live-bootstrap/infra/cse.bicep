param vmName string
param blobVersionUri string
param readerClientId string
param tags object

resource vm 'Microsoft.Compute/virtualMachines@2024-11-01' existing = {
  name: vmName
}

resource proof 'Microsoft.Compute/virtualMachines/extensions@2024-11-01' = {
  parent: vm
  name: 'g3-firstbyte-once'
  location: 'canadacentral'
  tags: tags
  properties: {
    publisher: 'Microsoft.Azure.Extensions'
    type: 'CustomScript'
    typeHandlerVersion: '2.1.10'
    autoUpgradeMinorVersion: false
    enableAutomaticUpgrade: false
    suppressFailures: false
    settings: {
      skipDos2Unix: true
    }
    protectedSettings: {
      fileUris: [
        blobVersionUri
      ]
      managedIdentity: {
        clientId: readerClientId
      }
      commandToExecute: './g3a-bootstrap-proof'
    }
  }
}
