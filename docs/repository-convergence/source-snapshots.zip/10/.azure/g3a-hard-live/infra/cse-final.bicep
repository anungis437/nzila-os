param vmName string
param handoffUri string
param capsuleUri string
param readerClientId string
param tags object
param boundCommand string

resource vm 'Microsoft.Compute/virtualMachines@2024-11-01' existing = {
  name: vmName
}

resource proof 'Microsoft.Compute/virtualMachines/extensions@2024-11-01' = {
  parent: vm
  name: 'g3-firstbyte-once'
  location: 'canadacentral'
  tags: tags
  properties: {
    publisher: 'Microsoft.Azure.Extensions'
    type: 'CustomScript'
    typeHandlerVersion: '2.1'
    autoUpgradeMinorVersion: false
    enableAutomaticUpgrade: false
    suppressFailures: false
    settings: {
      skipDos2Unix: true
    }
    protectedSettings: {
      fileUris: [
        handoffUri
        capsuleUri
      ]
      managedIdentity: {
        clientId: readerClientId
      }
      commandToExecute: boundCommand
    }
  }
}
