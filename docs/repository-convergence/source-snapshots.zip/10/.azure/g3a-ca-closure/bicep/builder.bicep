param readerIdentityId string
param pushIdentityId string
param subnetId string
param provisioningSshPublicKey string
param adminUsername string = 'nzilag3'
param tags object

resource nsg 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: 'nzila-g3-builder-001-nsg'
  location: 'canadacentral'
  tags: tags
  properties: {
    securityRules: [{
      name: 'DenyAllInbound'
      properties: {
        priority: 100
        direction: 'Inbound'
        access: 'Deny'
        protocol: '*'
        sourcePortRange: '*'
        destinationPortRange: '*'
        sourceAddressPrefix: '*'
        destinationAddressPrefix: '*'
      }
    }]
  }
}
resource nic 'Microsoft.Network/networkInterfaces@2024-05-01' = {
  name: 'nzila-g3-builder-001-nic'
  location: 'canadacentral'
  tags: tags
  properties: {
    enableIPForwarding: false
    enableAcceleratedNetworking: false
    networkSecurityGroup: { id: nsg.id }
    ipConfigurations: [{
      name: 'primary'
      properties: {
        primary: true
        privateIPAllocationMethod: 'Dynamic'
        privateIPAddressVersion: 'IPv4'
        subnet: { id: subnetId }
      }
    }]
  }
}
resource vm 'Microsoft.Compute/virtualMachines@2024-11-01' = {
  name: 'nzila-g3-builder-001'
  location: 'canadacentral'
  tags: tags
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: { '${readerIdentityId}': {}, '${pushIdentityId}': {} }
  }
  properties: {
    hardwareProfile: { vmSize: 'Standard_B2s' }
    osProfile: {
      computerName: 'g3-builder'
      adminUsername: adminUsername
      customData: base64('#cloud-config\npackage_update: false\npackage_upgrade: false\n')
      linuxConfiguration: {
        disablePasswordAuthentication: true
        provisionVMAgent: true
        ssh: {
          publicKeys: [{
            path: '/home/${adminUsername}/.ssh/authorized_keys'
            keyData: provisioningSshPublicKey
          }]
        }
      }
    }
    storageProfile: {
      imageReference: {
        publisher: 'Canonical'
        offer: 'ubuntu-24_04-lts'
        sku: 'server'
        version: '24.04.202609040'
      }
      osDisk: {
        name: 'nzila-g3-builder-001-osdisk'
        createOption: 'FromImage'
        deleteOption: 'Detach'
        diskSizeGB: 64
        managedDisk: { storageAccountType: 'StandardSSD_LRS' }
      }
    }
    networkProfile: {
      networkInterfaces: [{
        id: nic.id
        properties: { primary: true, deleteOption: 'Detach' }
      }]
    }
    diagnosticsProfile: { bootDiagnostics: { enabled: false } }
  }
}
output ownedCandidateIds array = [vm.id, nic.id, nsg.id, resourceId('Microsoft.Compute/disks', 'nzila-g3-builder-001-osdisk')]
output runtimeBlocked string = 'NO_CSE_EMITTED_NO_QUALIFIED_PRODUCTION_GUEST_BOOTSTRAP'
