targetScope = 'resourceGroup'

param registryName string
param principalId string
@allowed(['g3-build-source', 'g3-build-tooling'])
param repository string

resource registry 'Microsoft.ContainerRegistry/registries@2025-11-01' existing = {
  name: registryName
}

var roleId = subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'b93aa761-3e63-49ed-ac28-beffa264f7ac')
var condition = '''
(
  (
    !(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/content/read'})
    AND
    !(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/metadata/read'})
  )
  OR
  (
    @Request[Microsoft.ContainerRegistry/registries/repositories:name] StringEquals '${repository}'
  )
)
'''

resource assignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(registry.id, principalId, roleId, repository, 'NZ-20261008-INFRA-001-G3A')
  scope: registry
  properties: {
    principalId: principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: roleId
    conditionVersion: '2.0'
    condition: condition
    description: 'G3A_TRANSACTION_OWNED exact input repository reader; no input writer or catalog grant.'
  }
}

output assignmentId string = assignment.id
output ownership string = 'G3A_TRANSACTION_OWNED'
