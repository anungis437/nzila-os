targetScope = 'resourceGroup'

@description('Conditional local design only. Control-plane bootstrap must first prove this network and subnets.')
param vnetName string = 'nzila-g3-001-vnet'
param tags object
@minLength(64)
@maxLength(64)
param authoritySha256 string
param producerPrincipalId string
@allowed(['User', 'ServicePrincipal'])
param producerPrincipalType string
@description('Exact existing G2 registry ARM ID from a future baseline; never updated or deleted here.')
param targetRegistryId string

var location = 'canadacentral'
var ownedTags = union(tags, {
  mission: 'NZ-20261008-INFRA-001'
  ownership: 'G3A_TRANSACTION_OWNED'
  authority_sha256: authoritySha256
})
var repositories = ['g3-build-source', 'g3-build-tooling']
var storageReaderRole = '2a2b9908-6ea1-4ae2-8e65-a410df84e7d1'

resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: vnetName
}
resource peSubnet 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' existing = {
  parent: vnet
  name: 'private-endpoints'
}
resource builderSubnet 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' existing = {
  parent: vnet
  name: 'builders'
}
resource reader 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: 'nzila-g3-input-reader-001'
  location: location
  tags: ownedTags
}
resource push 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: 'nzila-g3-build-push-001'
  location: location
  tags: ownedTags
}
resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: 'nzilag3bootstrap001'
  location: location
  tags: ownedTags
  kind: 'StorageV2'
  sku: { name: 'Standard_LRS' }
  properties: {
    accessTier: 'Hot'
    supportsHttpsTrafficOnly: true
    minimumTlsVersion: 'TLS1_2'
    allowSharedKeyAccess: false
    allowBlobPublicAccess: false
    publicNetworkAccess: 'Disabled'
    networkAcls: {
      defaultAction: 'Deny'
      bypass: 'None'
      ipRules: []
      virtualNetworkRules: []
    }
  }
}
resource blob 'Microsoft.Storage/storageAccounts/blobServices@2023-05-01' = {
  parent: storage
  name: 'default'
  properties: { isVersioningEnabled: false }
}
resource container 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-05-01' = {
  parent: blob
  name: 'bootstrap'
  properties: { publicAccess: 'None' }
}
resource blobReader 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(container.id, reader.id, storageReaderRole, 'NZ-20261008-INFRA-001-G3A')
  scope: container
  properties: {
    principalId: reader.properties.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageReaderRole)
    description: 'G3A_TRANSACTION_OWNED bootstrap container reader.'
  }
}
resource blobProducer 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(container.id, producerPrincipalId, 'ba92f5b4-2d11-453d-a403-e96b0029c9fe', 'NZ-20261008-INFRA-001-G3A')
  scope: container
  properties: {
    principalId: producerPrincipalId
    principalType: producerPrincipalType
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'ba92f5b4-2d11-453d-a403-e96b0029c9fe')
    description: 'G3A_TRANSACTION_OWNED producer; revoke exact ID before builder.'
  }
}
resource input 'Microsoft.ContainerRegistry/registries@2025-11-01' = {
  name: 'nzilag3inputs001'
  location: location
  tags: ownedTags
  sku: { name: 'Premium' }
  properties: {
    adminUserEnabled: false
    anonymousPullEnabled: false
    publicNetworkAccess: 'Disabled'
    networkRuleBypassOptions: 'None'
    roleAssignmentMode: 'AbacRepositoryPermissions'
    dataEndpointEnabled: true
    networkRuleSet: { defaultAction: 'Deny', ipRules: [] }
  }
}
module inputReaders 'repository-reader.bicep' = [for repository in repositories: {
  name: 'g3a-${repository}-reader'
  params: {
    registryName: input.name
    principalId: reader.properties.principalId
    repository: repository
  }
}]
resource inputProducers 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for repository in repositories: {
  name: guid(input.id, producerPrincipalId, '2a1e307c-b015-4ebd-883e-5b7698a07328', repository, 'NZ-20261008-INFRA-001-G3A')
  scope: input
  properties: {
    principalId: producerPrincipalId
    principalType: producerPrincipalType
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '2a1e307c-b015-4ebd-883e-5b7698a07328')
    conditionVersion: '2.0'
    condition: '''
(
  (!(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/content/read'})
   AND !(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/content/write'})
   AND !(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/metadata/read'})
   AND !(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/metadata/write'}))
  OR (@Request[Microsoft.ContainerRegistry/registries/repositories:name] StringEquals '${repository}')
)
'''
    description: 'G3A_TRANSACTION_OWNED producer; revoke exact ID before builder.'
  }
}]
resource blobZone 'Microsoft.Network/privateDnsZones@2020-06-01' = {
  name: 'privatelink.blob.${environment().suffixes.storage}'
  location: 'global'
  tags: ownedTags
}
resource acrZone 'Microsoft.Network/privateDnsZones@2020-06-01' = {
  name: 'privatelink.azurecr.io'
  location: 'global'
  tags: ownedTags
}
resource blobLink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2020-06-01' = {
  parent: blobZone
  name: 'nzila-g3-001-link'
  location: 'global'
  tags: ownedTags
  properties: { registrationEnabled: false, virtualNetwork: { id: vnet.id } }
}
resource acrLink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2020-06-01' = {
  parent: acrZone
  name: 'nzila-g3-001-link'
  location: 'global'
  tags: ownedTags
  properties: { registrationEnabled: false, virtualNetwork: { id: vnet.id } }
}
var endpoints = [
  { name: 'nzila-g3-bootstrap-001-pe', service: storage.id, group: 'blob', zone: blobZone.id }
  { name: 'nzila-g3-input-001-pe', service: input.id, group: 'registry', zone: acrZone.id }
  { name: 'nzila-g3-target-001-pe', service: targetRegistryId, group: 'registry', zone: acrZone.id }
]
resource privateEndpoints 'Microsoft.Network/privateEndpoints@2024-05-01' = [for endpoint in endpoints: {
  name: endpoint.name
  location: location
  tags: ownedTags
  properties: {
    subnet: { id: peSubnet.id }
    privateLinkServiceConnections: [{
      name: endpoint.group
      properties: { privateLinkServiceId: endpoint.service, groupIds: [endpoint.group] }
    }]
  }
}]
resource dnsGroups 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2024-05-01' = [for (endpoint, i) in endpoints: {
  name: '${privateEndpoints[i].name}/default'
  properties: {
    privateDnsZoneConfigs: [{
      name: endpoint.group
      properties: { privateDnsZoneId: endpoint.zone }
    }]
  }
}]

var producerIds = [for i in range(0, 2): inputProducers[i].id]
var readerIds = [inputReaders[0].outputs.assignmentId, inputReaders[1].outputs.assignmentId]
var endpointIds = [for i in range(0, 3): privateEndpoints[i].id]
var dnsGroupIds = [for i in range(0, 3): dnsGroups[i].id]

output bindings object = {
  readerIdentityId: reader.id
  readerClientId: reader.properties.clientId
  pushIdentityId: push.id
  pushPrincipalId: push.properties.principalId
  builderSubnetId: builderSubnet.id
  privateEndpointSubnet: '10.91.3.0/24'
  storageId: storage.id
  inputRegistryId: input.id
  producerGrantIds: concat([blobProducer.id], producerIds)
  readerGrantIds: concat([blobReader.id], readerIds)
  exactOwnedCandidateIds: concat(
    [storage.id, blob.id, container.id, reader.id, push.id, input.id, blobZone.id, acrZone.id, blobLink.id, acrLink.id],
    endpointIds,
    dnsGroupIds
  )
  producerTransport: 'UNQUALIFIED_PRIVATE_PRODUCER_REQUIRED_NO_PUBLIC_FALLBACK'
  targetRole: 'SEPARATE_TARGET_GROUP_MODULE_REQUIRES_BASELINE_AND_RECEIPT'
  runtimeCse: 'NOT_EMITTED_UNQUALIFIED_PRODUCTION_GUEST_DELIVERY'
  cleanup: 'EXACT_CREATION_RECEIPTS_ONLY_NO_RESOURCE_GROUP_CASCADE'
}
