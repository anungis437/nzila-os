param registryName string
param principalId string

resource registry 'Microsoft.ContainerRegistry/registries@2025-11-01' existing = {
  name: registryName
}
var roleId = subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '2a1e307c-b015-4ebd-883e-5b7698a07328')
resource assignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(registry.id, principalId, roleId, 'g3-synthetic-runtime', 'NZ-20261008-INFRA-001-G3A')
  scope: registry
  properties: {
    principalId: principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: roleId
    conditionVersion: '2.0'
    condition: '''
(
  (!(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/content/read'})
   AND !(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/content/write'})
   AND !(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/metadata/read'})
   AND !(ActionMatches{'Microsoft.ContainerRegistry/registries/repositories/metadata/write'}))
  OR (@Request[Microsoft.ContainerRegistry/registries/repositories:name] StringEquals 'g3-synthetic-runtime')
)
'''
    description: 'G3A_TRANSACTION_OWNED exact runtime repository writer; no registry-wide fallback.'
  }
}
output candidateRoleId string = assignment.id
output cleanup string = 'DELETE_ONLY_AFTER_EXACT_ROLE_CREATION_RECEIPT_AND_BASELINE_ABSENCE'
