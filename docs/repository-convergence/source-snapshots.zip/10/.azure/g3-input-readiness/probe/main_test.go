package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"
)

func TestSigningBindsExactMethodPathNonceExpiry(t *testing.T) {
	pub, key, _ := ed25519.GenerateKey(rand.Reader)
	request, err := signedRequest(context.Background(), "bound.example", "/proof/identity", key)
	if err != nil {
		t.Fatal(err)
	}
	signature, _ := base64.StdEncoding.DecodeString(request.Header.Get("X-G3-Signature"))
	content := "GET\n/proof/identity\n" + request.Header.Get("X-G3-Nonce") + "\n" + request.Header.Get("X-G3-Expiry")
	if !ed25519.Verify(pub, []byte(content), signature) || ed25519.Verify(pub, []byte(content+"foreign"), signature) {
		t.Fatal("signature binding")
	}
}

func TestHostnameAndPrincipalContract(t *testing.T) {
	c := configuration{"nzila-g3-test-001-health.bound.canadacentral.azurecontainerapps.io",
		"aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee", "g3-" + strings.Repeat("a", 32)}
	if validate(c) != nil {
		t.Fatal("valid target")
	}
	for _, host := range []string{"foreign.example", c.Hostname + "/foreign", "nzila-g3-test-001-health.bound.eastus.azurecontainerapps.io"} {
		c.Hostname = host
		if validate(c) == nil {
			t.Fatal("unbound target")
		}
	}
}

func TestTLSAndNegativeNotMissingObject(t *testing.T) {
	for _, code := range []int{200, 403, 404, 503} {
		response := &http.Response{StatusCode: code, Body: io.NopCloser(strings.NewReader(
			`{"status":"DENIED","authorization":"AUTHENTICATED_REGISTRY_HTTP_DENIED",` +
				`"hostname":"nzilag2tzo75uuozprbo.azurecr.io","tls":"PASS",` +
				`"resolved_private_ips":["10.91.3.4"],"connected_private_ip":"10.91.3.4"}`)),
			TLS: &tls.ConnectionState{HandshakeComplete: true, VerifiedChains: [][]*x509.Certificate{{{}}}}}
		_, err := parseWitness(response, configuration{}, "/proof/runtime-acr-read")
		if (err == nil) != (code == 200) {
			t.Fatal("negative classification", code)
		}

	}
	response := &http.Response{StatusCode: 200, Body: io.NopCloser(strings.NewReader(`{"status":"ok"}`))}
	if _, err := parseWitness(response, configuration{}, "/health"); err == nil {
		t.Fatal("unverified TLS accepted")
	}
}

func TestPrivateWitnessAndNegativeBinding(t *testing.T) {
	c := configuration{PrincipalID: "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee", ChallengeID: "g3-" + strings.Repeat("a", 32)}
	base := map[string]any{
		"status": "PASS", "hostname": "nzl-g3-test-001-kv.vault.azure.net",
		"principal_id": c.PrincipalID, "tenant_id": "5082b8be-b04d-4a13-b61c-b6397670177b",
		"identity_binding": "CLAIMS_MATCH_RESOURCE_ACCEPTED_TOKEN", "challenge_id": c.ChallengeID,
		"secret_challenge": "PASS", "authorization": "AUTHENTICATED_HTTP_200", "tls": "PASS",
		"resolved_private_ips": []string{"10.91.3.4"}, "connected_private_ip": "10.91.3.4",
	}
	parse := func(path string, body map[string]any) error {
		raw, _ := json.Marshal(body)
		response := &http.Response{StatusCode: 200, Body: io.NopCloser(strings.NewReader(string(raw))),
			TLS: &tls.ConnectionState{HandshakeComplete: true, VerifiedChains: [][]*x509.Certificate{{{}}}}}
		_, err := parseWitness(response, c, path)
		return err
	}
	for _, path := range []string{"/proof/identity", "/proof/secret"} {
		if err := parse(path, base); err != nil {
			t.Fatal(err)
		}
		for _, field := range []string{"principal_id", "tenant_id", "hostname", "identity_binding",
			"challenge_id", "secret_challenge", "authorization", "tls", "connected_private_ip"} {
			old := base[field]
			base[field] = "foreign"
			if parse(path, base) == nil {
				t.Fatal("unbound witness field", field)
			}
			base[field] = old
		}
		base["connected_private_ip"] = "10.91.3.5"
		if parse(path, base) == nil {
			t.Fatal("peer not in resolved IPs")
		}
		base["connected_private_ip"] = "10.91.3.4"
	}
	for _, path := range []string{"/proof/secret-denied", "/proof/pull-token", "/proof/runtime-acr-read", "/proof/foreign"} {
		if parse(path, map[string]any{"status": "DENIED"}) == nil {
			t.Fatal("unclassified denial accepted", path)
		}
	}
	if err := parse("/proof/pull-token", map[string]any{"status": "DENIED",
		"authorization": "LOCAL_IDENTITY_HTTP_DENIED", "http_status": 403}); err != nil {
		t.Fatal(err)
	}
	if parse("/proof/pull-token", map[string]any{"status": "DENIED",
		"authorization": "LOCAL_IDENTITY_HTTP_DENIED", "http_status": 400}) == nil {
		t.Fatal("HTTP 400 classified as lifecycle denial")
	}
	base["status"], base["authorization"] = "DENIED", "AUTHENTICATED_HTTP_403"
	if err := parse("/proof/secret-denied", base); err != nil {
		t.Fatal(err)
	}
}

func TestHealthReadyFrozenResponseContract(t *testing.T) {
	for _, path := range []string{"/health", "/ready"} {
		for _, status := range []string{"ok", "not_ready", "ready"} {
			response := &http.Response{StatusCode: 200, Body: io.NopCloser(strings.NewReader(`{"status":"` + status + `"}`)),
				TLS: &tls.ConnectionState{HandshakeComplete: true, VerifiedChains: [][]*x509.Certificate{{{}}}}}
			_, err := parseWitness(response, configuration{}, path)
			if (err == nil) != (status == "ok") {
				t.Fatal("frozen health/ready response semantics")
			}
		}
	}
}
