module nzila.example/g3-private-probe

go 1.27.2
