package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"time"
)

type configuration struct {
	Hostname    string `json:"hostname"`
	PrincipalID string `json:"runtimePrincipalId"`
	ChallengeID string `json:"challengeId"`
}

type observation struct {
	Path       string `json:"path"`
	HTTPStatus int    `json:"httpStatus"`
	Status     string `json:"status"`
}

func validate(c configuration) error {
	if !regexp.MustCompile(`^nzila-g3-test-001-health\.[a-z0-9.-]+\.canadacentral\.azurecontainerapps\.io$`).MatchString(c.Hostname) ||
		!regexp.MustCompile(`^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$`).MatchString(c.PrincipalID) ||
		!regexp.MustCompile(`^g3-[0-9a-f]{32}$`).MatchString(c.ChallengeID) {
		return errors.New("PROBE_TARGET_BINDING_INVALID")
	}
	return nil
}

func privateClient(ctx context.Context, host string) (*http.Client, []string, error) {
	_, subnet, _ := net.ParseCIDR("10.91.0.0/27")
	addresses, err := net.DefaultResolver.LookupIPAddr(ctx, host)
	if err != nil || len(addresses) == 0 {
		return nil, nil, errors.New("PROBE_DNS_INCONCLUSIVE")
	}
	ips := []string{}
	for _, address := range addresses {
		if !subnet.Contains(address.IP) {
			return nil, nil, errors.New("PROBE_DNS_OUTSIDE_APPS_SUBNET")
		}
		ips = append(ips, address.IP.String())
	}
	transport := &http.Transport{
		Proxy: nil, DisableKeepAlives: true,
		DialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
			expectedHost, port, err := net.SplitHostPort(address)
			if err != nil || expectedHost != host || port != "443" {
				return nil, errors.New("PROBE_DIAL_TARGET_INVALID")
			}
			connection, err := (&net.Dialer{Timeout: 5 * time.Second}).DialContext(ctx, network, net.JoinHostPort(ips[0], "443"))
			if err != nil {
				return nil, errors.New("PROBE_CONNECT_INCONCLUSIVE")
			}
			peer, _, err := net.SplitHostPort(connection.RemoteAddr().String())
			if err != nil || peer != ips[0] {
				connection.Close()
				return nil, errors.New("PROBE_PEER_MISMATCH")
			}
			return connection, nil
		},
	}
	return &http.Client{
		Transport: transport, Timeout: 25 * time.Second,
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}, ips, nil
}

func signedRequest(ctx context.Context, host, path string, key ed25519.PrivateKey) (*http.Request, error) {
	nonce := make([]byte, 32)
	if _, err := rand.Read(nonce); err != nil {
		return nil, errors.New("PROBE_ENTROPY_FAILURE")
	}
	nonceText := fmt.Sprintf("%x", nonce)
	expiry := strconv.FormatInt(time.Now().Unix()+60, 10)
	request, err := http.NewRequestWithContext(ctx, "GET", (&url.URL{Scheme: "https", Host: host, Path: path}).String(), nil)
	if err != nil {
		return nil, errors.New("PROBE_REQUEST_INVALID")
	}
	request.Header.Set("X-G3-Nonce", nonceText)
	request.Header.Set("X-G3-Expiry", expiry)
	request.Header.Set("X-G3-Signature", base64.StdEncoding.EncodeToString(ed25519.Sign(key,
		[]byte("GET\n"+path+"\n"+nonceText+"\n"+expiry))))
	return request, nil
}

func parseWitness(response *http.Response, c configuration, path string) (observation, error) {
	result := observation{Path: path, HTTPStatus: response.StatusCode}
	defer response.Body.Close()
	if response.TLS == nil || !response.TLS.HandshakeComplete || len(response.TLS.VerifiedChains) == 0 {
		return result, errors.New("PROBE_TLS_INCONCLUSIVE")
	}
	raw, err := io.ReadAll(io.LimitReader(response.Body, 65537))
	if err != nil || len(raw) > 65536 {
		return result, errors.New("PROBE_RESPONSE_BOUND")
	}
	var body struct {
		Status          string   `json:"status"`
		Hostname        string   `json:"hostname"`
		PrincipalID     string   `json:"principal_id"`
		ChallengeID     string   `json:"challenge_id"`
		Challenge       string   `json:"secret_challenge"`
		TLS             string   `json:"tls"`
		IPs             []string `json:"resolved_private_ips"`
		PeerIP          string   `json:"connected_private_ip"`
		IdentityBinding string   `json:"identity_binding"`
		Authorization   string   `json:"authorization"`
		TenantID        string   `json:"tenant_id"`
		ResourceHTTP    int      `json:"http_status"`
	}
	if json.Unmarshal(raw, &body) != nil || response.StatusCode != 200 {
		return result, errors.New("PROBE_HTTP_OR_SCHEMA_INCONCLUSIVE")
	}
	result.Status = body.Status
	privateWitness := func(host string) bool {
		_, subnet, _ := net.ParseCIDR("10.91.3.0/24")
		if body.Hostname != host || body.TLS != "PASS" || len(body.IPs) == 0 {
			return false
		}
		foundPeer := false
		for _, address := range body.IPs {
			if !subnet.Contains(net.ParseIP(address)) {
				return false
			}
			foundPeer = foundPeer || address == body.PeerIP
		}
		return foundPeer
	}
	runtimeIdentity := func() bool {
		return body.PrincipalID == c.PrincipalID &&
			body.TenantID == "5082b8be-b04d-4a13-b61c-b6397670177b" &&
			body.IdentityBinding == "CLAIMS_MATCH_RESOURCE_ACCEPTED_TOKEN"
	}
	switch path {
	case "/health":
		if body.Status != "ok" {
			return result, errors.New("PROBE_HEALTH_FAILURE")
		}
	case "/ready":
		if body.Status != "ok" {
			return result, errors.New("PROBE_READY_FAILURE")
		}
	case "/proof/identity", "/proof/secret":
		if body.Status != "PASS" || !runtimeIdentity() ||
			!privateWitness("nzl-g3-test-001-kv.vault.azure.net") ||
			body.ChallengeID != c.ChallengeID || body.Challenge != "PASS" ||
			body.Authorization != "AUTHENTICATED_HTTP_200" {
			return result, errors.New("PROBE_PRIVATE_WITNESS_BINDING_FAILURE")
		}
	case "/proof/secret-denied":
		if body.Status != "DENIED" || body.Authorization != "AUTHENTICATED_HTTP_403" ||
			!runtimeIdentity() || !privateWitness("nzl-g3-test-001-kv.vault.azure.net") {
			return result, errors.New("PROBE_SECRET_DENIAL_INCONCLUSIVE")
		}
	case "/proof/pull-token":
		if body.Status != "DENIED" || body.Authorization != "LOCAL_IDENTITY_HTTP_DENIED" || body.ResourceHTTP != 403 {
			return result, errors.New("PROBE_PULL_LIFECYCLE_DENIAL_INCONCLUSIVE")
		}
	case "/proof/runtime-acr-read", "/proof/runtime-acr-write", "/proof/runtime-build-read":
		authorization := body.Authorization == "AUTHENTICATED_REGISTRY_EXCHANGE_DENIED" ||
			body.Authorization == "AUTHENTICATED_REGISTRY_SCOPE_DENIED" ||
			body.Authorization == "AUTHENTICATED_REGISTRY_HTTP_DENIED"
		if body.Status != "DENIED" || !authorization ||
			!privateWitness("nzilag2tzo75uuozprbo.azurecr.io") {
			return result, errors.New("PROBE_REGISTRY_DENIAL_INCONCLUSIVE")
		}
	default:
		return result, errors.New("PROBE_PATH_UNBOUND")
	}
	return result, nil
}

func execute() error {
	publicKey, privateKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return errors.New("PROBE_ENTROPY_FAILURE")
	}
	defer func() {
		for index := range privateKey {
			privateKey[index] = 0
		}
	}()
	if err := json.NewEncoder(os.Stdout).Encode(map[string]string{"probePublicKey": base64.StdEncoding.EncodeToString(publicKey)}); err != nil {
		return errors.New("PROBE_PUBLIC_KEY_OUTPUT_FAILURE")
	}
	var c configuration
	if json.NewDecoder(io.LimitReader(os.Stdin, 4096)).Decode(&c) != nil {
		return errors.New("PROBE_CONFIGURATION_INVALID")
	}
	if err := validate(c); err != nil {
		return err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	client, ips, err := privateClient(ctx, c.Hostname)
	if err != nil {
		return err
	}
	defer client.CloseIdleConnections()
	observations := []observation{}
	for _, path := range []string{
		"/health", "/ready", "/proof/identity", "/proof/secret", "/proof/secret-denied",
		"/proof/pull-token", "/proof/runtime-acr-read", "/proof/runtime-acr-write", "/proof/runtime-build-read",
	} {
		request, err := signedRequest(ctx, c.Hostname, path, privateKey)
		if err != nil {
			return err
		}
		response, err := client.Do(request)
		if err != nil {
			return errors.New("PROBE_NETWORK_OR_TLS_INCONCLUSIVE")
		}
		result, err := parseWitness(response, c, path)
		if err != nil {
			return err
		}
		observations = append(observations, result)
	}
	if json.NewEncoder(os.Stdout).Encode(map[string]any{
		"status": "PASS", "privateIPs": ips, "observations": observations,
		"scope": "APP_WITNESSES_ONLY_PULL_REPOSITORY_PROBE_REQUIRES_SEPARATE_CALLER",
	}) != nil {
		return errors.New("PROBE_RESULT_OUTPUT_FAILURE")
	}
	return nil
}

func main() {
	if err := execute(); err != nil {
		json.NewEncoder(os.Stdout).Encode(map[string]string{"status": "INCONCLUSIVE", "stage": err.Error()})
		os.Exit(1)
	}
}
