targetScope = 'resourceGroup'

@description('Future authority must bind an absent G3-only registry name; never the G2 target.')
@minLength(5)
@maxLength(50)
param inputRegistryName string
param tags object
@allowed(['PRIVATE_LOCKED', 'PRODUCER_STAGING'])
param phase string = 'PRIVATE_LOCKED'
@description('Explicit future approval for the G3-only temporary producer ingress window.')
param stagingAuthorized bool = false
@description('One future-authority-bound producer IPv4 /32; empty in locked state.')
param producerIpv4Cidr string = ''

var allowProducer = phase == 'PRODUCER_STAGING' && stagingAuthorized

resource registry 'Microsoft.ContainerRegistry/registries@2025-11-01' = {
  name: inputRegistryName
  location: 'canadacentral'
  tags: tags
  sku: {name: 'Premium'}
  properties: {
    adminUserEnabled: false
    anonymousPullEnabled: false
    dataEndpointEnabled: true
    roleAssignmentMode: 'AbacRepositoryPermissions'
    publicNetworkAccess: allowProducer ? 'Enabled' : 'Disabled'
    networkRuleBypassOptions: 'None'
    networkRuleSet: {
      defaultAction: 'Deny'
      ipRules: allowProducer ? [
        {action: 'Allow', value: producerIpv4Cidr}
      ] : []
    }
  }
}

output registryId string = registry.id
output loginServer string = registry.properties.loginServer
output selectedPhase string = phase
output publicProducerWindowEnabled bool = allowProducer
