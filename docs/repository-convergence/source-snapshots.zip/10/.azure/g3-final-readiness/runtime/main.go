package main

import (
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

const vaultHost = "nzl-g3-test-001-kv.vault.azure.net"
const registryHost = "nzilag2tzo75uuozprbo.azurecr.io"
const tenantID = "5082b8be-b04d-4a13-b61c-b6397670177b"

var hex64 = regexp.MustCompile(`^[0-9a-f]{64}$`)
var guid = regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`)
var secretPath = regexp.MustCompile(`^/secrets/substrate-proof/[0-9a-f]{32}$`)

type config struct {
	Authority, SecretURI, ClientID, PrincipalID, PullClientID   string
	IdentityEndpoint, IdentityHeader, ChallengeID, ExpectedHash string
	PublicKey                                                   ed25519.PublicKey
}

func loadConfig(get func(string) string) (config, error) {
	c := config{
		Authority: get("G3_SOURCE_AUTHORITY"), SecretURI: get("G3_SECRET_URI"),
		ClientID: get("AZURE_CLIENT_ID"), PrincipalID: get("G3_RUNTIME_PRINCIPAL_ID"),
		PullClientID: get("G3_PULL_CLIENT_ID"), IdentityEndpoint: get("IDENTITY_ENDPOINT"),
		IdentityHeader: get("IDENTITY_HEADER"), ChallengeID: get("G3_CHALLENGE_ID"),
		ExpectedHash: get("G3_EXPECTED_SECRET_SHA256"),
	}
	key, err := base64.StdEncoding.DecodeString(get("G3_PROBE_PUBLIC_KEY"))
	if err != nil || len(key) != ed25519.PublicKeySize {
		return c, errors.New("PROBE_KEY_INVALID")
	}
	c.PublicKey = key
	u, err := url.Parse(c.SecretURI)
	if err != nil || u.Scheme != "https" || u.Host != vaultHost || u.User != nil ||
		u.RawQuery != "" || u.Fragment != "" || u.RawPath != "" || !secretPath.MatchString(u.Path) {
		return c, errors.New("SECRET_REFERENCE_INVALID")
	}
	if get("G3_ENVIRONMENT") != "integration-test" || get("G3_PROOF_MODE") != "synthetic-only" ||
		!hex64.MatchString(c.Authority) || !hex64.MatchString(c.ExpectedHash) ||
		!guid.MatchString(c.ClientID) || !guid.MatchString(c.PrincipalID) ||
		!guid.MatchString(c.PullClientID) || c.ClientID == c.PullClientID ||
		!regexp.MustCompile(`^g3-[0-9a-f]{32}$`).MatchString(c.ChallengeID) {
		return c, errors.New("CONFIG_BINDING_INVALID")
	}
	u, err = url.Parse(c.IdentityEndpoint)
	if err != nil || u.Scheme != "http" || u.User != nil || u.RawQuery != "" ||
		u.Fragment != "" || (u.Hostname() != "localhost" && !net.ParseIP(u.Hostname()).IsLoopback()) || c.IdentityHeader == "" {
		return c, errors.New("IDENTITY_ENDPOINT_INVALID")
	}
	return c, nil
}

type witness struct {
	Status          string   `json:"status"`
	Stage           string   `json:"stage,omitempty"`
	Hostname        string   `json:"hostname,omitempty"`
	ResolvedIPs     []string `json:"resolved_private_ips,omitempty"`
	PeerIP          string   `json:"connected_private_ip,omitempty"`
	TLS             string   `json:"tls,omitempty"`
	HTTPStatus      int      `json:"http_status,omitempty"`
	Authorization   string   `json:"authorization,omitempty"`
	PrincipalID     string   `json:"principal_id,omitempty"`
	TenantID        string   `json:"tenant_id,omitempty"`
	IdentityBinding string   `json:"identity_binding,omitempty"`
	ChallengeID     string   `json:"challenge_id,omitempty"`
	Challenge       string   `json:"secret_challenge,omitempty"`
}

type proofError string

func (e proofError) Error() string { return string(e) }

func bounded(resp *http.Response) ([]byte, error) {
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 65537))
	if err != nil || len(body) > 65536 {
		return nil, proofError("RESPONSE_INVALID")
	}
	return body, nil
}

func statusError(stage string, code int) error {
	return proofError(stage + "_HTTP_" + strconv.Itoa(code))
}

func noRedirect(_ *http.Request, _ []*http.Request) error { return http.ErrUseLastResponse }

func identityClient() *http.Client {
	return &http.Client{
		Timeout: 5 * time.Second, CheckRedirect: noRedirect,
		Transport: &http.Transport{Proxy: nil, DialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
			host, port, err := net.SplitHostPort(address)
			if err != nil {
				return nil, proofError("IDENTITY_ADDRESS_INVALID")
			}
			if host == "localhost" {
				host = "127.0.0.1"
			}
			if !net.ParseIP(host).IsLoopback() {
				return nil, proofError("IDENTITY_ADDRESS_NOT_LOCAL")
			}
			return (&net.Dialer{Timeout: 3 * time.Second}).DialContext(ctx, network, net.JoinHostPort(host, port))
		}},
	}
}

type claims struct {
	OID   string `json:"oid"`
	TID   string `json:"tid"`
	AppID string `json:"appid"`
	AZP   string `json:"azp"`
	AUD   string `json:"aud"`
	EXP   int64  `json:"exp"`
}

func tokenClaims(raw string, c config, audience string, now time.Time) (claims, error) {
	var result claims
	parts := strings.Split(raw, ".")
	if len(parts) != 3 {
		return result, proofError("TOKEN_FORMAT_INVALID")
	}
	body, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil || len(body) > 16384 || json.Unmarshal(body, &result) != nil {
		return result, proofError("TOKEN_CLAIMS_INVALID")
	}
	client := result.AppID
	if client == "" {
		client = result.AZP
	}
	if result.OID != c.PrincipalID || result.TID != tenantID || client != c.ClientID ||
		strings.TrimRight(result.AUD, "/") != strings.TrimRight(audience, "/") || result.EXP <= now.Unix() {
		return result, proofError("TOKEN_BINDING_INVALID")
	}
	return result, nil
}

func acquire(ctx context.Context, c config, client *http.Client, clientID, audience string) (string, int, error) {
	u, err := url.Parse(c.IdentityEndpoint)
	if err != nil {
		return "", 0, proofError("IDENTITY_ENDPOINT_INVALID")
	}
	q := u.Query()
	q.Set("api-version", "2019-08-01")
	q.Set("resource", audience)
	q.Set("client_id", clientID)
	u.RawQuery = q.Encode()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return "", 0, proofError("IDENTITY_REQUEST_INVALID")
	}
	req.Header.Set("X-IDENTITY-HEADER", c.IdentityHeader)
	resp, err := client.Do(req)
	if err != nil {
		return "", 0, proofError("IDENTITY_TRANSPORT_FAILURE")
	}
	code := resp.StatusCode
	body, err := bounded(resp)
	if err != nil {
		return "", code, err
	}
	if code != 200 {
		return "", code, statusError("IDENTITY", code)
	}
	var token struct {
		AccessToken string `json:"access_token"`
		ClientID    string `json:"client_id"`
	}
	if json.Unmarshal(body, &token) != nil || token.AccessToken == "" || token.ClientID != clientID {
		return "", code, proofError("IDENTITY_RESPONSE_INVALID")
	}
	return token.AccessToken, code, nil
}

type privateSession struct {
	Client *http.Client
	Trace  *witness
	Close  func()
}

type privateFactory func(context.Context, string) (*privateSession, error)

func openPrivate(ctx context.Context, host string) (*privateSession, error) {
	if host != vaultHost && host != registryHost {
		return nil, proofError("PRIVATE_HOST_FORBIDDEN")
	}
	addresses, err := net.DefaultResolver.LookupIPAddr(ctx, host)
	if err != nil || len(addresses) == 0 {
		return nil, proofError("PRIVATE_DNS_FAILURE")
	}
	_, allowed, _ := net.ParseCIDR("10.91.3.0/24")
	trace := &witness{Hostname: host}
	seen := map[string]bool{}
	for _, address := range addresses {
		if !allowed.Contains(address.IP) {
			return nil, proofError("PRIVATE_DNS_OUTSIDE_ENDPOINT_SUBNET")
		}
		ip := address.IP.String()
		if !seen[ip] {
			trace.ResolvedIPs = append(trace.ResolvedIPs, ip)
			seen[ip] = true
		}
	}
	pinned := trace.ResolvedIPs[0]
	transport := &http.Transport{
		Proxy: nil, DisableKeepAlives: true,
		TLSClientConfig:     &tls.Config{MinVersion: tls.VersionTLS12, ServerName: host},
		TLSHandshakeTimeout: 5 * time.Second,
		DialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
			if address != net.JoinHostPort(host, "443") {
				return nil, proofError("PRIVATE_DESTINATION_INVALID")
			}
			conn, err := (&net.Dialer{Timeout: 5 * time.Second}).DialContext(ctx, "tcp", net.JoinHostPort(pinned, "443"))
			if err != nil {
				return nil, proofError("PRIVATE_CONNECT_FAILURE")
			}
			peer, _, err := net.SplitHostPort(conn.RemoteAddr().String())
			if err != nil || peer != pinned {
				conn.Close()
				return nil, proofError("PRIVATE_PEER_MISMATCH")
			}
			trace.PeerIP = peer
			return conn, nil
		},
	}
	return &privateSession{
		Client: &http.Client{Timeout: 10 * time.Second, Transport: transport, CheckRedirect: noRedirect},
		Trace:  trace, Close: transport.CloseIdleConnections,
	}, nil
}

func privateDo(ctx context.Context, session *privateSession, method, target, token string, data io.Reader) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, method, target, data)
	if err != nil {
		return nil, proofError("PRIVATE_REQUEST_INVALID")
	}
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	if data != nil {
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	}
	resp, err := session.Client.Do(req)
	if err != nil {
		return nil, proofError("PRIVATE_TRANSPORT_FAILURE")
	}
	if resp.TLS == nil || !resp.TLS.HandshakeComplete || len(resp.TLS.VerifiedChains) == 0 {
		resp.Body.Close()
		return nil, proofError("PRIVATE_TLS_UNVERIFIED")
	}
	session.Trace.TLS = "PASS"
	session.Trace.HTTPStatus = resp.StatusCode
	return resp, nil
}

type dependencies struct {
	Identity *http.Client
	Private  privateFactory
	Now      func() time.Time
}

func secretProof(ctx context.Context, c config, d dependencies, forbidden bool) (witness, error) {
	token, _, err := acquire(ctx, c, d.Identity, c.ClientID, "https://vault.azure.net")
	if err != nil {
		return witness{}, err
	}
	claims, err := tokenClaims(token, c, "https://vault.azure.net", d.Now())
	if err != nil {
		return witness{}, err
	}
	session, err := d.Private(ctx, vaultHost)
	if err != nil {
		return witness{}, err
	}
	defer session.Close()
	target := c.SecretURI
	if forbidden {
		target = "https://" + vaultHost + "/secrets/g3-forbidden-reference"
	}
	resp, err := privateDo(ctx, session, http.MethodGet, target+"?api-version=7.4", token, nil)
	if err != nil {
		return witness{}, err
	}
	code := resp.StatusCode
	body, err := bounded(resp)
	if err != nil {
		return witness{}, err
	}
	result := *session.Trace
	result.PrincipalID, result.TenantID = claims.OID, claims.TID
	if forbidden {
		if code != 403 {
			return result, statusError("FORBIDDEN_SECRET_EXPECT_403", code)
		}
		var denied struct {
			Error struct {
				Code  string `json:"code"`
				Inner struct {
					Code string `json:"code"`
				} `json:"innererror"`
			} `json:"error"`
		}
		if json.Unmarshal(body, &denied) != nil || denied.Error.Code != "Forbidden" ||
			denied.Error.Inner.Code != "ForbiddenByRbac" {
			return result, proofError("SECRET_403_NOT_PROVEN_RBAC_DENIAL")
		}
		result.Status, result.Authorization = "DENIED", "AUTHENTICATED_HTTP_403"
		result.IdentityBinding = "CLAIMS_MATCH_RESOURCE_ACCEPTED_TOKEN"
		return result, nil
	}
	if code != 200 {
		return result, statusError("SECRET", code)
	}
	var secret struct {
		Value string `json:"value"`
		ID    string `json:"id"`
	}
	if json.Unmarshal(body, &secret) != nil || secret.Value == "" || secret.ID != c.SecretURI {
		return result, proofError("SECRET_BINDING_INVALID")
	}
	sum := sha256.Sum256([]byte(secret.Value))
	expected, _ := hex.DecodeString(c.ExpectedHash)
	if subtle.ConstantTimeCompare(sum[:], expected) != 1 {
		return result, proofError("SECRET_CHALLENGE_MISMATCH")
	}
	result.Status, result.Authorization = "PASS", "AUTHENTICATED_HTTP_200"
	result.IdentityBinding = "CLAIMS_MATCH_RESOURCE_ACCEPTED_TOKEN"
	result.ChallengeID, result.Challenge = c.ChallengeID, "PASS"
	return result, nil
}

func pullTokenProof(ctx context.Context, c config, d dependencies) (witness, error) {
	_, code, err := acquire(ctx, c, d.Identity, c.PullClientID, "https://vault.azure.net")
	if err != nil && code == 403 {
		return witness{Status: "DENIED", HTTPStatus: code, Authorization: "LOCAL_IDENTITY_HTTP_DENIED"}, nil
	}
	if err != nil {
		return witness{}, err
	}
	return witness{}, proofError("PULL_TOKEN_UNEXPECTEDLY_AVAILABLE")
}

func registryProof(ctx context.Context, c config, d dependencies, repository string, write bool) (witness, error) {
	if repository != "g3-synthetic-runtime" && repository != "g2-tooling" {
		return witness{}, proofError("REPOSITORY_FORBIDDEN")
	}
	raw, _, err := acquire(ctx, c, d.Identity, c.ClientID, "https://containerregistry.azure.net")
	if err != nil {
		return witness{}, err
	}
	if _, err = tokenClaims(raw, c, "https://containerregistry.azure.net", d.Now()); err != nil {
		return witness{}, err
	}
	session, err := d.Private(ctx, registryHost)
	if err != nil {
		return witness{}, err
	}
	defer session.Close()
	base := "https://" + registryHost
	form := url.Values{"grant_type": {"access_token"}, "service": {registryHost}, "tenant": {tenantID}, "access_token": {raw}}
	resp, err := privateDo(ctx, session, http.MethodPost, base+"/oauth2/exchange", "", strings.NewReader(form.Encode()))
	if err != nil {
		return witness{}, err
	}
	code := resp.StatusCode
	body, err := bounded(resp)
	if err != nil {
		return witness{}, err
	}
	if code == 401 || code == 403 {
		result := *session.Trace
		result.Status, result.Authorization = "DENIED", "AUTHENTICATED_REGISTRY_EXCHANGE_DENIED"
		return result, nil
	}
	if code != 200 {
		return witness{}, statusError("REGISTRY_EXCHANGE", code)
	}
	var refresh struct {
		Token string `json:"refresh_token"`
	}
	if json.Unmarshal(body, &refresh) != nil || refresh.Token == "" {
		return witness{}, proofError("REGISTRY_EXCHANGE_INVALID")
	}
	action := "pull"
	if write {
		action = "pull,push"
	}
	form = url.Values{"grant_type": {"refresh_token"}, "service": {registryHost},
		"scope": {"repository:" + repository + ":" + action}, "refresh_token": {refresh.Token}}
	resp, err = privateDo(ctx, session, http.MethodPost, base+"/oauth2/token", "", strings.NewReader(form.Encode()))
	if err != nil {
		return witness{}, err
	}
	code = resp.StatusCode
	body, err = bounded(resp)
	if err != nil {
		return witness{}, err
	}
	if code == 401 || code == 403 {
		result := *session.Trace
		result.Status, result.Authorization = "DENIED", "AUTHENTICATED_REGISTRY_SCOPE_DENIED"
		return result, nil
	}
	if code != 200 {
		return witness{}, statusError("REGISTRY_TOKEN", code)
	}
	var access struct {
		Token string `json:"access_token"`
	}
	if json.Unmarshal(body, &access) != nil || access.Token == "" {
		return witness{}, proofError("REGISTRY_TOKEN_INVALID")
	}
	method, target := http.MethodGet, base+"/v2/"+repository+"/tags/list?n=1"
	if write {
		method, target = http.MethodPost, base+"/v2/"+repository+"/blobs/uploads/"
	}
	resp, err = privateDo(ctx, session, method, target, access.Token, nil)
	if err != nil {
		return witness{}, err
	}
	code = resp.StatusCode
	location := resp.Header.Get("Location")
	if _, err = bounded(resp); err != nil {
		return witness{}, err
	}
	result := *session.Trace
	if write && code == 202 {
		u, err := url.Parse(location)
		if err != nil {
			return result, proofError("UNEXPECTED_UPLOAD_CLEANUP_LOCATION_INVALID")
		}
		u = (&url.URL{Scheme: "https", Host: registryHost}).ResolveReference(u)
		if u.Scheme != "https" || u.Host != registryHost || u.User != nil ||
			!strings.HasPrefix(u.Path, "/v2/"+repository+"/blobs/uploads/") {
			return result, proofError("UNEXPECTED_UPLOAD_CLEANUP_LOCATION_INVALID")
		}
		cleanup, err := privateDo(ctx, session, http.MethodDelete, u.String(), access.Token, nil)
		if err != nil {
			return result, proofError("UNEXPECTED_UPLOAD_CLEANUP_FAILED")
		}
		cleanupCode := cleanup.StatusCode
		if _, err = bounded(cleanup); err != nil || cleanupCode != 204 {
			return result, proofError("UNEXPECTED_UPLOAD_CLEANUP_FAILED")
		}
		return result, proofError("REGISTRY_WRITE_UNEXPECTEDLY_ALLOWED_UPLOAD_ABORTED")
	}
	if code != 401 && code != 403 {
		return result, statusError("REGISTRY_DENIAL_EXPECT_401_OR_403", code)
	}
	result.Status, result.Authorization = "DENIED", "AUTHENTICATED_REGISTRY_HTTP_DENIED"
	return result, nil
}

type runtime struct {
	Config config
	Deps   dependencies
	Proof  func(context.Context, string) (witness, error)
	mu     sync.Mutex
	nonces map[string]int64
	slots  chan struct{}
}

func (s *runtime) authorize(r *http.Request) bool {
	if r.URL.RawQuery != "" || r.URL.RawPath != "" {
		return false
	}
	expiryText, nonce := r.Header.Get("X-G3-Expiry"), r.Header.Get("X-G3-Nonce")
	expiry, err := strconv.ParseInt(expiryText, 10, 64)
	now := s.Deps.Now().Unix()
	if err != nil || expiry <= now || expiry > now+60 || !hex64.MatchString(nonce) {
		return false
	}
	sig, err := base64.StdEncoding.DecodeString(r.Header.Get("X-G3-Signature"))
	canonical := r.Method + "\n" + r.URL.Path + "\n" + nonce + "\n" + expiryText
	if err != nil || !ed25519.Verify(s.Config.PublicKey, []byte(canonical), sig) {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for n, until := range s.nonces {
		if until <= now {
			delete(s.nonces, n)
		}
	}
	if _, exists := s.nonces[nonce]; exists || len(s.nonces) >= 1024 {
		return false
	}
	s.nonces[nonce] = expiry
	return true
}

func writeJSON(w http.ResponseWriter, code int, body interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	if err := json.NewEncoder(w).Encode(body); err != nil {
		log.Print("RESPONSE_WRITE_FAILURE")
	}
}

func (s *runtime) invoke(ctx context.Context, path string) (witness, error) {
	switch path {
	case "/ready", "/probes/ready", "/proof/identity", "/proof/secret":
		return secretProof(ctx, s.Config, s.Deps, false)
	case "/proof/secret-denied":
		return secretProof(ctx, s.Config, s.Deps, true)
	case "/proof/pull-token":
		return pullTokenProof(ctx, s.Config, s.Deps)
	case "/proof/runtime-acr-read":
		return registryProof(ctx, s.Config, s.Deps, "g3-synthetic-runtime", false)
	case "/proof/runtime-acr-write":
		return registryProof(ctx, s.Config, s.Deps, "g3-synthetic-runtime", true)
	case "/proof/runtime-build-read":
		return registryProof(ctx, s.Config, s.Deps, "g2-tooling", false)
	default:
		return witness{}, proofError("PROOF_ROUTE_INVALID")
	}
}

func (s *runtime) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.Header().Set("Allow", http.MethodGet)
		writeJSON(w, 405, map[string]string{"status": "method_not_allowed"})
		return
	}
	switch r.URL.Path {
	case "/health", "/ready", "/probes/startup", "/probes/live", "/probes/ready",
		"/proof/identity", "/proof/secret", "/proof/secret-denied", "/proof/pull-token",
		"/proof/runtime-acr-read", "/proof/runtime-acr-write", "/proof/runtime-build-read":
	default:
		writeJSON(w, 404, map[string]string{"status": "not_found"})
		return
	}
	if r.URL.RawQuery != "" || r.URL.RawPath != "" ||
		(!strings.HasPrefix(r.URL.Path, "/probes/") && !s.authorize(r)) {
		writeJSON(w, 401, map[string]string{"status": "unauthorized"})
		return
	}
	if r.URL.Path == "/health" || r.URL.Path == "/probes/live" || r.URL.Path == "/probes/startup" {
		writeJSON(w, 200, map[string]string{"status": "ok"})
		return
	}
	select {
	case s.slots <- struct{}{}:
		defer func() { <-s.slots }()
	default:
		writeJSON(w, 429, map[string]string{"status": "proof_busy"})
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
	defer cancel()
	result, err := s.Proof(ctx, r.URL.Path)
	if err != nil {
		if strings.HasPrefix(r.URL.Path, "/proof/") {
			stage := "PROOF_INTERNAL_FAILURE"
			var safe proofError
			if errors.As(err, &safe) {
				stage = string(safe)
			}
			log.Print(stage)
			writeJSON(w, 503, witness{Status: "INCONCLUSIVE", Stage: stage})
		} else {
			log.Print("READINESS_DEPENDENCY_FAILURE")
			writeJSON(w, 503, map[string]string{"status": "not_ready"})
		}
		return
	}
	if strings.HasPrefix(r.URL.Path, "/proof/") {
		writeJSON(w, 200, result)
	} else {
		writeJSON(w, 200, map[string]string{"status": "ok"})
	}
}

func main() {
	c, err := loadConfig(os.Getenv)
	if err != nil {
		log.Fatal(err)
	}
	s := &runtime{Config: c, Deps: dependencies{Identity: identityClient(), Private: openPrivate, Now: time.Now},
		nonces: map[string]int64{}, slots: make(chan struct{}, 1)}
	s.Proof = s.invoke
	server := &http.Server{Addr: ":3000", Handler: s, ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout: 10 * time.Second, WriteTimeout: 25 * time.Second, IdleTimeout: 30 * time.Second}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	done := make(chan struct{})
	go func() {
		<-ctx.Done()
		shutdown, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := server.Shutdown(shutdown); err != nil {
			log.Print("SHUTDOWN_FAILURE")
		}
		close(done)
	}()
	if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatal("SERVER_START_FAILURE")
	}
	<-done
}
