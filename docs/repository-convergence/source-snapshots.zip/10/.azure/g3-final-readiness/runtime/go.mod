module nzila.local/g3-final-synthetic

go 1.27.2
