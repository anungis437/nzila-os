package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"
	"time"
)

type transportFunc func(*http.Request) (*http.Response, error)

func (f transportFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func fixture(t *testing.T) (config, ed25519.PrivateKey, map[string]string) {
	t.Helper()
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256([]byte("local-synthetic-secret-not-a-credential"))
	env := map[string]string{
		"G3_ENVIRONMENT": "integration-test", "G3_SOURCE_AUTHORITY": strings.Repeat("a", 64),
		"G3_PROOF_MODE": "synthetic-only", "G3_PROBE_PUBLIC_KEY": base64.StdEncoding.EncodeToString(pub),
		"G3_SECRET_URI":           "https://" + vaultHost + "/secrets/substrate-proof/" + strings.Repeat("a", 32),
		"AZURE_CLIENT_ID":         "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
		"G3_RUNTIME_PRINCIPAL_ID": "11111111-2222-3333-4444-555555555555",
		"G3_PULL_CLIENT_ID":       "22222222-3333-4444-5555-666666666666",
		"IDENTITY_ENDPOINT":       "http://127.0.0.1:1234/msi/token", "IDENTITY_HEADER": "LOCAL_SYNTHETIC_ONLY",
		"G3_CHALLENGE_ID": "g3-" + strings.Repeat("b", 32), "G3_EXPECTED_SECRET_SHA256": hex.EncodeToString(sum[:]),
	}
	c, err := loadConfig(func(k string) string { return env[k] })
	if err != nil {
		t.Fatal(err)
	}
	return c, priv, env
}

func signed(path string, key ed25519.PrivateKey, expiry int64, nonce string) *http.Request {
	r := httptest.NewRequest("GET", path, nil)
	exp := strconv.FormatInt(expiry, 10)
	r.Header.Set("X-G3-Expiry", exp)
	r.Header.Set("X-G3-Nonce", nonce)
	r.Header.Set("X-G3-Signature", base64.StdEncoding.EncodeToString(ed25519.Sign(key, []byte("GET\n"+path+"\n"+nonce+"\n"+exp))))
	return r
}

func jwt(c config, audience string) string {
	b, _ := json.Marshal(claims{OID: c.PrincipalID, TID: tenantID, AppID: c.ClientID, AUD: audience, EXP: 2000000060})
	return "synthetic." + base64.RawURLEncoding.EncodeToString(b) + ".not-a-real-signature"
}

func identityMock(c config, status int, mismatch bool) *http.Client {
	return &http.Client{Transport: transportFunc(func(r *http.Request) (*http.Response, error) {
		if r.URL.Hostname() != "127.0.0.1" || r.Header.Get("X-IDENTITY-HEADER") != c.IdentityHeader ||
			r.URL.Query().Get("client_id") == "" {
			return nil, errors.New("RAW_SECRET_TOKEN")
		}
		audience := r.URL.Query().Get("resource")
		client := c.ClientID
		if mismatch {
			client = "foreign"
		}
		body, _ := json.Marshal(map[string]string{"access_token": jwt(c, audience), "client_id": client})
		return &http.Response{StatusCode: status, Body: io.NopCloser(strings.NewReader(string(body)))}, nil
	})}
}

func mockPrivate(handler func(*http.Request) (int, string, string), verified bool) privateFactory {
	return func(_ context.Context, host string) (*privateSession, error) {
		state := &tls.ConnectionState{HandshakeComplete: true}
		if verified {
			state.VerifiedChains = [][]*x509.Certificate{{{}}}
		}
		client := &http.Client{Transport: transportFunc(func(r *http.Request) (*http.Response, error) {
			code, body, location := handler(r)
			return &http.Response{StatusCode: code, Body: io.NopCloser(strings.NewReader(body)),
				TLS: state, Header: http.Header{"Location": []string{location}}}, nil
		})}
		return &privateSession{Client: client, Trace: &witness{Hostname: host, ResolvedIPs: []string{"10.91.3.4"}, PeerIP: "10.91.3.4"}, Close: func() {}}, nil
	}
}

func TestConfigFailsClosed(t *testing.T) {
	_, _, env := fixture(t)
	for k := range env {
		t.Run(k, func(t *testing.T) {
			cloned := map[string]string{}
			for key, v := range env {
				cloned[key] = v
			}
			cloned[k] = ""
			if _, err := loadConfig(func(k string) string { return cloned[k] }); err == nil {
				t.Fatal("missing input accepted")
			}
		})
	}
	for _, uri := range []string{
		"http://" + vaultHost + "/secrets/substrate-proof/" + strings.Repeat("a", 32),
		"https://foreign.vault.azure.net/secrets/substrate-proof/" + strings.Repeat("a", 32),
		env["G3_SECRET_URI"] + "?secret=leak", strings.ReplaceAll(env["G3_SECRET_URI"], "substrate-proof", "foreign"),
	} {
		env["G3_SECRET_URI"] = uri
		if _, err := loadConfig(func(k string) string { return env[k] }); err == nil {
			t.Fatal("bad URI accepted")
		}
	}
}

func TestIdentityEndpointCannotResolveOffHost(t *testing.T) {
	_, _, env := fixture(t)
	for _, host := range []string{"localhost", "127.0.0.1", "[::1]", "foreign.example", "169.254.169.254"} {
		env["IDENTITY_ENDPOINT"] = "http://" + host + ":1234/msi/token"
		_, err := loadConfig(func(k string) string { return env[k] })
		if (err == nil) != (host == "localhost" || host == "127.0.0.1" || host == "[::1]") {
			t.Fatal("identity host binding", host)
		}
	}
	transport := identityClient().Transport.(*http.Transport)
	if transport.Proxy != nil {
		t.Fatal("identity proxy enabled")
	}
	if _, err := transport.DialContext(context.Background(), "tcp", "foreign.example:443"); err == nil {
		t.Fatal("identity off-host dial allowed")
	}
}

func TestHealthAuthAndProofIsolation(t *testing.T) {
	c, key, _ := fixture(t)
	now := time.Unix(2000000000, 0)
	calls := 0
	s := &runtime{Config: c, Deps: dependencies{Now: func() time.Time { return now }},
		nonces: map[string]int64{}, slots: make(chan struct{}, 1)}
	s.Proof = func(context.Context, string) (witness, error) { calls++; return witness{Status: "PASS"}, nil }
	paths := []string{"/health", "/ready", "/proof/secret", "/proof/identity", "/proof/pull-token"}
	for i, path := range paths {
		req := signed(path, key, now.Unix()+30, strings.Repeat(strconv.Itoa(i), 64))
		rec := httptest.NewRecorder()
		s.ServeHTTP(rec, req)
		if rec.Code != 200 || rec.Header().Get("Cache-Control") != "no-store" {
			t.Fatal(path, rec.Code)
		}
		rec = httptest.NewRecorder()
		s.ServeHTTP(rec, req)
		if rec.Code != 401 {
			t.Fatal("replay")
		}
		rec = httptest.NewRecorder()
		s.ServeHTTP(rec, httptest.NewRequest("GET", path, nil))
		if rec.Code != 401 {
			t.Fatal("unauthenticated", path)
		}
	}
	if calls != 4 {
		t.Fatal("health accessed dependency")
	}
	s.Proof = func(context.Context, string) (witness, error) { return witness{}, errors.New("RAW_SECRET_TOKEN") }
	for _, path := range []string{"/ready", "/proof/secret"} {
		rec := httptest.NewRecorder()
		s.ServeHTTP(rec, signed(path, key, now.Unix()+30, strings.Repeat("f", 64)))
		if rec.Code != 503 || strings.Contains(rec.Body.String(), "RAW_") {
			t.Fatal("unsafe failure")
		}
		s.nonces = map[string]int64{}
	}
	for _, path := range []string{"/probes/live", "/probes/startup"} {
		rec := httptest.NewRecorder()
		s.ServeHTTP(rec, httptest.NewRequest("GET", path, nil))
		if rec.Code != 200 {
			t.Fatal(path)
		}
	}
	for _, req := range []*http.Request{
		signed("/proof/secret", key, now.Unix()-1, strings.Repeat("c", 64)),
		signed("/proof/secret", key, now.Unix()+61, strings.Repeat("d", 64)),
		signed("/proof/secret?target=foreign", key, now.Unix()+30, strings.Repeat("e", 64)),
	} {
		rec := httptest.NewRecorder()
		s.ServeHTTP(rec, req)
		if rec.Code != 401 {
			t.Fatal("bad signed request")
		}
	}
	s.slots <- struct{}{}
	rec := httptest.NewRecorder()
	s.ServeHTTP(rec, signed("/ready", key, now.Unix()+30, strings.Repeat("a", 64)))
	if rec.Code != 429 {
		t.Fatal("unbounded concurrent proof")
	}
}

func TestPrivateSecretChallengeAndFailures(t *testing.T) {
	c, _, _ := fixture(t)
	for _, scenario := range []string{"ok", "wrong-value", "wrong-id", "forbidden-403", "forbidden-403-firewall", "forbidden-403-unclassified", "forbidden-404", "forbidden-200", "tls-unverified", "dns-public", "identity-denied", "identity-client-mismatch", "token-principal-mismatch"} {
		t.Run(scenario, func(t *testing.T) {
			cc := c
			d := dependencies{Now: func() time.Time { return time.Unix(2000000000, 0) }, Identity: identityMock(c, 200, false)}
			if scenario == "identity-denied" {
				d.Identity = identityMock(c, 403, false)
			}
			if scenario == "identity-client-mismatch" {
				d.Identity = identityMock(c, 200, true)
			}
			if scenario == "token-principal-mismatch" {
				cc.PrincipalID = "99999999-2222-3333-4444-555555555555"
			}
			forbidden := strings.HasPrefix(scenario, "forbidden")
			d.Private = mockPrivate(func(r *http.Request) (int, string, string) {
				if r.Header.Get("X-IDENTITY-HEADER") != "" || r.Header.Get("Authorization") == "" {
					t.Fatal("headers leaked/unbound")
				}
				code := 200
				if strings.HasPrefix(scenario, "forbidden-403") {
					code = 403
				}
				if scenario == "forbidden-404" {
					code = 404
				}
				value, id := "local-synthetic-secret-not-a-credential", c.SecretURI
				if scenario == "wrong-value" {
					value = "wrong"
				}
				if scenario == "wrong-id" {
					id = "foreign"
				}
				body, _ := json.Marshal(map[string]string{"value": value, "id": id})
				if scenario == "forbidden-403" {
					body = []byte(`{"error":{"code":"Forbidden","innererror":{"code":"ForbiddenByRbac"}}}`)
				}
				if scenario == "forbidden-403-firewall" {
					body = []byte(`{"error":{"code":"Forbidden","innererror":{"code":"ForbiddenByFirewall"}}}`)
				}
				return code, string(body), ""
			}, scenario != "tls-unverified")
			if scenario == "dns-public" {
				d.Private = func(context.Context, string) (*privateSession, error) {
					return nil, proofError("PRIVATE_DNS_OUTSIDE_ENDPOINT_SUBNET")
				}
			}
			result, err := secretProof(context.Background(), cc, d, forbidden)
			if scenario == "ok" || scenario == "forbidden-403" {
				if err != nil {
					t.Fatal(err)
				}
				if scenario == "ok" && (result.Challenge != "PASS" || result.PrincipalID != c.PrincipalID || result.TLS != "PASS") {
					t.Fatal("witness incomplete")
				}
			} else if err == nil {
				t.Fatal("failure accepted")
			}
			body, _ := json.Marshal(result)
			if strings.Contains(string(body), "local-synthetic-secret") || strings.Contains(string(body), "access_token") {
				t.Fatal("secret/token response")
			}
		})
	}
}

func TestPullTokenDeniedNotNetworkFailure(t *testing.T) {
	c, _, _ := fixture(t)
	for _, code := range []int{400, 403, 404, 500, 200} {
		d := dependencies{Identity: identityMock(c, code, false)}
		result, err := pullTokenProof(context.Background(), c, d)
		if code == 403 {
			if err != nil || result.Status != "DENIED" {
				t.Fatal(code, err)
			}
		} else if err == nil {
			t.Fatal("non-denial accepted", code)
		}
	}
}

func TestRegistryDenialsAndOwnedUnexpectedUploadCleanup(t *testing.T) {
	c, _, _ := fixture(t)
	for _, scenario := range []string{"403", "401", "404", "transport", "unexpected-write", "hostile-location", "cleanup-failure"} {
		t.Run(scenario, func(t *testing.T) {
			calls := []string{}
			write := strings.Contains(scenario, "write") || scenario == "hostile-location" || scenario == "cleanup-failure"
			d := dependencies{Identity: identityMock(c, 200, false), Now: func() time.Time { return time.Unix(2000000000, 0) }}
			d.Private = mockPrivate(func(r *http.Request) (int, string, string) {
				calls = append(calls, r.Method+" "+r.URL.Path)
				switch r.URL.Path {
				case "/oauth2/exchange":
					return 200, `{"refresh_token":"LOCAL_ONLY_REFRESH"}`, ""
				case "/oauth2/token":
					return 200, `{"access_token":"LOCAL_ONLY_ACCESS"}`, ""
				case "/v2/g3-synthetic-runtime/blobs/uploads/":
					loc := "/v2/g3-synthetic-runtime/blobs/uploads/owned-id"
					if scenario == "hostile-location" {
						loc = "https://foreign.example/leak"
					}
					return 202, "", loc
				case "/v2/g3-synthetic-runtime/blobs/uploads/owned-id":
					if r.Method != "DELETE" {
						t.Fatal("not cleanup")
					}
					if scenario == "cleanup-failure" {
						return 403, "", ""
					}
					return 204, "", ""
				default:
					code, _ := strconv.Atoi(scenario)
					return code, "", ""
				}
			}, true)
			if scenario == "transport" {
				d.Private = func(context.Context, string) (*privateSession, error) { return nil, proofError("PRIVATE_DNS_FAILURE") }
			}
			result, err := registryProof(context.Background(), c, d, "g3-synthetic-runtime", write)
			if scenario == "401" || scenario == "403" {
				if err != nil || result.Status != "DENIED" {
					t.Fatal(err)
				}
			} else if err == nil {
				t.Fatal("inconclusive unexpectedly passed")
			}
			if scenario == "unexpected-write" && calls[len(calls)-1] != "DELETE /v2/g3-synthetic-runtime/blobs/uploads/owned-id" {
				t.Fatal("not owned cleanup")
			}
			if scenario == "hostile-location" && len(calls) != 3 {
				t.Fatal("followed hostile cleanup URI")
			}
		})
	}
}

func TestClaimsAndBoundedResponse(t *testing.T) {
	c, _, _ := fixture(t)
	if _, err := tokenClaims(jwt(c, "https://vault.azure.net"), c, "https://vault.azure.net", time.Unix(2000000000, 0)); err != nil {
		t.Fatal(err)
	}
	for _, raw := range []string{"bad", "x." + base64.RawURLEncoding.EncodeToString([]byte(`{"oid":"foreign"}`)) + ".x"} {
		if _, err := tokenClaims(raw, c, "https://vault.azure.net", time.Unix(2000000000, 0)); err == nil {
			t.Fatal("bad token")
		}
	}
	resp := &http.Response{Body: io.NopCloser(strings.NewReader(strings.Repeat("x", 65537)))}
	if _, err := bounded(resp); err == nil {
		t.Fatal("unbounded response")
	}
	if _, err := openPrivate(context.Background(), "foreign.example"); err == nil {
		t.Fatal("unbounded target")
	}
}
