targetScope = 'resourceGroup'

param appsSubnetId string
param tags object

resource environment 'Microsoft.App/managedEnvironments@2025-07-01' = {
  name: 'nzila-g3-test-001-env'
  location: 'canadacentral'
  tags: tags
  properties: {
    infrastructureResourceGroup: 'nzila-g3-test-001-managed-rg'
    publicNetworkAccess: 'Disabled'
    vnetConfiguration: {infrastructureSubnetId: appsSubnetId, internal: true}
    workloadProfiles: [{name: 'Consumption', workloadProfileType: 'Consumption'}]
    appLogsConfiguration: {destination: 'azure-monitor'}
    peerTrafficConfiguration: {encryption: {enabled: true}}
  }
}

output environmentId string = environment.id
output defaultDomain string = environment.properties.defaultDomain
output privateStaticIp string = environment.properties.staticIp
output quotaUrl string = uri(az.environment().resourceManager, '${environment.id}/usages?api-version=2025-07-01')
