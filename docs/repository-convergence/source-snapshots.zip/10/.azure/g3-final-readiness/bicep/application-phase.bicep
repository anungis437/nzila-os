targetScope = 'resourceGroup'

param environmentId string
param tags object
param pullIdentityId string
param runtimeIdentityId string
param runtimeClientId string
param runtimePrincipalId string
param pullClientId string
@minLength(64)
@maxLength(64)
param sourceAuthority string
@minLength(64)
@maxLength(64)
param imageDigest string
@minLength(32)
@maxLength(32)
param secretVersion string
param probePublicKey string
@minLength(35)
@maxLength(35)
param challengeId string
@minLength(64)
@maxLength(64)
param expectedChallengeSha256 string

resource app 'Microsoft.App/containerApps@2025-07-01' = {
  name: 'nzila-g3-test-001-health'
  location: 'canadacentral'
  tags: tags
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${pullIdentityId}': {}
      '${runtimeIdentityId}': {}
    }
  }
  properties: {
    managedEnvironmentId: environmentId
    workloadProfileName: 'Consumption'
    configuration: {
      activeRevisionsMode: 'Single'
      identitySettings: [
        {identity: pullIdentityId, lifecycle: 'None'}
        {identity: runtimeIdentityId, lifecycle: 'Main'}
      ]
      registries: [{server: 'nzilag2tzo75uuozprbo.azurecr.io', identity: pullIdentityId}]
      ingress: {
        external: true
        targetPort: 3000
        transport: 'http'
        allowInsecure: false
      }
    }
    template: {
      containers: [
        {
          name: 'g3-runtime'
          image: 'nzilag2tzo75uuozprbo.azurecr.io/g3-synthetic-runtime@sha256:${imageDigest}'
          resources: {cpu: json('0.25'), memory: '0.5Gi'}
          env: [
            {name: 'G3_ENVIRONMENT', value: 'integration-test'}
            {name: 'G3_SOURCE_AUTHORITY', value: sourceAuthority}
            {name: 'G3_SECRET_URI', value: 'https://nzl-g3-test-001-kv${az.environment().suffixes.keyvaultDns}/secrets/substrate-proof/${secretVersion}'}
            {name: 'G3_PROOF_MODE', value: 'synthetic-only'}
            {name: 'G3_PROBE_PUBLIC_KEY', value: probePublicKey}
            {name: 'AZURE_CLIENT_ID', value: runtimeClientId}
            {name: 'G3_RUNTIME_PRINCIPAL_ID', value: runtimePrincipalId}
            {name: 'G3_PULL_CLIENT_ID', value: pullClientId}
            {name: 'G3_CHALLENGE_ID', value: challengeId}
            {name: 'G3_EXPECTED_SECRET_SHA256', value: expectedChallengeSha256}
          ]
          probes: [
            {
              type: 'Startup'
              httpGet: {path: '/probes/startup', port: 3000}
              periodSeconds: 5
              failureThreshold: 24
            }
            {
              type: 'Liveness'
              httpGet: {path: '/probes/live', port: 3000}
              periodSeconds: 10
              failureThreshold: 3
            }
            {
              type: 'Readiness'
              httpGet: {path: '/probes/ready', port: 3000}
              periodSeconds: 10
              failureThreshold: 3
              timeoutSeconds: 20
            }
          ]
        }
      ]
      scale: {minReplicas: 1, maxReplicas: 1}
    }
  }
}

output appId string = app.id
output appFqdn string = app.properties.configuration.ingress.fqdn
