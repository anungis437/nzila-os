package main

import (
	"archive/tar"
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func archiveFixture(t *testing.T, names []string, kind byte) []byte {
	t.Helper()
	var data bytes.Buffer
	writer := tar.NewWriter(&data)
	for _, name := range names {
		header := &tar.Header{Name: name, Mode: 0644, Typeflag: kind}
		if kind == tar.TypeSymlink || kind == tar.TypeLink {
			header.Linkname = "/foreign"
		}
		if err := writer.WriteHeader(header); err != nil {
			t.Fatal(err)
		}
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	return data.Bytes()
}

func TestRejectArchiveEscapesTypesAndDuplicates(t *testing.T) {
	for _, tc := range []struct {
		names []string
		kind  byte
	}{
		{[]string{"/foreign"}, tar.TypeReg}, {[]string{"../foreign"}, tar.TypeReg},
		{[]string{"x/../foreign"}, tar.TypeReg}, {[]string{"x\\file"}, tar.TypeReg},
		{[]string{"file"}, tar.TypeSymlink}, {[]string{"file"}, tar.TypeLink},
		{[]string{"file"}, tar.TypeChar}, {[]string{"file", "file"}, tar.TypeReg},
	} {
		contract := map[string]entry{"file": {SHA: hash(nil), Mode: 0644}}
		if err := extract(archiveFixture(t, tc.names, tc.kind), filepath.Join(t.TempDir(), "out"), contract); err == nil {
			t.Fatal("unsafe archive accepted", tc)
		}
	}
}

func TestExtractionExactHashModeCensusAndNoOverwrite(t *testing.T) {
	raw := archiveFixture(t, []string{"file"}, tar.TypeReg)
	contract := map[string]entry{"file": {SHA: hash(nil), Mode: 0644}}
	dest := filepath.Join(t.TempDir(), "out")
	if err := extract(raw, dest, contract); err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(filepath.Join(dest, "file"))
	if err != nil || info.Mode().Perm() != 0644 {
		t.Fatal("mode", err)
	}
	if err := extract(raw, dest, contract); err == nil {
		t.Fatal("existing workspace accepted")
	}
	for _, bad := range []map[string]entry{
		{"file": {SHA: hash([]byte("foreign")), Mode: 0644}},
		{"file": {SHA: hash(nil), Mode: 0755}},
		{"file": {SHA: hash(nil), Mode: 0644}, "missing": {SHA: hash(nil), Mode: 0644}},
	} {
		if err := extract(raw, filepath.Join(t.TempDir(), "out"), bad); err == nil {
			t.Fatal("unbound archive accepted")
		}
	}
}

func TestFrozenTarMetadataWithoutCompression(t *testing.T) {
	files := []struct {
		Name      string
		Mode      int64
		Data      []byte
		Directory bool
	}{{"g3-runtime", 0755, []byte("fixture"), false}}
	raw, err := makeLayer(files)
	if err != nil {
		t.Fatal(err)
	}
	again, err := makeLayer(files)
	if err != nil || !bytes.Equal(raw, again) || len(raw) != 2048 {
		t.Fatal("tar deterministic size")
	}
	header, err := tar.NewReader(bytes.NewReader(raw)).Next()
	if err != nil || header.Name != "g3-runtime" || header.Mode != 0755 ||
		header.Uid != 0 || header.Gid != 0 || header.ModTime.Unix() != 946684800 ||
		header.Typeflag != tar.TypeReg || header.Format != tar.FormatUSTAR {
		t.Fatal("frozen tar metadata", err)
	}
}

func TestDescriptorSizesCompactAndPretty(t *testing.T) {
	for _, template := range []string{`{"digest":"sha256:fixture","size":3}`,
		"{\n \"digest\": \"sha256:fixture\",\n \"size\": 3,\n \"mediaType\": \"fixture\"\n}"} {
		actual, err := replaceDescriptor(template, descriptor{Digest: "sha256:fixture", Size: 3}, []byte("five!"))
		if err != nil {
			t.Fatal(err)
		}
		var object descriptor
		if err := json.Unmarshal([]byte(actual), &object); err != nil || object.Size != 5 ||
			object.Digest != "sha256:"+hash([]byte("five!")) {
			t.Fatal("invalid descriptor", actual, err)
		}
	}
	if _, err := replaceDescriptor(`{"digest":"sha256:fixture","size":4}`,
		descriptor{Digest: "sha256:fixture", Size: 3}, []byte("five!")); err == nil {
		t.Fatal("unbound descriptor accepted")
	}
}

func TestCompressorRejectsUnprovenExecutableBeforeInvocation(t *testing.T) {
	binary := filepath.Join(t.TempDir(), "foreign")
	if err := os.WriteFile(binary, []byte("foreign"), 0700); err != nil {
		t.Fatal(err)
	}
	if _, err := compressStaged([]byte("fixture"), binary, t.TempDir(), t.TempDir()); err == nil {
		t.Fatal("foreign compressor accepted")
	}
}
