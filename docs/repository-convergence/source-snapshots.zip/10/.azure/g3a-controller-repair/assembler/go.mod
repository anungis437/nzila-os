module nzila.example/g3a-portable

go 1.27.2
