targetScope = 'resourceGroup'

param name string
@allowed(['canadacentral'])
param location string = 'canadacentral'
param tags object
param subnetId string
param targetId string
@allowed(['registry', 'vault'])
param groupId string
param zoneName string
param networkId string
param linkName string

resource zone 'Microsoft.Network/privateDnsZones@2024-06-01' = {
  name: zoneName
  location: 'global'
  tags: tags
}
resource link 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2024-06-01' = {
  parent: zone
  name: linkName
  location: 'global'
  properties: {
    registrationEnabled: false
    virtualNetwork: {id: networkId}
  }
}
resource endpoint 'Microsoft.Network/privateEndpoints@2024-05-01' = {
  name: name
  location: location
  tags: tags
  properties: {
    subnet: {id: subnetId}
    privateLinkServiceConnections: [
      {
        name: name
        properties: {
          privateLinkServiceId: targetId
          groupIds: [groupId]
        }
      }
    ]
  }
}
resource group 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2024-05-01' = {
  parent: endpoint
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {name: 'service', properties: {privateDnsZoneId: zone.id}}
    ]
  }
}
output endpointId string = endpoint.id
output zoneId string = zone.id
output linkId string = link.id
