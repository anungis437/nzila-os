targetScope = 'resourceGroup'

@allowed(['canadacentral'])
param location string = 'canadacentral'
param tags object
param appsSubnetId string
param networkId string
param workspaceId string
param pullIdentityId string
param runtimeIdentityId string
param runtimeClientId string
@minLength(64)
@maxLength(64)
param sourceAuthority string
@minLength(64)
@maxLength(64)
param imageDigest string
@minLength(1)
param secretVersion string
@minLength(1)
param probePublicKey string

resource environment 'Microsoft.App/managedEnvironments@2025-07-01' = {
  name: 'nzila-g3-test-001-env'
  location: location
  tags: tags
  properties: {
    infrastructureResourceGroup: 'nzila-g3-test-001-managed-rg'
    publicNetworkAccess: 'Disabled'
    vnetConfiguration: {infrastructureSubnetId: appsSubnetId, internal: true}
    workloadProfiles: [{name: 'Consumption', workloadProfileType: 'Consumption'}]
    appLogsConfiguration: {destination: 'azure-monitor'}
    peerTrafficConfiguration: {encryption: {enabled: true}}
  }
}
resource logs 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'g3-runtime-proof'
  scope: environment
  properties: {
    workspaceId: workspaceId
    logs: [
      {category: 'ContainerAppConsoleLogs', enabled: true}
      {category: 'ContainerAppSystemLogs', enabled: true}
    ]
  }
}
module internalDns 'internal-dns.bicep' = {
  name: 'g3-internal-dns'
  params: {
    defaultDomain: environment.properties.defaultDomain
    privateStaticIp: environment.properties.staticIp
    networkId: networkId
    tags: tags
  }
}
resource app 'Microsoft.App/containerApps@2025-07-01' = {
  name: 'nzila-g3-test-001-health'
  location: location
  tags: tags
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${pullIdentityId}': {}
      '${runtimeIdentityId}': {}
    }
  }
  properties: {
    managedEnvironmentId: environment.id
    workloadProfileName: 'Consumption'
    configuration: {
      activeRevisionsMode: 'Single'
      identitySettings: [
        {identity: pullIdentityId, lifecycle: 'None'}
        {identity: runtimeIdentityId, lifecycle: 'Main'}
      ]
      registries: [{server: 'nzilag2tzo75uuozprbo.azurecr.io', identity: pullIdentityId}]
      ingress: {
        external: true
        targetPort: 3000
        transport: 'http'
        allowInsecure: false
      }
    }
    template: {
      containers: [
        {
          name: 'g3-runtime'
          image: 'nzilag2tzo75uuozprbo.azurecr.io/g3-synthetic-runtime@sha256:${imageDigest}'
          resources: {cpu: json('0.25'), memory: '0.5Gi'}
          env: [
            {name: 'G3_ENVIRONMENT', value: 'integration-test'}
            {name: 'G3_SOURCE_AUTHORITY', value: sourceAuthority}
            {name: 'G3_SECRET_URI', value: 'https://nzl-g3-test-001-kv${az.environment().suffixes.keyvaultDns}/secrets/substrate-proof/${secretVersion}'}
            {name: 'G3_PROOF_MODE', value: 'synthetic-only'}
            {name: 'G3_PROBE_PUBLIC_KEY', value: probePublicKey}
            {name: 'AZURE_CLIENT_ID', value: runtimeClientId}
          ]
          probes: [
            {
              type: 'Startup'
              httpGet: {path: '/probes/startup', port: 3000}
              periodSeconds: 5
              failureThreshold: 24
            }
            {
              type: 'Liveness'
              httpGet: {path: '/probes/live', port: 3000}
              periodSeconds: 10
              failureThreshold: 3
            }
            {
              type: 'Readiness'
              httpGet: {path: '/probes/ready', port: 3000}
              periodSeconds: 10
              failureThreshold: 3
              timeoutSeconds: 20
            }
          ]
        }
      ]
      scale: {minReplicas: 1, maxReplicas: 1}
    }
  }
}
output appId string = app.id
output appFqdn string = app.properties.configuration.ingress.fqdn
output defaultDomain string = environment.properties.defaultDomain
output privateStaticIp string = environment.properties.staticIp
output dnsLinkId string = internalDns.outputs.linkId
output dnsRecordId string = internalDns.outputs.recordId
