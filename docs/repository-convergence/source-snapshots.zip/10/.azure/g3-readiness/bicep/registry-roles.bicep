targetScope = 'resourceGroup'

@allowed(['G3A', 'G3B'])
param slice string
@description('New G3A build principal or G3B image-pull principal, never a G2 principal.')
param principalId string

resource registry 'Microsoft.ContainerRegistry/registries@2025-11-01' existing = {
  name: 'nzilag2tzo75uuozprbo'
}
var roleId = slice == 'G3A' ? '2a1e307c-b015-4ebd-883e-5b7698a07328' : 'b93aa761-3e63-49ed-ac28-beffa264f7ac'
var actions = slice == 'G3A'
  ? [
    'Microsoft.ContainerRegistry/registries/repositories/content/read'
    'Microsoft.ContainerRegistry/registries/repositories/content/write'
    'Microsoft.ContainerRegistry/registries/repositories/metadata/read'
    'Microsoft.ContainerRegistry/registries/repositories/metadata/write'
  ]
  : [
    'Microsoft.ContainerRegistry/registries/repositories/content/read'
    'Microsoft.ContainerRegistry/registries/repositories/metadata/read'
  ]
var actionPredicate = join(map(actions, action => 'ActionMatches{\'${action}\'}'), ' OR ')

resource assignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(registry.id, principalId, roleId, 'g3-synthetic-runtime')
  scope: registry
  properties: {
    principalId: principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleId)
    conditionVersion: '2.0'
    condition: '((!(${actionPredicate})) OR (@Request[Microsoft.ContainerRegistry/registries/repositories:name] StringEqualsIgnoreCase \'g3-synthetic-runtime\'))'
  }
}
output assignmentId string = assignment.id
output condition string = assignment.properties.condition
