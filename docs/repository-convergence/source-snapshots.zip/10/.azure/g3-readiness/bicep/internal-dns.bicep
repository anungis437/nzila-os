targetScope = 'resourceGroup'

param defaultDomain string
param privateStaticIp string
param networkId string
param tags object

resource zone 'Microsoft.Network/privateDnsZones@2024-06-01' = {
  name: defaultDomain
  location: 'global'
  tags: tags
}
resource link 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2024-06-01' = {
  parent: zone
  name: 'nzila-g3-test-001-app-link'
  location: 'global'
  properties: {
    registrationEnabled: false
    virtualNetwork: {id: networkId}
  }
}
resource record 'Microsoft.Network/privateDnsZones/A@2024-06-01' = {
  parent: zone
  name: '*'
  properties: {
    ttl: 60
    aRecords: [{ipv4Address: privateStaticIp}]
  }
}
output zoneId string = zone.id
output linkId string = link.id
output recordId string = record.id
