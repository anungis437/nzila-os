targetScope = 'resourceGroup'

param runtimePrincipalId string

resource vault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: 'nzl-g3-test-001-kv'
}
resource secret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' existing = {
  parent: vault
  name: 'substrate-proof'
}
var roleId = '4633458b-17de-408a-b874-0445c86b69e6'
resource assignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: secret
  name: guid(secret.id, runtimePrincipalId, roleId, 'g3-runtime-secret')
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleId)
    principalId: runtimePrincipalId
    principalType: 'ServicePrincipal'
  }
}
output assignmentId string = assignment.id
