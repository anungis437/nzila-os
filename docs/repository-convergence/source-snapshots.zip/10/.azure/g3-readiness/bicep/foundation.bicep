targetScope = 'resourceGroup'

@allowed(['canadacentral'])
param location string = 'canadacentral'
param tags object
@description('Existing G2 target ID. Only a new private connection is proposed; no registry PUT.')
param registryId string

var subnetNames = ['apps', 'private-endpoints', 'builders', 'proof-clients']
var prefixes = ['10.91.0.0/27', '10.91.3.0/24', '10.91.4.0/28', '10.91.5.0/28']
var nsgNames = [
  'nzila-g3-test-001-apps-nsg'
  'nzila-g3-test-001-pe-nsg'
  'nzila-g3-test-001-build-nsg'
  'nzila-g3-test-001-probe-nsg'
]
var platformTags = [
  'MicrosoftContainerRegistry'
  'AzureFrontDoor.FirstParty'
  'AzureActiveDirectory'
  'AzureMonitor'
  'Storage.CanadaCentral'
]
var dnsRule = {
  name: 'allow-platform-dns'
  properties: {
    priority: 110
    direction: 'Outbound'
    access: 'Allow'
    protocol: '*'
    sourceAddressPrefix: '*'
    sourcePortRange: '*'
    destinationAddressPrefix: 'AzurePlatformDNS'
    destinationPortRange: '53'
  }
}
var privateRule = {
  name: 'allow-named-private-dependencies'
  properties: {
    priority: 120
    direction: 'Outbound'
    access: 'Allow'
    protocol: 'Tcp'
    sourceAddressPrefix: '*'
    sourcePortRange: '*'
    destinationAddressPrefix: '10.91.3.0/24'
    destinationPortRange: '443'
  }
}
var denyOutbound = {
  name: 'deny-other-outbound'
  properties: {
    priority: 4096
    direction: 'Outbound'
    access: 'Deny'
    protocol: '*'
    sourceAddressPrefix: '*'
    sourcePortRange: '*'
    destinationAddressPrefix: '*'
    destinationPortRange: '*'
  }
}
var denyInbound = union(denyOutbound, {
  name: 'deny-other-inbound'
  properties: union(denyOutbound.properties, {direction: 'Inbound'})
})
var platformRules = [for (tag, index) in platformTags: {
  name: 'allow-platform-${index}'
  properties: {
    priority: 200 + index
    direction: 'Outbound'
    access: 'Allow'
    protocol: 'Tcp'
    sourceAddressPrefix: '10.91.0.0/27'
    sourcePortRange: '*'
    destinationAddressPrefix: tag
    destinationPortRange: '443'
  }
}]
var appInternal = [for direction in ['Inbound', 'Outbound']: {
  name: 'allow-apps-subnet-${direction}'
  properties: {
    priority: 130
    direction: direction
    access: 'Allow'
    protocol: '*'
    sourceAddressPrefix: '10.91.0.0/27'
    sourcePortRange: '*'
    destinationAddressPrefix: '10.91.0.0/27'
    destinationPortRange: '*'
  }
}]
var healthRules = [
  {
    name: 'allow-signed-proof-client-https'
    properties: {
      priority: 100
      direction: 'Inbound'
      access: 'Allow'
      protocol: 'Tcp'
      sourceAddressPrefix: '10.91.5.0/28'
      sourcePortRange: '*'
      destinationAddressPrefix: '10.91.0.0/27'
      destinationPortRanges: ['443', '31443']
    }
  }
  {
    name: 'allow-platform-health-probes'
    properties: {
      priority: 105
      direction: 'Inbound'
      access: 'Allow'
      protocol: 'Tcp'
      sourceAddressPrefix: 'AzureLoadBalancer'
      sourcePortRange: '*'
      destinationAddressPrefix: '10.91.0.0/27'
      destinationPortRange: '30000-32767'
    }
  }
]
var endpointInbound = {
  name: 'allow-private-service-callers'
  properties: {
    priority: 100
    direction: 'Inbound'
    access: 'Allow'
    protocol: 'Tcp'
    sourceAddressPrefixes: ['10.91.0.0/27', '10.91.4.0/28', '10.91.5.0/28']
    sourcePortRange: '*'
    destinationAddressPrefix: '10.91.3.0/24'
    destinationPortRange: '443'
  }
}
var probeOutbound = {
  name: 'allow-private-app-proof'
  properties: {
    priority: 100
    direction: 'Outbound'
    access: 'Allow'
    protocol: 'Tcp'
    sourceAddressPrefix: '10.91.5.0/28'
    sourcePortRange: '*'
    destinationAddressPrefix: '10.91.0.0/27'
    destinationPortRange: '443'
  }
}

resource nsgs 'Microsoft.Network/networkSecurityGroups@2024-05-01' = [for (name, index) in nsgNames: {
  name: name
  location: location
  tags: tags
  properties: {
    securityRules: concat(
      [denyInbound, denyOutbound],
      index == 0 ? concat([dnsRule, privateRule], appInternal, healthRules, platformRules) : [],
      index == 1 ? [endpointInbound] : [],
      index == 2 ? [dnsRule, privateRule] : [],
      index == 3 ? [dnsRule, privateRule, probeOutbound] : []
    )
  }
}]
resource network 'Microsoft.Network/virtualNetworks@2024-05-01' = {
  name: 'nzila-g3-test-001-vnet'
  location: location
  tags: tags
  properties: {
    addressSpace: {addressPrefixes: ['10.91.0.0/16']}
    subnets: [for (name, index) in subnetNames: {
      name: name
      properties: {
        addressPrefix: prefixes[index]
        networkSecurityGroup: {id: nsgs[index].id}
        privateEndpointNetworkPolicies: index == 1 ? 'NetworkSecurityGroupEnabled' : 'Disabled'
        defaultOutboundAccess: false
        delegations: index == 0 ? [
          {
            name: 'container-apps'
            properties: {serviceName: 'Microsoft.App/environments'}
          }
        ] : []
      }
    }]
  }
}
resource vault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: 'nzl-g3-test-001-kv'
  location: location
  tags: tags
  properties: {
    tenantId: tenant().tenantId
    sku: {family: 'A', name: 'standard'}
    enableRbacAuthorization: true
    enableSoftDelete: true
    enablePurgeProtection: true
    softDeleteRetentionInDays: 90
    publicNetworkAccess: 'Disabled'
    networkAcls: {bypass: 'None', defaultAction: 'Deny'}
  }
}
resource workspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'nzila-g3-test-001-law'
  location: location
  tags: tags
  properties: {
    sku: {name: 'PerGB2018'}
    retentionInDays: 30
    features: {disableLocalAuth: true}
    workspaceCapping: {dailyQuotaGb: json('0.1')}
  }
}
var endpointSubnetId = resourceId('Microsoft.Network/virtualNetworks/subnets', network.name, 'private-endpoints')
module acrEndpoint 'private-endpoint.bicep' = {
  name: 'g3-acr-network'
  params: {
    name: 'nzila-g3-test-001-acr-pe'
    location: location
    tags: tags
    subnetId: endpointSubnetId
    targetId: registryId
    groupId: 'registry'
    zoneName: 'privatelink.azurecr.io'
    networkId: network.id
    linkName: 'nzila-g3-test-001-acr-link'
  }
}
module vaultEndpoint 'private-endpoint.bicep' = {
  name: 'g3-vault-network'
  params: {
    name: 'nzila-g3-test-001-kv-pe'
    location: location
    tags: tags
    subnetId: endpointSubnetId
    targetId: vault.id
    groupId: 'vault'
    zoneName: 'privatelink.vaultcore.azure.net'
    networkId: network.id
    linkName: 'nzila-g3-test-001-kv-link'
  }
}
resource vaultLogs 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'g3-secret-audit'
  scope: vault
  properties: {
    workspaceId: workspace.id
    logs: [{categoryGroup: 'allLogs', enabled: true}]
  }
}
output networkId string = network.id
output appsSubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', network.name, 'apps')
output vaultId string = vault.id
output workspaceId string = workspace.id
