targetScope = 'resourceGroup'

@allowed(['canadacentral'])
param location string = 'canadacentral'
param tags object

var names = [
  'nzila-g3-test-001-pull-mi'
  'nzila-g3-test-001-runtime-mi'
  'nzila-g3-test-001-build-mi'
  'nzila-g3-test-001-probe-mi'
]

resource identities 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = [for name in names: {
  name: name
  location: location
  tags: tags
}]

output pullIdentityId string = identities[0].id
output pullPrincipalId string = identities[0].properties.principalId
output runtimeIdentityId string = identities[1].id
output runtimePrincipalId string = identities[1].properties.principalId
output runtimeClientId string = identities[1].properties.clientId
output buildIdentityId string = identities[2].id
output buildPrincipalId string = identities[2].properties.principalId
output probeIdentityId string = identities[3].id
output probePrincipalId string = identities[3].properties.principalId
