package main

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

type config struct {
	Environment, Authority, SecretURI, ClientID, IdentityEndpoint, IdentityHeader string
	PublicKey                                                                     ed25519.PublicKey
}

var hex64 = regexp.MustCompile(`^[0-9a-f]{64}$`)
var guid = regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`)
var secretPath = regexp.MustCompile(`^/secrets/substrate-proof/[0-9a-f]{32}$`)

func loadConfig(get func(string) string) (config, error) {
	c := config{
		Environment: get("G3_ENVIRONMENT"), Authority: get("G3_SOURCE_AUTHORITY"),
		SecretURI: get("G3_SECRET_URI"), ClientID: get("AZURE_CLIENT_ID"),
		IdentityEndpoint: get("IDENTITY_ENDPOINT"), IdentityHeader: get("IDENTITY_HEADER"),
	}
	key, err := base64.StdEncoding.DecodeString(get("G3_PROBE_PUBLIC_KEY"))
	if err != nil || len(key) != ed25519.PublicKeySize {
		return c, errors.New("PROBE_KEY_INVALID")
	}
	c.PublicKey = ed25519.PublicKey(key)
	u, err := url.Parse(c.SecretURI)
	if err != nil || u.Scheme != "https" || u.Host != "nzl-g3-test-001-kv.vault.azure.net" ||
		u.User != nil || u.RawQuery != "" || u.Fragment != "" || !secretPath.MatchString(u.Path) {
		return c, errors.New("SECRET_REFERENCE_INVALID")
	}
	if c.Environment != "integration-test" || !hex64.MatchString(c.Authority) ||
		!guid.MatchString(c.ClientID) || get("G3_PROOF_MODE") != "synthetic-only" {
		return c, errors.New("CONFIG_BINDING_INVALID")
	}
	identityURL, err := url.Parse(c.IdentityEndpoint)
	if err != nil || identityURL.Scheme != "http" || identityURL.User != nil ||
		identityURL.RawQuery != "" || identityURL.Fragment != "" ||
		!net.ParseIP(identityURL.Hostname()).IsLoopback() || c.IdentityHeader == "" {
		return c, errors.New("IDENTITY_ENDPOINT_INVALID")
	}
	return c, nil
}

func decodeResponse(resp *http.Response, target interface{}, stage string) error {
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("%s_HTTP_%d", stage, resp.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, 65537))
	if err != nil || len(body) > 65536 || json.Unmarshal(body, target) != nil {
		return fmt.Errorf("%s_RESPONSE_INVALID", stage)
	}
	return nil
}

func fetchSecret(ctx context.Context, c config, client *http.Client) error {
	u, err := url.Parse(c.IdentityEndpoint)
	if err != nil {
		return errors.New("IDENTITY_ENDPOINT_INVALID")
	}
	q := u.Query()
	q.Set("api-version", "2019-08-01")
	q.Set("resource", "https://vault.azure.net")
	q.Set("client_id", c.ClientID)
	u.RawQuery = q.Encode()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return errors.New("IDENTITY_REQUEST_INVALID")
	}
	req.Header.Set("X-IDENTITY-HEADER", c.IdentityHeader)
	resp, err := client.Do(req)
	if err != nil {
		return errors.New("IDENTITY_TRANSPORT_FAILURE")
	}
	var token struct {
		AccessToken string `json:"access_token"`
		ClientID    string `json:"client_id"`
	}
	if err = decodeResponse(resp, &token, "IDENTITY"); err != nil {
		return err
	}
	if token.AccessToken == "" || token.ClientID != c.ClientID {
		return errors.New("IDENTITY_BINDING_INVALID")
	}
	req, err = http.NewRequestWithContext(ctx, http.MethodGet, c.SecretURI+"?api-version=7.4", nil)
	if err != nil {
		return errors.New("SECRET_REQUEST_INVALID")
	}
	req.Header.Set("Authorization", "Bearer "+token.AccessToken)
	resp, err = client.Do(req)
	if err != nil {
		return errors.New("SECRET_TRANSPORT_FAILURE")
	}
	var secret struct {
		Value string `json:"value"`
		ID    string `json:"id"`
	}
	if err = decodeResponse(resp, &secret, "SECRET"); err != nil {
		return err
	}
	if secret.ID != c.SecretURI || secret.Value == "" {
		return errors.New("SECRET_BINDING_INVALID")
	}
	return nil
}

type runtime struct {
	config config
	check  func(context.Context) error
	now    func() time.Time
	mu     sync.Mutex
	nonces map[string]int64
}

func (s *runtime) authorize(r *http.Request) bool {
	if r.URL.RawQuery != "" {
		return false
	}
	expiryText, nonce := r.Header.Get("X-G3-Expiry"), r.Header.Get("X-G3-Nonce")
	expiry, err := strconv.ParseInt(expiryText, 10, 64)
	now := s.now().Unix()
	if err != nil || expiry <= now || expiry > now+60 || !hex64.MatchString(nonce) {
		return false
	}
	signature, err := base64.StdEncoding.DecodeString(r.Header.Get("X-G3-Signature"))
	message := r.Method + "\n" + r.URL.Path + "\n" + nonce + "\n" + expiryText
	if err != nil || !ed25519.Verify(s.config.PublicKey, []byte(message), signature) {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for n, until := range s.nonces {
		if until <= now {
			delete(s.nonces, n)
		}
	}
	if _, exists := s.nonces[nonce]; exists || len(s.nonces) >= 1024 {
		return false
	}
	s.nonces[nonce] = expiry
	return true
}

func writeStatus(w http.ResponseWriter, code int, status string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	if _, err := io.WriteString(w, `{"status":"`+status+`"}`); err != nil {
		log.Print("RESPONSE_WRITE_FAILURE")
	}
}

func (s *runtime) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.Header().Set("Allow", http.MethodGet)
		writeStatus(w, http.StatusMethodNotAllowed, "method_not_allowed")
		return
	}
	switch r.URL.Path {
	case "/health", "/ready", "/probes/startup", "/probes/live", "/probes/ready":
	default:
		writeStatus(w, http.StatusNotFound, "not_found")
		return
	}
	if !strings.HasPrefix(r.URL.Path, "/probes/") && !s.authorize(r) {
		writeStatus(w, http.StatusUnauthorized, "unauthorized")
		return
	}
	if r.URL.Path == "/ready" || r.URL.Path == "/probes/ready" {
		if err := s.check(r.Context()); err != nil {
			log.Print(err)
			writeStatus(w, http.StatusServiceUnavailable, "not_ready")
			return
		}
	}
	writeStatus(w, http.StatusOK, "ok")
}

func main() {
	c, err := loadConfig(os.Getenv)
	if err != nil {
		log.Fatal(err)
	}
	client := &http.Client{
		Timeout: 10 * time.Second,
		Transport: &http.Transport{
			Proxy:               nil,
			DialContext:         (&net.Dialer{Timeout: 5 * time.Second}).DialContext,
			TLSHandshakeTimeout: 5 * time.Second,
		},
		CheckRedirect: func(_ *http.Request, _ []*http.Request) error { return http.ErrUseLastResponse },
	}
	s := &runtime{config: c, now: time.Now, nonces: map[string]int64{},
		check: func(ctx context.Context) error { return fetchSecret(ctx, c, client) }}
	server := &http.Server{Addr: ":3000", Handler: s, ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout: 15 * time.Second, WriteTimeout: 25 * time.Second, IdleTimeout: 30 * time.Second}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	done := make(chan struct{})
	go func() {
		<-ctx.Done()
		shutdown, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := server.Shutdown(shutdown); err != nil {
			log.Print("SHUTDOWN_FAILURE")
		}
		close(done)
	}()
	if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatal("SERVER_START_FAILURE")
	}
	<-done
}
