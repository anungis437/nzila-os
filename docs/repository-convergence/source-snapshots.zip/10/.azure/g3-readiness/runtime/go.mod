module example.com/nzila/g3-synthetic-runtime

go 1.27.2
