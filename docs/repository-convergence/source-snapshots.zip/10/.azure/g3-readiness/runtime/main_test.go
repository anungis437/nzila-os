package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"
	"time"
)

func fixture(t *testing.T) (config, ed25519.PrivateKey, map[string]string) {
	t.Helper()
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	env := map[string]string{
		"G3_ENVIRONMENT": "integration-test", "G3_SOURCE_AUTHORITY": strings.Repeat("a", 64),
		"G3_SECRET_URI":     "https://nzl-g3-test-001-kv.vault.azure.net/secrets/substrate-proof/" + strings.Repeat("a", 32),
		"AZURE_CLIENT_ID":   "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
		"IDENTITY_ENDPOINT": "http://127.0.0.1:1234/msi/token", "IDENTITY_HEADER": "synthetic-ephemeral",
		"G3_PROBE_PUBLIC_KEY": base64.StdEncoding.EncodeToString(pub), "G3_PROOF_MODE": "synthetic-only",
	}
	c, err := loadConfig(func(k string) string { return env[k] })
	if err != nil {
		t.Fatal(err)
	}
	return c, priv, env
}

func signed(path string, key ed25519.PrivateKey, expiry int64, nonce string) *http.Request {
	req := httptest.NewRequest(http.MethodGet, path, nil)
	exp := strconv.FormatInt(expiry, 10)
	req.Header.Set("X-G3-Expiry", exp)
	req.Header.Set("X-G3-Nonce", nonce)
	req.Header.Set("X-G3-Signature", base64.StdEncoding.EncodeToString(ed25519.Sign(key, []byte("GET\n"+path+"\n"+nonce+"\n"+exp))))
	return req
}

func TestConfigFailsClosed(t *testing.T) {
	_, _, env := fixture(t)
	for k := range env {
		t.Run(k, func(t *testing.T) {
			copy := map[string]string{}
			for key, v := range env {
				copy[key] = v
			}
			copy[k] = ""
			if _, err := loadConfig(func(k string) string { return copy[k] }); err == nil {
				t.Fatal("missing required value accepted")
			}
		})
	}
	for _, uri := range []string{"http://nzl-g3-test-001-kv.vault.azure.net/secrets/substrate-proof/" + strings.Repeat("a", 32), "https://foreign.vault.azure.net/secrets/substrate-proof/" + strings.Repeat("a", 32), env["G3_SECRET_URI"] + "?secret=leak", strings.ReplaceAll(env["G3_SECRET_URI"], "substrate-proof", "foreign")} {
		env["G3_SECRET_URI"] = uri
		if _, err := loadConfig(func(k string) string { return env[k] }); err == nil {
			t.Fatalf("invalid secret URI accepted")
		}
	}
}

func TestHealthReadinessAndAuthorization(t *testing.T) {
	c, key, _ := fixture(t)
	now := time.Unix(2000000000, 0)
	checks := 0
	s := &runtime{config: c, now: func() time.Time { return now }, nonces: map[string]int64{},
		check: func(context.Context) error { checks++; return nil }}
	for i, path := range []string{"/health", "/ready"} {
		req := signed(path, key, now.Unix()+30, strings.Repeat(strconv.Itoa(i), 64))
		res := httptest.NewRecorder()
		s.ServeHTTP(res, req)
		if res.Code != 200 || res.Body.String() != `{"status":"ok"}` || res.Header().Get("Cache-Control") != "no-store" {
			t.Fatalf("unexpected health result: %d %s", res.Code, res.Body.String())
		}
		res = httptest.NewRecorder()
		s.ServeHTTP(res, req)
		if res.Code != 401 {
			t.Fatal("replayed signed request accepted")
		}
	}
	if checks != 1 {
		t.Fatal("health should not consume a secret")
	}
	s.check = func(context.Context) error { return errors.New("SECRET_HTTP_403") }
	res := httptest.NewRecorder()
	s.ServeHTTP(res, signed("/ready", key, now.Unix()+30, strings.Repeat("c", 64)))
	if res.Code != 503 || res.Body.String() != `{"status":"not_ready"}` {
		t.Fatal("secret denial must fail readiness without detail disclosure")
	}
	for _, req := range []*http.Request{
		httptest.NewRequest(http.MethodGet, "/health", nil),
		signed("/health", key, now.Unix()-1, strings.Repeat("d", 64)),
		signed("/health", key, now.Unix()+61, strings.Repeat("e", 64)),
		signed("/health?unexpected=1", key, now.Unix()+30, strings.Repeat("f", 64)),
	} {
		res := httptest.NewRecorder()
		s.ServeHTTP(res, req)
		if res.Code != 401 {
			t.Fatal("invalid signed request accepted")
		}
	}
	for _, test := range []struct {
		method, path string
		code         int
	}{
		{"POST", "/health", 405}, {"GET", "/unknown", 404},
		{"GET", "/probes/live", 200}, {"GET", "/probes/startup", 200}, {"GET", "/probes/ready", 503},
	} {
		res := httptest.NewRecorder()
		s.ServeHTTP(res, httptest.NewRequest(test.method, test.path, nil))
		if res.Code != test.code {
			t.Fatalf("%s: %d", test.path, res.Code)
		}
	}
}

type transportFunc func(*http.Request) (*http.Response, error)

func (f transportFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func TestSecretFlowAndSanitizedFailures(t *testing.T) {
	c, _, _ := fixture(t)
	for _, scenario := range []string{"ok", "identity-denied", "identity-mismatch", "secret-denied", "wrong-secret-id", "empty-secret", "transport", "oversize"} {
		t.Run(scenario, func(t *testing.T) {
			client := &http.Client{Transport: transportFunc(func(r *http.Request) (*http.Response, error) {
				code, body := 200, ""
				if scenario == "transport" {
					return nil, errors.New("RAW_TOKEN_SECRET_MUST_NOT_ESCAPE")
				}
				if r.URL.Hostname() == "127.0.0.1" {
					if r.Header.Get("X-IDENTITY-HEADER") != c.IdentityHeader || r.URL.Query().Get("client_id") != c.ClientID || r.URL.Query().Get("resource") != "https://vault.azure.net" {
						t.Fatal("identity request is not explicitly bound")
					}
					body = `{"access_token":"EPHEMERAL_NOT_PERSISTED","client_id":"` + c.ClientID + `"}`
					if scenario == "identity-denied" {
						code = 403
					}
					if scenario == "identity-mismatch" {
						body = `{"access_token":"ephemeral","client_id":"foreign"}`
					}
				} else {
					if r.Header.Get("Authorization") != "Bearer EPHEMERAL_NOT_PERSISTED" || r.Header.Get("X-IDENTITY-HEADER") != "" {
						t.Fatal("secret request headers wrong")
					}
					body = `{"value":"random-synthetic","id":"` + c.SecretURI + `"}`
					if scenario == "secret-denied" {
						code = 403
					}
					if scenario == "wrong-secret-id" {
						body = `{"value":"random-synthetic","id":"foreign"}`
					}
					if scenario == "empty-secret" {
						body = `{"value":"","id":"` + c.SecretURI + `"}`
					}
				}
				if scenario == "oversize" {
					body = strings.Repeat("x", 65537)
				}
				return &http.Response{StatusCode: code, Body: io.NopCloser(strings.NewReader(body))}, nil
			})}
			err := fetchSecret(context.Background(), c, client)
			if scenario == "ok" && err != nil {
				t.Fatal(err)
			}
			if scenario != "ok" && (err == nil || strings.Contains(err.Error(), "RAW_")) {
				t.Fatal("failure not surfaced safely")
			}
		})
	}
}
