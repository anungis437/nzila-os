targetScope = 'resourceGroup'
@allowed([false])
param workloadActivationAuthorized bool = false
param location string
param names object
param tags object
param environmentId string
param buildIdentityId string
param runtimeIdentityId string
param immutableImage string

resource app 'Microsoft.App/containerApps@2025-07-01' = if (workloadActivationAuthorized) {
  name: names.application
  location: location
  tags: tags
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${buildIdentityId}': {}
      '${runtimeIdentityId}': {}
    }
  }
  properties: {
    environmentId: environmentId
    workloadProfileName: 'Consumption'
    configuration: {
      activeRevisionsMode: 'Single'
      identitySettings: [
        { identity: buildIdentityId, lifecycle: 'None' }
        { identity: runtimeIdentityId, lifecycle: 'Main' }
      ]
      registries: [{ server: 'nzilag2tzo75uuozprbo.azurecr.io', identity: buildIdentityId }]
      ingress: {
        external: true
        targetPort: 3000
        transport: 'http'
        allowInsecure: false
      }
      secrets: [
        {
          name: 'g3-proof-secret'
          keyVaultUrl: 'https://${names.keyVault}${environment().suffixes.keyvaultDns}/secrets/g3-proof-secret'
          identity: runtimeIdentityId
        }
      ]
    }
    template: {
      containers: [
        {
          name: 'g3-synthetic-runtime'
          image: immutableImage
          env: [{ name: 'G3_PROOF_SECRET', secretRef: 'g3-proof-secret' }]
          resources: { cpu: json('0.25'), memory: '0.5Gi' }
          probes: [
            {
              type: 'Readiness'
              httpGet: { path: '/health/readiness', port: 3000 }
              initialDelaySeconds: 5
              periodSeconds: 10
            }
            {
              type: 'Liveness'
              httpGet: { path: '/health/liveness', port: 3000 }
              initialDelaySeconds: 10
              periodSeconds: 10
            }
          ]
        }
      ]
      scale: { minReplicas: 0, maxReplicas: 1 }
    }
  }
}
output authorityStatus string = 'DENY;PROSPECTIVE_SOURCE_ONLY'
